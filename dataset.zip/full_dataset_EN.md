# Xiaohongshu carpooling research: English reading edition

70 posts and 1,480 comments. Automated translation with selected passages edited and remaining service-limited fields translated separately; not fully reviewed. Original Chinese and source metadata are preserved in the bilingual CSV files. Some posts contain only collected excerpts. Opinions and factual claims are those of the original commenters.

## 1. Carpooling is really a test of luck.

Source: https://www.rednote.com/discovery/item/6adc3893000000003300e097
Original record: 20_posts_480_comments / R001
Text scope: Collected post text

The guy kept crunching away on spicy snacks the whole way, and the smell in the car was something else. His phone kept playing livestream battles at a ridiculously loud volume. My poor clip-on earbuds couldn't block it out. I could barely breathe, my ears were ringing, and my head was pounding. Those two hours were unbearable. #Carpooling #CouldTheWorldBeAKinderPlace

### Comments

No sampled comments in the supplied dataset.

## 2. Every carpooling ride is like entering a DJ set

Source: https://www.rednote.com/discovery/item/6905f75f0000000004012d86
Original record: 20_posts_480_comments / R002
Text scope: Collected post text

I don’t want to appreciate it but I’m too embarrassed to stop. Just pretend it’s for the fare.
#carpooling #taxi

### Comments

**R021**

Reply to 小红薯6837143B: The driver was simply playing it far too loud. My eardrums hurt.

**R039**

I didn’t even dislike the loud TikTok videos of the carpoolers, and even disliked the playlist in the car.

**R056**

Isn’t it just because I think the high-speed rail is troublesome? Isn’t it cheaper to pick up and drop off in a carpooling car than to take a taxi? It doesn’t matter to me what songs other people play. . Anyway, I use my own TikTok.

**R071**

Not everyone can think this way about you. Some people are truly professional passengers.

**R084**

Reply to Gong Xi Fa Cai 💰: I replaced the broken mobile phone before. When I need to travel long distances, I take it out and use it. The experience is much better.

**R096**

exclusive ridehighway tolls I will let them choose the playlist

**R108**

it's me

**R119**

My car can not only listen but also sing

**R129**

I do carpooling just to let others listen to my playlist

**R139**

I took a premium ride service once. It was quiet and the driver was nice and polite.

**R149**

I once attended a carpooling session and read the novel "Jianke" to them for two hours.

**R159**

You're a bit handsome

**R169**

I know some people don’t like to play too loud music, but I can’t help it. Playing music can cheer me up and make me safer. Otherwise, staring at an empty line for an hour or two on the highway will easily make me sleepy.

**R179**

I'm happy to play some death metal and rape the passengers' ears.

**R189**

It’s a cheap deal in the first place. If you call for an exclusive ride, I’ll listen to you, so the last sentence is very pertinent. In order to pay for the ride

**R199**

You can use the premium ride service. The premium ride service can be arranged according to your requirements.

**R209**

Haha, so I play Jay Chou’s songs every time, paired with my Bowers and Wei Jian, and I have successfully received high praise and recognition from four young ladies.

**R219**

I like to play soothing music when driving. The people in my car are more nervous than me and are afraid that I will fall asleep.

**R229**

Reply to wowo: Because I have two mobile phones, and when I call someone long distance, I put the platform on the backup phone.

**R239**

I don't care about this, after all, carpooling, but there is someone who keeps talking to me, and the more he asks, the more detailed and private he becomes. Do I have to endure it because I am carpooling?

**R249**

Then you have to listen and fall asleep, it's not safe

**R259**

Because of boredom, because of sleepiness. . Because if I want to race, no one can stop me.

**R267**

Reply to wowo: Haha yes

**R275**

Since I have like-minded people, I just like to play my own playlist

**R283**

Are you going to make it a thriller or a hypnotic one?

**R291** (post author)

I once sat in a car that was constantly playing rock and folk songs. The driver kept switching between smart driving and manual driving. When driving smartly, he waved his hands to play songs. The car kept switching between them, and the car was filled with loud singing. I am embarrassed to say that in the first half, I broke into a cold sweat and felt like vomiting (physically) in the second half, and then I almost climbed out of the car.

**R299**

I feel tired and sleepy without playing a song. I am not a driver who specializes in driving, and I have not practiced the ability to drive quietly.

**R307**

I won’t let friends who dislike my playlist anymore ride in my car [Smile R]

**R315**

I also like to listen to DJs when I’m driving. I can resist feeling sleepy. When I’m in someone else’s car, I don’t want others to listen to DJs.

**R323**

Let him play Chopin Bach

**R330**

So why do so many people dislike drivers playing songs?

**R336**

I'm speechless. When I meet a driver who only listens to hard rock, my head will explode.

**R342**

I can't do it anymore. The driver kept playing the microphone and shouted very loudly. The key is that he was still listening to the novel.

**R348**

Just tell him directly that he is motion sick and needs to rest.

**R354**

Reply to wowo: It seems that the phone is not broken. The last one was given to my mother-in-law at 15pm.

**R360**

Yes, if you meet someone who appreciates it, they will ask me the title of the song. If you don’t appreciate it, just shut up. If you like carpooling, do you want to sit still?

**R366**

It’s not okay for me to be in Tuhe. Fortunately, I don’t sit down, otherwise I would have been uncomfortable all the way.

**R372**

Same

**R378**

Carpooling will use a backup machine

**R384**

Noise canceling headphones 🎧

**R390**

No, after carpooling is connected, the map will be sent to canplay, and the sound quality will be very poor when playing music.

**R396**

Ah, I'm sorry, I just

**R402**

Reply to Gong Xi Fa Cai💰: CarPlay audio is wrong. Only occasionally receive long distance calls. The music was not right during the whole journey and it was very uncomfortable.

**R408**

I turned it off immediately after confirming that I got in the car.

**R414**

Nothing wrong

**R420**

Remember to bring headphones next time

**R426**

Reply to wowo: Yes

**R431**

Reply to wowo: I’m not running specifically, so why bother with the whole backup machine?

**R436**

My playlist has everything

**R441**

Does that sound nice?

**R445**

Reply to Gong Xi Fa Cai💰: I basically don’t answer now. I can’t get it. Many of them are freeloaders. Only when I'm watching a concert across cities, I'll look for it via xhs

**R448**

It can be said that I also like to listen to high-pitched songs while driving. I usually turn the tone down when picking up people.

**R451**

I'm already taking carpooling, so I have to endure it.

**R454**

I can put whatever I want in my car. Last time I took two people from home to Tiantongyuan on the highway. I can’t even play tolls. The messy stuff on my cell phone is really annoying. It affects my driving, so I asked them to keep their voices down. They also chatted with me, saying that I was playing music, which made me laugh. I wanted to play whatever I wanted. I told them to get out and even said they were going to call the police. I couldn't get out of the car, so I stopped on the side of the road and waited for them to call the police. In the end, I bowed my head and admitted my mistake. In the past, people who even tried to get a black car could not even get the driver's call. Now they are carpooling, and they want to be uncles. Haha, it's a habit.

**R457**

I can't let it go, the Japanese style is so noisy

## 3. Carpooling really gave me an emo treatment today😅

Source: https://www.rednote.com/discovery/item/6a915a95000000002902addd
Original record: 20_posts_480_comments / R003
Text scope: Collected post text

As soon as I got in the car, I could smell the smell of garlic. The driver also played the audio aloud of Xu Song's song at a very high volume.
While holding my breath due to the smell of garlic, I listened to the driver humming "Chengfu" and "Suyan"
The little brother sang quite enthusiastically. I wore a mask in the passenger seat and dared not breathe. My soul swayed to the melody and my nose was tortured.
Let’s just say, can you rinse your mouth before driving? Playing audio aloud music can really put people in a funny and painful situation
Throughout the entire journey, I just wanted to reach my destination quickly, and this carpooling experience was truly magical 😂

### Comments

**R022**

Like the driver

**R040**

Got it from carpooling last year

**R057**

Why are you sitting in the passenger seat? My E has been registered for so many years, and occasionally I take a few passengers in the back seat.

**R072**

You can have fun without increasing the price.

**R085**

Carpooling is just as long as the driver is happy, not a premium ride service

**R097**

Reply to a fellow traveler: It’s just black and short skirt, so I won’t accept it.

**R109**

Those who cherish very little, those who leave melon seeds on the ground when walking, those who take off their shoes and socks, those who cross their feet, those who have bad breath

**R120**

Reply to Duoyu mm🐟: It’s embarrassing, but I always take orders that go very smoothly, so it doesn’t matter which destination I want to go to. If someone takes a detour and asks me to pick them up, I just ignore them.

**R130**

I still have to yell at you.

**R140**

It's true that you want to be cheap, but there are always cheap chauffeurs, right? With banana money you can only hire monkeys. This saying also applies to all service industries. Shanghai is a good example recently

**R150**

If you don’t play audio aloud music while driving, you should dismantle the speakers in the car.

**R160**

If you are just doing charity, can you earn back the gas money?

**R170**

Are you unhappy when you encounter real carpooling?

**R180**

Reply to a fellow traveler: Wuhan to Tianjin, more than 1,100 kilometers

**R190**

Is there anyone in the back seat?

**R200**

Jimei

**R210**

There are also passengers who poop on the bus, that one is a god

**R220**

Brother is so confident

**R230**

You are a loader

**R240**

Anyway, now I only accept exclusive rides or shared rides on highway tolls. I don’t accept shared rides that don’t go out of highway tolls. Now it costs 30 cents per kilometer. No matter how I go on the platform, it will take almost an hour longer. It takes an extra 2 to 30 kilometers to run back and forth, plus the cost of gas and time for the extra mile. Just to pick up a 300-kilometer ride for 100 yuan. Isn’t that sick? And generally shared rides that don’t have highway tolls are in trouble!

**R250**

I haven't picked up the passenger seat yet. Although there are very few pick-ups.

**R260**

Reply to Kick the lame man's good leg: If you sleep like this, you are probably exhausted.

**R268**

He was scolded for shouting

**R276**

Just don’t sit downwind. Because it is only responsible for delivering it to you, the driver makes the final decision on everything else, because you are taking his car, and Shunfeng is not the operator.

**R284**

If it doesn't work, just get another one. As long as you have the money, there's nothing you can't do.

**R292**

Reply to kicking the lame man’s good leg: 🈶What’s the problem?

**R300**

So no sense of boundaries? Do normal people sit in the passenger seat when taking a taxi?

**R308**

It should be like this. Carpooling is a bit cheaper. In addition, your private car must be cleaner. Aren’t there many posts complaining about Didi’s car smelling bad?

**R316**

There are so many things to do with a car

**R324**

Just everything

**R331**

Will it affect insurance?

**R337**

Without exception, the Didi passengers I received were all consciously sitting in the back row and didn’t know why. They didn’t dare to say or ask.

**R343**

I met a little girl who took off her shoes as soon as she got in the car, put her feet into the air-conditioning vent, and still farted.

**R349**

The beggar thinks the food is sour

**R355**

You’re already carpooling, why do you still care about so many things?

**R361**

Last time I picked up an old man and the smell was very strong.

**R367**

These pants are one of a kind

**R373**

Whoever came up with this carpooling thing?

**R379**

It’s disgusting. I took pictures and then posted them for people to comment on.

**R385**

Your pants have a retro feel

**R391**

What's going on in today's society? How is it possible to pay 10 yuan for 100 yuan of quality?

**R397**

Wouldn't it be better if you sat in the back seat?

**R403**

Reply to Kick the Cripple’s Good Leg: 1100 kilometers of carpooling? How much did you charge?

**R409**

A group of creatures with only sperm and no brain cells.

**R415**

Although but...if you're already carpooling, don't pick it up. It's essentially an act of civil mutual aid. If you want service, Didi Express premium ride service luxury cars have different service contents.

**R421**

Will answer like this: What are you talking about, what does cherishing have to do with me. I gave the money. If you want to be cherished, don’t accept it. A lowly man who wants to make money but also wants to push him. How is the image?

**R427**

Let’s just say, why not get a premium ride service? It’s not expensive to buy a car.

**R432**

Maybe I didn't meet my co-pilot.

**R437**

I ran out of car fragrance, and a bottle of vintage Dior was thrown into the glove box.

**R442**

Why does he cherish it? He originally wanted to get the value of 5 yuan to enjoy the service and experience of 50 yuan.

**R446**

Don't you guys say hello to me on this floor?

**R449**

If you can find carpooling with music, just have fun.

**R452**

I bought my own car in order to prevent myself from getting a stinky car and to prevent the car owner from playing music I didn’t like. You can also buy one. It’s not illegal to buy a car. Of course, it’s not illegal to complain about someone else’s smelly car while playing songs, but it’s not illegal to treat carpooling as a premium ride service. It’s both illegal and illegal.

**R455**

There are so many things to do when working as a pig cart, but don’t you have to do these things when using a premium ride service? You will make yourself uncomfortable.

**R458**

I want it but I still want it. If I spend the money of a fast hotel, I need five-star service.

**R460**

If you take carpooling, this won’t work and that won’t work. If you take a bus or a train, it’s not that much trouble.

**R462**

I have a problem. When I go out, I always drive or take an express bus. I never do carpooling. I know it’s very cheap. So the question is, does everyone who engages in carpooling want to take advantage of it? Want to buy someone else’s private car at the lowest price, which is clean and smells good? Is this the mentality? My car is clean and smells good. I spray thousands of perfumes in it and wipe it with disinfectant wipes every two days. The question is, will you take care of it when you sit in it?

**R464**

What can I say? I took over ten orders and only one had no body odor. Maybe everyone (including me) has it.

**R466**

Why don't you sit in the back?

## 4. Why am I still not brave enough?

Source: https://www.rednote.com/discovery/item/69ec7d45000000002301e789
Original record: 20_posts_480_comments / R004
Text scope: Collected post text

I did some carpooling when I got home, and I was lucky enough to get it with another person. The driver picked me up after picking me up. Before he got in the car, there was only low-pitched car music, but 10 minutes later this person came with his arrogant and loud playing audio aloud and ultra-high decibel game background sound. The excitement was as if he was about to compete in the e-sports circle as a seed player after getting off the car.
	
I felt uncomfortable, and I had been brewing in my mind for a long time, "Hello, your voice is too loud, could you please lower it?" "Hello, I want to take a break, could you please turn down the volume on your phone?", but I still didn't dare to say it. My mind flashed through countless scenes of sisters who I saw in other posts bravely speaking out, but at the same time, "He looks very strong, will he beat me if he is irritable?" He just said "The driver's address is not far from my home. Will he retaliate against me?" "The driver didn't speak and the driver is also a man. Will he not care or even stand with him?" "The principle of compromise for the happy should be forgotten." These thoughts came up one by one and quickly overwhelmed me. I immediately knocked down the courage I gained from my sisters. I was so cowardly that I didn't even say such a simple and reasonable request until he got off the car.
	
I hate myself for being so weak, but is that my problem? This society makes people afraid to speak out, even if the voice is reasonable and correct. Asking "Can you please lower your voice?" is obviously a common thing and does not require courage to describe it, but before I said it, I thought of many negative cases and social news, and I was scared.
	
I want to be stronger. I can't stand myself like this. On the high-speed train home, I bravely fought with the boy next to me for the right to use the middle armrest. On the subway, I dared to spread my legs and let the man next door pull his legs back. I couldn't do this before. Before, I would only feel uncomfortable and uncomfortable, and then swallow it silently and be forced to accept it. But now I don't want to give up my normal rights and space.
	
So why I "didn't dare" this time, a large part of the reason was the size of the space. Before, it was in public places with many people, such as subways and high-speed trains. I felt that the other party would not mess around in such places. Even if he did, I could at least ask for help (although there were a lot of bad things happening in such places, I would have the most basic psychological sense of security). But at that time, it was only me, him and the driver, two people of the opposite sex, so I backed down.
	
what to do? I don’t know what else I can ask of this society. Maybe many people think this is nothing. Why are you so cowardly? It can be solved with just one sentence. It’s you who think so badly of others. How can you be so smart about it? But obviously I have always believed that there are more kind people in the world. In fact, I believe so now, but I did not do it at the time. I can only say to myself: Be stronger.
Be stronger.
	
# Playing audio aloud #essay #female thinking

### Comments

**R023** (post author)

Reply Dolphin is also getting better today: I’ll go and I’ve left a bad review, but I don’t know if I can still complain. I’ll go check it out again.

**R041** (post author)

As soon as I got off the car, I gave a negative review and blocked the driver because it was difficult for the driver to comment. The destination I wrote was my home. When he arrived at the gate of the community, he took the order and dropped me off. I argued with him and he said that the platform does not allow entry into the community... How could carpooling be allowed in before? If he hadn't directly taken off the suitcase, I had no intention of getting off the car. I just slammed the door and walked away and immediately blocked the negative review. I would have accepted it before.

**R058**

Take photos while on the bus to keep the evidence, and after getting off the bus, complain and report to blackmail the train.

**R073**

Baby, let's take our time

**R086**

When I asked five men who were smoking indoors to go out for the sake of my own health, I felt that I was slowly becoming braver and considered for my own health.

**R098** (post author)

I hope I can get better and better, but many times I hope these people will do what they should do instead of us bearing the consequences of their actions😮‍💨

**R110**

Reply: Rice and sweet potato porridge is super delicious: Remember to complain, you should be able to get a refund, or you can complain again after a few days.

## 5. Gaode carpooling speechless incident

Source: https://www.rednote.com/discovery/item/6aa6967f00000000110356c2
Original record: 20_posts_480_comments / R005
Text scope: Collected post text

I'm really speechless. I took a high-definition private carpooling today. As soon as I got in the car, the driver's family members were sitting in the passenger seat, and a movie was playing loudly in the car.
I remained silent the whole time and didn't offer a single comment.
Later, the driver turned off the movie and switched to playing music, and my companions and I chatted at normal volume. There were other shared ride passengers in the car, and they didn't feel noisy.
As a result, the driver said directly: "We will talk about this beauty if we can go back." 😤
I feel a little offended. If you tell me please keep your voice down, I can totally understand.
But let us go back and talk about it directly, which means that we are not allowed to talk in the car, which sounds very uncomfortable.
I replied directly: You were playing a movie when you got in the car, and I didn’t say anything. After speaking, the driver turned off the music himself.
Carpooling is a carpooling trip, not a library. You can understand each other, but you can't have double standards. You are only allowed to make noise, and passengers are prohibited from talking normally.
I have submitted a complaint on the platform and hope that no one will encounter this situation when traveling.
Have you ever encountered this kind of double standard situation when taking carpooling?
#driver #taxicomment #高德carpooling #行 Lightning Protection

### Comments

**R024**

Reply to Sweet Nini Jiang: The payment is also divided into three, six or nine levels. You get what you pay for. The price of carpooling is only one-fifth of the taxi. There is no service at all. It’s all about safe delivery.

**R042**

Still have to take an express train?

**R059**

Reply to Sweet Nini Jiang: It’s very simple. The money you pay is only enough to get you to your destination, nothing else.

**R074**

Reply to Sweet Nini Jiang: The word "payment" is not appropriate to use here. The platform has stated it, and the law does not recognize that you constitute consumption behavior.

**R087**

Reply to Xiaoxin.: I’m laughing so hard. You’re so eager to blow yourself up. You’re posting a coded screenshot to make people think that you have a part-time job moving bricks on a construction site during the day, so the carpooling platform went bankrupt. Are you going to starve to death if you lose your job of pulling in illegal cars?

**R099** (post author)

oh oh

**R111** (post author)

Reply to Smart Mushroom: Delivery to the destination is a basic obligation, but it does not mean that the car owner can arbitrarily restrict the reasonable behavior of passengers during the journey. Non-interference is the bottom line for both parties, not just passengers.

**R121**

Reply to Xiaoxin.: You're a stinky piece of garbage. You're supposed to install a piece of shit with a salary that's not as high as my provident fund. You should take out your social security tax payment certificate first and then install it. You're a bitch first and you're afraid of being criticized. A stinky machine like you also has a face to pretend to be, Jinnengniang.

**R131**

You also know that it is a private car, and it is indeed the car owner who has the final say. If you don't cooperate, he can let you get off.

**R141** (post author)

Reply to Lone Ranger: Even if you are not a consumer, you still have the freedom to communicate normally. There is no clause in the agreement prohibiting passengers from speaking in a low voice.

**R151**

Can you do carpooling without being greedy for money? How poor do you have to be to let a stranger ride in your car?

**R161**

Hello, Xiaode attaches great importance to your feedback. I have worked hard to privately message Xiaode to provide relevant information. Xiaode will follow up and verify it immediately after receiving it.

**R171** (post author)

Reply to Xiao Hongshu 666BF53F: Oh, I understand, but it does not mean that after paying, you have to unconditionally and unilaterally accommodate the car owner.

**R181**

Reply to Xiao Hongshu 6A92600A: What kind of rubbish are you? You are really making a fuss. You are so rich and I don’t know you are pretending to be a young mother. You can’t even build a car. You are pretending to be your grandma. You are also a school admissions threshold. Do you understand the subway recruitment and admissions? I really don’t understand a lot of things, but I just have a bad mouth.

**R191**

Reply to Xiao Hongshu 6A92600A: Le

**R201**

Reply to Lan Ju Jiu Duan————: A stinky guy who pulls carts and waits on people.

**R211**

Reply to Xiaoxin: If you are so willing to get rid of your salary, who can you bluff with a screenshot with a thick code? Why don't you dare to tell me what your position and income are in China Railway No. 1 Bureau? You don’t want to say that you are the chairman of China Railway First Bureau and carpooling is your hobby, right? Why don’t you pretend to be your dad with a WeChat screenshot that you don’t even dare to send out? Why did you finally ask your grandpa to tell your grandma to work as a laborer on China Railway, but you don’t know how to pretend? What on earth can I post about a crappy company name? Don’t you realize that you can pretend to be just by posting your company name?

**R221**

Carpooling is inherently about mutual convenience. The car owner makes money by carrying passengers along the way, and the passengers pay the fee. Carpooling does not clearly stipulate that passengers cannot talk in the car, right?

**R231**

The driver is still greedy for money. If I were to let the passengers off, the most important thing is to be happy.

**R241**

Reply to Xiao Hongshu 6A92600A: I really don’t know what you are talking about. Are you in such a hurry? Are you talking about it in your heart? I don’t rely on carpooling for a living.

**R251**

You can try the one next door to you. This one is called a driver and passenger. Yours is not called a passenger, but a carpooler.

**R261**

Reply to Xiaoxin.: It’s hard to say whether other people understand carpooling, but you, a stinky car driver, definitely don’t understand. Your old BYD Qin still counts for fuel consumption. A stinky car driver knows how to scream on the Internet. If the carpooling platform is banned today, you will starve to death tomorrow.

**R269**

Reply to Xiaoxin.: What kind of outstanding talents can apply for the job of Jinan subway attendant? You are pretending to be inferior. In Shandong, you are considered a treasure even if you are ignored by dogs. As long as you are not trash, you will not be embarrassed and thrown into this situation.

**R277**

Reply to Xiaoxin.: Junior college students are starting to fantasize again. There are undergraduates in the subway = people like you who are on duty can’t even meet are undergraduates. You don’t think that the technicians and managers of the subway have anything in common with you who can’t even be a low-level on-duty minion? Posting a screenshot of yourself for an interview and then saying that you didn’t go to participate. You have done so many things to slap yourself in the face. Isn’t it interesting to take a bunch of tattered screenshots every day and finally prove that you are trash? As long as the school is not so bad, you know that it is easy to get a good offer when you have just graduated and are a fresh graduate. Big companies will go to the school to recruit, and it is easier for fresh graduates in liberal arts to take the public examination. Only a bad college student like you has no company to apply for on-campus recruitment and cannot meet the academic requirements for the public examination. In the end, you go to social recruitment but are blocked due to the experience requirement of social recruitment. People have dual cards for school recruitment and social recruitment to screen out trash like you.

**R285**

Reply to Sweet Nini Jiang: You can choose to get off the car

**R293**

It's okay, you just took a seat

**R301**

Reply to Sweet Nini Jiang: Carpooling has no passengers, no customers, no consumers, and the platform will not give you an invoice. Carpoolers only.

**R309**

Reply to Xiao Hongshu 6A92600A: First of all, I am born in 2000. Will I starve to death? Are you out of your mind? Why should I starve to death if I don’t have a mortgage or a car loan? Secondly, who moved bricks at the construction site of China Railway No. 1 Bureau? You seem to have a hard time with your brain, so you will talk about it online. Secondly, I will take two orders in 860 days. Do you have trouble with your glasses, or do you accept yourself? What can you do? You can accept the evidence thrown in your face, so go ahead

**R317**

Reply to Xiao Hongshu 6A92600A: You have a broken car and you still take someone else’s car? Carpooling is inherently about reducing costs. You don’t even understand carpooling. I don’t know what you’re talking about.

**R325**

There are no regulations, but the car owner can stipulate it, because the car belongs to the car owner.

**R332**

Reply to Xiao Hongshu 6A92600A: It’s a stinky ride.

**R338**

Reply to Xiao Hongshu 6A92600A: Say I don’t rely on carpooling and then say I work. Say I work and say no. If it doesn’t work, you can find a hospital for treatment. I don’t know anything except oral pleasure or oral pleasure. Every year, the subway announces the recruitment and academic qualifications. If it doesn’t work, let’s go and find out. I am an independent young aunt. You can always scream, right?

**R344**

What, you can also sanction the car owner?

**R350** (post author)

Reply to Believe in the Future 0808: How much you spend is the platform’s pricing, not a reason for car owners to have double standards. There is no need to say such ugly things.

**R356**

Don’t do carpooling. It’s inconvenient and not much cheaper.

**R362**

Reply to Sweet Nini-chan: That’s called a carpooler

**R368** (post author)

It's a paid booking through a platform. Respect goes both ways; you can't set rules only for passengers.

**R374**

Reply to Xiaoxin.: A lousy subway attendant who recruited 120 junior college students went out of his way to brag about it after he failed to pass the exam. Even if he could score 500 points in the college entrance examination and get a third-level bachelor's degree, he wouldn't look down on such a bad job. You actually came out to brag about it with an interview qualification. It really amuses me.

**R380**

Reply to Sweet Nini Jiang: The essence is a game between breach of contract costs and performance benefits. This is the game rule for social operation.

**R386**

everyone

**R392**

Reply to Xiaoxin.: A lousy college student who works as a temporary worker still has the nerve to scream. I’m here to slap trash like you in the face. You probably can’t even touch the threshold of campus recruitment. What kind of trash can treat on-duty workers and temporary workers as precious jobs? I'm really convinced. If it weren't for the Internet, I would never interact with a trash like you. It's really unnecessary for me to talk to trash like you.

**R398** (post author)

That's right

**R404**

Reply to Xiaoxin: If you are not greedy for money, why would you accept carpooling? Letting a stranger sit in your car for 80 yuan shows that you are greedy for money. No matter how valuable other people's money is, it is definitely more valuable than your shabby car. After all, no one else is driving a stranger for money.

**R410**

Next time drive by yourself

**R416**

Reply to Believe in the Future 0808: Can Xiaohongshu be made after a little summer vacation?

**R422**

Much cheaper than taking a taxi normally

## 6. It was the first time that carpooling was so frustrating, and it opened my eyes.

Source: https://www.rednote.com/discovery/item/69c00fc3000000001d01ba7f
Original record: 20_posts_480_comments / R006
Text scope: Collected post text

After getting in the car, I held a work conference call with my colleagues. Wearing headphones throughout the whole process, we communicated calmly, without any noise or playing audio aloud.
After only ten or twenty minutes of playing, the driver suddenly became aggressive and asked me to lower my voice, and I also lowered the volume.
As a result, the whole process only lasted half an hour, and he immediately started to get angry and throw his face:
"Be quiet in the car, go to the service area to make calls, and consider other people's feelings."
I actually laughed.
It's just him, his wife and kids in the car. It's fine for him to play music all the way, but it's not okay for me to wear headphones and talk normally?
What, your car is an exclusive VIP seat in the high-speed rail silent carriage?
Ride-hailing is here to serve passengers, not to be a rule-maker or emotional trainer for me.
Doing work in the car is a productive time for working people. I basically have no tolerance for this. I seriously doubt that I have never been to work. It is recommended not to ride-hailing. It is better to open a silent meditation cabin.
I sincerely recommend that everyone stay away from this kind of extremely emotionally unstable middle-aged male driver.
He gets angry easily, gets angry at others for no reason, and plays double standards.
If we weren't on an elevated highway and there were children in the car, I really would have wanted to argue the case right there and then.
I didn't say a few harsh words from beginning to end, but he was the first to explode and was completely convinced.
When you spend money to ride in a car, you have to look at the driver’s face and work carefully.
With this kind of service attitude and quality, we really don’t want to go out and cause trouble to passengers.
Backhand a complaint.
#driver #carpoolingdriver #malecarpoolingmaster #carpooling #Hangzhoucarpooling

### Comments

**R025**

I'll call the premium ride service next time

**R043**

Reply to me and say you want pancakes: Carpooling is used as premium ride service

**R060**

Self-explosion, please pay more next time and get a premium ride service and no one will say anything to you.

**R075**

Serving your grandma’s legs, you only paid a few dollars to do it, you’re just a freeloader

**R088**

Then use the premium ride service to ensure that no driver will complain about you.

**R100**

Who are these people who regard carpooling as ride-hailing?

**R112**

In the past, every time I went out, even if I brought my large German shepherd home, I would take a shared ride. I would take the dog directly into the car and sit in the back seat. They would fill up the tank with gas and wash the car according to the time set by me. They would pick me up on time. The cars were all BBA gas trucks. The furthest one said they had driven 500 kilometers to pick me up. Seeing that I was carrying luggage, they would definitely carry it into the car for me. Car The owner will no longer fight for people. When I get in the car, he gives me Red Bull and cigarettes, asks me if the temperature is right, treats me to a meal when I go to the service area, and does not let me take out highway tolls that I should not take out. When I am about to get off, he will actively refund the money to me. Every time I refuse, the money should be made by the real car owner. This is carpooling.

**R122** (post author)

Agreed. In my shared ride experience, I met real car owners very rarely, but they were very gentle and did not charge extra. But even if I met a real car owner who came to make money, if the place is remote or the time is not easy to come by, I will understand that it is not easy for workers to make money and pay extra for hard work. Some driver service areas will even help buy food. This time I was really emotional, and I didn’t realize at all that maybe it was the real car owner who took the order, so my emotions suddenly came back...

**R132**

Reply to me and say you want pancakes: The word "it" is super essential

**R142**

What exactly is carpooling? Or online dating? I'm so confused

**R152**

Although carpooling, you are just a carpooler. If you want service, you really need to go for ride-hailing.

**R162**

1. He is not a driver, 2. Carpooling is not ride-hailing, there is no service, 3. You are riding someone else’s car, you need express service or premium ride service.

**R172**

You can only stay quietly when taking carpooling, and no other movements are allowed.

**R182**

It’s good that I didn’t leave you alone. It’s okay to listen to music. Talking all the time is annoying.

**R192**

When will they understand that the relationship between them and the other party is a mutual aid relationship, rather than a consumer relationship where they pay for services. . .

**R202**

What is the ride-hailing of the carpooling platform? Or ride-hailing?

**R212**

Reply to me and say you want pancakes: this one

**R222**

You can only be considered a hitchhiker, not a passenger. Don’t put your position too high.

**R232**

What you mean by carpooling is not ride-hailing.

**R242**

A hitchhiker has no idea? Either it’s money spent or uncle

**R252**

What else do you want from carpooling? You keep talking until it annoys others, why can't people say a few words about you? You need to figure out your position first

## 7. What kind of friends have you met?

Source: https://www.rednote.com/discovery/item/6a97f4f2000000002a02c4e9
Original record: 20_posts_480_comments / R007
Text scope: Collected post text

#How many people are like me?
I made an appointment for dinner, and it was quite cost-effective to take a shared ride during peak hours. But, hey, what kind of luck am I, this is the second time I met a fellow ride-hailer who was open to the public, didn’t I feel conscious about this? I’m really not interested in listening to your skits or short videos... I can’t close my ears... and I don’t have headphones on either😇
It doesn’t matter if there are still people waiting at the site in advance, I can’t open it to the public...
The only time the Angel Fighters got off the bus was when they found out that the finish line was quite close!

### Comments

**R026**

You can ask the other party directly, or you can not fight next time, and you don't communicate, and you want a shared ride. After playing, cursing in a tree hole where no one knows, it would be too dark and crawling.

**R044** (post author)

I said it on the spot when we first met. The second time you see someone of the same sex, express your bad luck. Because I don’t have to be in a hurry and just go for it. In the future, if you consider the issue of probability, then you won’t fight. I'm not sunny either.

## 8. Shared ride riders started watching short dramas as soon as they got on the bus

Source: https://www.rednote.com/discovery/item/6abc5b210000000002012205
Original record: 20_posts_480_comments / R008
Text scope: Collected post text

Can't you wear headphones? I'm so bored. I'm so bored. I'm so bored. I'm so bored. #Tucao #Uncivilized Behavior #CrazyDaily

### Comments

**R027** (post author)

At home, my family swipes the phone, and when taking a taxi, the driver swipes the passengers. When I hear this sound, I really start to feel physical discomfort.

**R045** (post author)

[greet]

**R061**

Deng 唔唔唔唔唔

**R076**

My parents use the phone at home, while eating and sleeping. When I wake up in the middle of the night and turn off their phones one by one, I have a nervous breakdown.

## 9. Next time I take carpooling, ask the master if he wants to listen to music?

Source: https://www.rednote.com/discovery/item/6a7c197800000000080130b3
Original record: 20_posts_480_comments / R009
Text scope: Collected post text

#carpooling TUHI
My ears are so miserable! Finally arrived!

### Comments

**R028** (post author)

Oh my God! I will definitely drive by myself next time
19"
Recognized singing

## 10. I will never do carpooling again

Source: https://www.rednote.com/discovery/item/680dbb83000000001d003032
Original record: 20_posts_480_comments / R010
Text scope: Collected post text

Recently, at the instigation of others, I registered carpoolingcar owner out of curiosity.
Yesterday, I was thinking of placing a order when I went home, and I picked up a male passenger who is 90% of the people on my way home.
Really bad experience
First, this male passenger slammed the car door so hard. I have never been hit so hard in my whole life. I couldn’t help but turn around and tell him, don’t close the door so hard when you get off the car.
The second one really stinks. Even the fragrance couldn't cover up the smell. As a driver, I almost got carsick due to the smell, so I had no choice but to keep three windows open the whole time. After the passengers got off the bus, I drove around for half a circle to catch my breath.
Third, he has been playing Tik Tok so loudly that my music can’t cover up the sound of Tik Tok.
I really won’t poop anymore, and I won’t be curious anymore.
# Commute commute carpooling #车 #小米su7

### Comments

**R029**

I pulled over a couple and waited for them for half an hour, and then waited for them in the service area for another 20 minutes. The man teased the woman all the way, and she lost her temper and cried in the car. I endured it all the way. Later, when the man was lying on the back seat and getting up, he pulled hard on the armrest of the car and broke the armrest. He also said that my armrest was broken. I couldn't bear it and started arguing with them. I really wanted to throw them off at that time, but I didn't want to cause safety problems on the highway.

**R046**

Who would be willing to drive a car and go for a run if life didn’t force them?

**R062**

Reply to red momo: If you have family members traveling with you, it will be displayed. It is wrong to have other passengers on an exclusive ride.

**R077** (post author)

Did I finally compensate you?

**R089**

From now on, just order three people for the exclusive ride, and the price will be the same.

**R101**

Can't stand it any longer

**R113**

Reply to red momo: Choosing the correct number of passengers is a guarantee for both parties.

**R123**

Moreover, they posted shared ride orders, and I only accepted one order from them, which gave them an exclusive ride.

**R133**

Reply to Xiaohongshu user: It’s you who should relearn, thank you

**R143**

Reply to red momo: It’s different

**R153**

Reply to red momo: One person and two people are different. Short distance is about the same and long distance is different.

**R163**

Exclusive ride means that you are not competing with other orders, it does not mean that you are alone.

**R173**

Reply to mo: Having more than one person means having relatives and friends, and it will be marked, but it is wrong to include other passengers.

**R183**

You have to go into the community before being picked up or dropped off.

**R193**

Pull me, I have high quality and want to take a ride in the Brilliant Magenta. I met one on the roundabout last night. It was a young lady driving it.

**R203**

The reply was 700 million: The driver would definitely be wrong if he tried harder.

**R213**

Reply to red momo: Didi’s long-distance exclusive ride for 2 people is more expensive. For exclusive rides over 20 kilometers, I always call the customer first to confirm the number of people. Is it okay for 2 people?

**R223**

Landlord. I just want to say. You need to call and communicate with them before taking the bus. Making a phone call can screen out a large number of unsuitable people. I recommend you call next time. I usually just take my students back, or my mother, etc.

**R233**

Stop answering carpooling, it's very annoying. I once picked up a woman in her 30s and made an appointment at 7 o'clock in the morning. I arrived at his community at 6:50. When I called, the person said that I had just gotten up and asked me to wait for a while, but I ended up waiting for nearly an hour. Then another time, she was also a woman and asked me to pick her up in a small alley. I told her that I couldn’t get in because of my poor skills. She said that everyone else could do it but I couldn’t. I turned around and canceled the order and ran away. I earned him a hundred or two hundred yuan, but it couldn’t cover my gas bill. It was unnecessary.

**R243**

Reply to red momo: Oh oh. This is Hello

**R253**

Xiaomi’s electric car is No. 9

**R262**

Reply to red momo: Didi’s exclusive ride has different prices for one person and two people, although it’s not much different.

**R270**

I am both a La La student and my quality is quite good.

**R278**

Reply to Chao'er: That means she did not select two people for the number of people below her. The system defaults to one person. I probably didn’t notice it, because the price for an exclusive ride is the same for one person and two people.

**R286** (post author)

Fortunately, I stopped answering and we will never meet again.

**R294** (post author)

I actually drove around the city last night

**R302**

It's better if you don't tell the insurance. You can't take a friend home in your own car. You have seat insurance.

**R310**

Reply to red momo: Who told you that the price is different for one person and for two people, and the insurance purchased is also different. If there is an accident, you will cheat the driver.

**R318**

Reply to Beigang: 2 people have never done carpooling and haven’t looked at it carefully.

**R326**

Reply to red momo: Which software are you using? An exclusive ride for one person costs the same as for two people.

**R333**

The reply was 700 million: the prices are different.

**R339**

I pulled it once. Shown is an exclusive ride. When two girls came up, I thought I had seen it wrong.

**R345**

The reply was 700 million: Ah yes, I wanted to say that it’s okay to have more than one passenger.

**R351**

Reply to Chaoer: Both Gaode and Didi

**R357**

Are the two girls okay?

**R363**

su7 you are willing to take it out and pull it out

**R369**

Reply to Hanaru: I asked them to get off the highway and find a repair shop and they would pay for the repair, but they refused. Finally, I asked them to check the price of the parts on Taobao and send it back to me to find someone to repair it myself. I have never seen such a rogue person.

**R375**

Hahahahaha I also took it, 1 person on the exclusive ride, 4 people came up, I still had my own things in the front row, forget it

**R381**

Reply to red momo: No, there is a price difference between Amap and Didi exclusive rides for one person and two people. In addition, insurance is also based on the number of people.

**R387**

Take me to the airport

**R393** (post author)

Don't give up, it's a car

**R399**

How can we ensure that we attract young people?

**R405**

The reply is 700 million: Exclusive ride does not accept shared orders, but multiple people can

**R411**

Reply to red momo: The price of an exclusive ride for 1 person and an exclusive ride for 2 people are different.

**R417**

Reply to red momo: But the software shows one person exclusive ride

**R423**

The reply is 700 million: Go back to the Chinese teacher to learn reading comprehension again

**R428** (post author)

I won't answer the question. It's not worth the effort to spend so few cents.

**R433**

Reply to concroft: Is labor free?

**R438** (post author)

I no longer answer the call, I don’t want to serve you.

## 11. Annoying carpooling passengers

Source: https://www.rednote.com/discovery/item/6a58c7f3000000000f014f86
Original record: 20_posts_480_comments / R011
Text scope: Collected post text

In the past, I always took orders from one person.
Today I unexpectedly picked up a couple of two people.
As a result, we encountered this situation
[Humanly transcribed picture text]
We were carpooling today, and two girls were chatting all the way in the back seat, one after another, hahaha... Can't you take care of the driver's feelings when you're in a car?

### Comments

**R030**

Reply that it is a dog: It’s not that you are cursing, because some people will skip the negotiation step and directly shout fiercely, can you please stop xxxx? It’s annoying to death! Something is wrong! So as long as this is not the case, reasonable negotiation is supported. If you want to be quiet, it will be very uncomfortable if others keep making noises. Don’t hold back and embarrass yourself

**R047**

Not necessarily. I took a taxi and took my friend home. Before my friend got in the car, I told the driver that I would chat with him and don’t say anything for a while. Anyway, after my friend got in the bus, I moved to the back seat to chat with my friend. The driver silently put on the headphones. It doesn’t matter if I spent money or not, but I can’t avoid chatting. Let’s tolerate each other.

**R063** (post author)

I'm the kind of person who will never take orders from multiple people again, and I don't want to say a word to them. I was alone in the front row sighing all the way, and the two of them acted like nothing happened.

**R078**

I just like listening to passengers chatting, but I don’t want to join in ()

**R090**

She felt that she spent money and she needed to enjoy it, she said she was God!

**R102**

I once met a couple who quarreled over the same direction. The man was an idiot. One person got on the exclusive ride but two people got on the bus. I tolerated it for the first order reward. When I got there, I didn’t get off the car. I had to go to the door inside the market. When I got off, I even slammed the door. Carpooling means that the more you deduct, the worse the quality of the person is, and no rebuttal is accepted.

**R114** (post author)

Paying out income is completely disproportionate

**R124**

Reply that it is a dog: You continue to chat with them about autism.

**R134**

I always harass the master when chatting. I don’t speak so loudly with my friends, and I don’t turn on my mobile phone too loudly.

**R144** (post author)

It's not that I would directly curse at someone... I just feel that their chatting would disturb them and I don't want to talk. . . I have been frustrated all the way

**R154** (post author)

Earned a mental damage fee

**R164** (post author)

Reply: I am sick and you have medicine: Yes, yes, friendly communication

**R174** (post author)

Ha ha ha ha

**R184** (post author)

The platform’s mindless bias towards passengers is a big reason

**R194**

When I encounter them, I will remind them and ask them to keep their voices down so as not to affect my ability to listen to the navigation system.

**R204**

Hahaha

**R214**

No service is easy to do

**R224**

You can say it directly, please lower your voice. . You may not notice it if you are chatting with your friends. There is no need to endure the embarrassment and speak directly. It does affect you and negotiate reasonably. Just don't open your mouth to curse people. .

**R234**

Aren’t they all magnetic nowadays?

**R244**

There are more and more weird passengers

**R254** (post author)

Reply to kicking the lame man's good leg: You still have a trick

## 12. Establish a post as evidence

Source: https://www.rednote.com/discovery/item/6acc4c830000000015000d32
Original record: 20_posts_480_comments / R012
Text scope: Collected post text

If I can’t afford carpooling trips with exclusive rides in the future, I won’t take them. It took an hour to pick up another person, forget it, and it hadn’t started yet. The first person I picked up hit it off with the driver, and the more we chatted, the happier I got. I had insomnia yesterday, woke up early in the morning, and only slept for 4 hours. It was so noisy, so noisy, ahhhhhhhhhhhhhhh, crazy, crazy

### Comments

**R031**

Luck is very important for shared rides. Last time I took a bus with students, and one of the students had the same taste in music as me. We had a great time, but luckily they were all classmates.

**R048**

Can't you tell them to be quiet for a while and say that they are sleepy? I feel like this is a problem that can be solved through casual communication.

**R064** (post author)

Sister, when I saw your message, I went to tell the driver. And the driver was also very cooperative. Sometimes when I want to do something, I need someone to encourage me and then I fall asleep until I wake up. Thank you.

## 13. Should the driver also shout "Ten days of hard work to make us bigger and stronger"?

Source: https://www.rednote.com/discovery/item/6ad50d12000000001e027c00
Original record: 20_posts_480_comments / R013
Text scope: Collected post text

#十千天 #妾屋人 #禾青久久 #何浩南 #何浩南青道 # Northeast人 #同干
After the concert, we took a taxi. The driver was from Heilongjiang. He was very interesting. He started chatting with us. He said he had forgotten that there was a concert today, so he took the order from both of us. Originally, he didn’t plan to take the order today and wanted to come directly to the door to solicit customers (very lucky, he happened to be hit by accident). My brother took the order. I thought I couldn’t get a taxi, but as soon as it came out, I got one. My sister really saved us!) Originally, there were only two people in the car, my sister and I. But seeing that it was raining and windy outside, it was too dangerous, so I thought about asking two more people to come up and share with us! ride, I shouted for a long time, but no one wanted to come up to the shared ride. I said, brother, open the window and let me shout. Just outside the window, there were two people walking messily in the wind. I quickly shouted, "He, get on the bus! Shared ride! Get on!" The two of them didn't hesitate at all, as if they saw a savior, they came up immediately. Then the four of us started chatting with our brother. He asked us whose concert it was today. We said it was He Haonan, the oldest member of the Ten Qintians... Then he said that he knew the Ten Qintians, but didn’t know who was in them. We said that you just know the Ten Qintians! Then we started to teach our brother to shout slogans, which made us happy! My Northeastern accent is so fun! The four of us were very excited and high-spirited along the way. We were chattering to my brother about the ten days of hard work. The Hehe people were just going around and enjoying the ten days of work. We were noisy to my brother and asked us to keep our voices down. His ears couldn’t bear it hahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahaha🤣It’s so fun, special thanks to brother for saving the four of us! Otherwise we would be soaked outside!

### Comments

**R032**

This guy is so funny hahahahahaha

**R049**

Hahahahahahaha

**R065**

Hahahaha so happy

**R079**

social terrorist

**R091**

Person E is also Person E’s toy

**R103**

He feels that you have enough physical strength to hold on through the night.

## 14. Terrible carpooling list

Source: https://www.rednote.com/discovery/item/681560130000000022036913
Original record: 20_posts_480_comments / R014
Text scope: Collected post text

I have been commuting to and from work for carpooling for a month, and I have received 11 orders. Basically, I have not accepted any orders that are not particularly convenient. The order I received today was really terrible. The two young guys got in the car and started playing audio aloud on Douyin. It was very loud. This is not the worst thing. The worst thing is that they have body odor and foot odor. ah! ! ! You can smell it even if you open the windows for an hour's drive. Unfortunately, these two guys are quite relaxed. They tilted their heads and fell asleep after playing TikTok. They were also snoring. Even though they were walking along the dilapidated road construction section, they couldn't be shaken awake! #carpooling #commuting carpooling

### Comments

No sampled comments in the supplied dataset.

## 15. Send someone to the airport and work as a Didi carpooling driver on the return trip

Source: https://www.rednote.com/discovery/item/68ba7521000000001c00d04b
Original record: 20_posts_480_comments / R015
Text scope: Collected post text

I won’t do it a second time. After I picked up my aunt, she smelled too much. The smell of sweat and bad breath hit my face. I used a lot of playing audio aloud to scroll through Douyin! Professional ethics endured all the way! Mad Mad Mad!
There are a lot of mosquitoes in the garage and I dare not open the window at night to spread the smell! !

### Comments

**R033**

Spray air freshener

**R050**

After getting off the car, open the window and take a walk. Just bear with it for the money, haha. I took two Xinjiangs and the body odor was a bit strong and I felt like I didn’t want to take a shower. I picked up two old men and took them to the hospital. They smelled like urine. I was short of money and I didn't care.

**R066**

Don't be afraid of being a beauty, just be afraid of being an aunt

## 16. carpooling23August 22

Source: https://www.rednote.com/discovery/item/68a7c246000000001d001243
Original record: 20_posts_480_comments / R016
Text scope: Collected post text

#上海 #carpooling #国产CARpooling #人Looking for carpooling #COMmuting to and from get off work carpooling #松江 #Chedun
[Humanly transcribed picture text]
Page 3: While driving, one of the passengers in the back seat was using Douyin and playing audio aloud at a very high volume. Page 4: The closed car instantly became the center of noise, and I had to step in to stop him: "Please turn down the sound, as this will affect driving." The other party's reaction was not understanding or cooperation, but displeasure and obvious impatience, and eventually he threatened to cancel subsequent charter arrangements.

### Comments

**R034**

Keep your mind at ease and make some money if you have it. It doesn’t matter if you don’t have it. I’m glad that I’m still alive and have a wife and children. How lucky I am.

**R051** (post author)

Life is really a continuous practice. When it comes to my child, I hope that he will insist on doing the right things and reduce internal friction.

## 17. Complaints from a real carpoolingcar owner!

Source: https://www.rednote.com/discovery/item/6a2ee00800000000070265d9
Original record: 20_posts_480_comments / R017
Text scope: Collected post text

I have been carpooling for ten years. When a certain D had an accident in Chengdu, he was taking people to and from get off work. Driving a gas car can really save money. At the peak, he could make 2,000 yuan a month. Now, it is almost 800 yuan in 20 days. They are all taking people to and from get off work, not professional!
1. You are taking carpooling, which is defined by the state as carpooling. I am the car owner and you are the carpooler. Our act of civil mutual assistance is not a transportation service contract! I’m not ride-hailing either!
2. The money you pay is only about half of taking a taxi during the morning and evening peak hours. This is called a reasonable sharing of toll costs. It’s not a service fee, so you won’t get much money!
3. Exclusive ride is not the same as chartering a car. I can have relatives and friends in the car, and I will make a note clearly. If you want to ride alone at the carpooling price, you may not always be able to do so!
4. There is no carpooling service, no luggage is carried, and the trunk is opened and closed by yourself. My obligation is to safely transport you from the starting point to the destination without violating the platform rules. I have the final say in route planning!
5. Those orders of 4 kilometers, 3 people, and 5 yuan, please don’t invite me. I really don’t like it. Even if you refuse, you still want to invite me. Do you think that’s US dollars? Either go find a bus that costs two yuan, or read some books if you can't find one!
6. For orders in the city, I am commuting to and from get off work. If you don’t get more than 90% of the orders, don’t invite me. I’m too lazy to pick you up. Under normal circumstances, I only accept more than 95% of the orders!
7. Don’t make excessive demands. Please take a ride-hailing taxi between the two locations. There is no rule of entering the community or the basement. Please be polite and communicate in case of special weather!
8. Life and work are already very tiring, so don’t make me angry in my car. If you can’t bear it, don’t curse, but I will fight back no matter how angry you are. Anyway, if you don’t violate several major principles, the platform can’t handle me!
9. Don’t think that whoever takes the order will definitely come to pick you up. Everyone has unexpected circumstances that change the itinerary. I often get dropped after running to the starting point. Not only do I have to go home directly, but there are many uncertain factors if I am not an operating vehicle.
10. I don’t have to pay for the ride around the city. If other highways are not necessary, please bear the cost yourself (in the city). After all, if you only pay a few yuan for tolls for 20 yuan or so, you won’t have to worry about it!
11. You must listen to music. If you want to sleep, I can turn it down appropriately, but please be polite. This is not a matter of course. Of course, I will also pause when you call. If I forget, you can remind me!
12. If you have been with the car owner for a long time, you can add a V after the end to make it easier to book a car. This kind of situation is generally more secure after all! However, be sure not to trade offline, otherwise it will be too late to cry after the accident!
13. The price varies depending on the number of people! Don’t think that the exclusive ride you ordered can only accommodate a few people, so I’ll have to ask you to cancel and wait where you are. I’d rather have an empty ride than take you! There is a saying that you can lose both ways, but you can't win alone!
14. Please note your luggage in advance. The car owner’s trunk may not be empty, otherwise you may not be able to get in even when he arrives!
15. If you are bringing a cat or a dog, be sure to note that no matter whether your dog sheds or not, it can get into your bed but it can never get into my car. Don’t wait until it’s close, then I’ll have to let you crawl alone!

### Comments

**R035** (post author)

You'd better pay attention, insurance will deny compensation in case of an accident like this.

**R052**

Four people are more expensive than one

**R067**

My co-pilot always keeps my camera bag, so he only picks up 1-2 people for the exclusive ride.

**R080** (post author)

Hahaha, I've never been more than ten minutes late.

**R092** (post author)

Just make the agreement you made above and make it clear in advance that you are an old man and in good health. Then ask if he is the real car owner and if he also accepts orders through other platforms!

**R104** (post author)

Really a car owner, I really don’t know how to do it. I was very happy to meet someone who took full responsibility for the highway tolls. It meant that he hardly paid for this trip.

**R115**

I take at most two people on an exclusive ride at a time, and I rule out three or four at a glance.

**R125** (post author)

Thanks, I feel like I haven’t finished writing this yet

**R135**

Real car owners won't take four people for an exclusive ride. The most I can do in the car is two people in the back. No seats allowed in the front row.

**R145**

I’ll give you a stupid reply: So under normal circumstances, the car owner picked up two passengers, and the fare should be three fares. I was in a hurry at the time, so I didn’t argue with him.

**R155**

I'm not refuting the main package, I'm just stating my opinion, nothing else.

**R165** (post author)

Reply to Lilithv04: Yes, I usually only post three positions.

**R175**

Reply to Laqi Miyitian: No matter whether you have relatives or friends, you can pick up two at most

**R185**

You can choose the number of people on the exclusive ride, that is, you can't write an exclusive ride for 1 person, and then how many people come on

**R195**

I'm not a professional. I won't click on four people like you when I see them.

**R205**

Reply to the monk who doesn’t want to listen to the chanting: Yes, me too.

**R215**

Who will take this "exclusive ride" for four people? Anyway, I don’t even take the pure tram – the per capita unit price per kilometer is as low as 2 cents.

**R225**

As a passenger, I have to say two things.

**R235**

Excuse me, I once took a carpooling ride. There was no one else except me, so the highway tolls master shared the fare with me. Then another time, there was another passenger besides me. The master said, you two share a carpooling position. This is the rule on Didi carpooling. What I mean is that there shouldn’t be three people sharing a carpooling position. If the master said you don’t understand, don’t come out for carpooling.

**R245**

Here’s a quick reply to you: After reading your article, I think I’m a perfect fit for a car owner like you, and I can do it all. In fact, it can be done and both parties will be very comfortable.

**R255**

Real carpoolingcar owners don’t accept this kind of thing

**R263**

There is an option for highway tolls. You can choose to share the highway equally, or bear part of the highway tolls. This way the order will be accepted quickly, or you can not bear the highway tolls. Those who do not bear the highway tolls are particularly convenient. Anyway, he will go back without dragging you and will not care about it.

**R271**

I only give two seats when I send them, and the co-pilot doesn’t want to give them to passers-by.

**R279**

Basically don’t watch more than 2

**R287**

I don't dare to accept it when I see this

**R295**

I'm most afraid of the four-person exclusive ride.

**R303**

The four of us were really only picked up by professional carpooling drivers. I really couldn’t stand the crowds in my car.

**R311**

Exclusive ride real car owners generally accept up to 2 people

**R319**

Real car owners are scared to see it. Pulling a car full of people would scare someone to death.

**R327**

For exclusive rides, I usually write four people, so that the driver doesn’t have any so-called relatives or friends.

**R334** (post author)

Reply to Jinfanz baby💜💜: Hahahaha, the location is Chengdu, come and make an appointment. In fact, carpooling has great advantages for you. I have met several commuters who would rather pay extra than take an express train! Because it is cheaper to pay extra than express trains, and the key is that there is no smell or dust in the car, and the hygiene of private cars is very clean. For example, I wash my car twice a month. I have a few towels in the car, foam detergent, and a small vacuum cleaner. . .

**R340**

Real carpooling master, if you see more than 2 people, you will not pick up the call, no matter how much money you have.

**R346** (post author)

It saves car costs, but it doesn’t serve people!

**R352**

I'll only post two locations. You'll most likely not be able to get a ride from a real car owner.

**R358**

Reply to PaperEagle丨Jiangsu, Zhejiang and Shanghai travel airport pick-up: That is, suppose I am the only one picked up, and I choose to share the highway tolls equally. In this case, the person will use the car and the highway tolls will be used. I am not arguing, but I don’t understand the specific regulations here. At that time, the master told me that when I received a driver, I received a booth, and when I received two drivers, I didn’t wait.

**R364**

When I see four people taking an exclusive ride, I won’t accept it at all, even if I’m 100% on board.

**R370**

I know I'm poor, so I never make carpooling trips. I get in the car alone and carry my luggage. I also bear all the highway tolls myself. I just ask the driver not to take long detours to pick up others when I take an exclusive ride.

**R376**

So how many people are needed for a carpoolingexclusive ride? If one is not enough, I might as well choose a shared ride.

**R382**

Only professional people will accept this kind of service. We are really afraid of carpooling car owners and would not consider accepting it at all.

**R388**

Very comprehensive and well said!

**R394**

Reply to momo: Master, a few people are riding together; Master, it’s so hot and turn on the air conditioner; Master, it’s still a long time to wait before leaving; Master, I took an exclusive ride, why are there other people in the car; Master, please hurry up, I’m in a hurry; Master, I’ve been on the bus for so long and I still haven’t arrived (classic quotation)

**R400**

Even if I don’t have any friends or family, I don’t want to overcrowd the car. So I won’t bring it if I see this kind of thing.

**R406**

I take my wife with me to and from get off work, and I will also make notes.

**R412**

I just want to say...can you come on time? I'm an hour and a half late. Just be late. Can you call me and tell me what time you'll pick me up... It's really depressing to be outside in the sun for an hour and a half on such a hot day.

**R418** (post author)

This way you will also exclude some real car owners who bring a family member with them.

**R424**

Curious, then why do you insist on carpooling? I once thought about registering, but I thought it would be too troublesome and I didn’t need the few dollars.

**R429**

I plan to arrange a carpooling, exclusive ride with my elders on the highway across the city. Highway tolls can be afforded. You can pay extra. The clothes are clean and smoke-free, there is no clutter, and I have a small suitcase and a backpack. Will it be considered an annoyance to an elderly person or will the other driver cancel the trip at short notice? Since I have never used carpooling, what should I pay attention to? What was agreed upon?

**R434**

I work part-time at night to run two rides. Even a professional ride-hailing driver doesn’t want to pick them up. It’s only 70 cents per kilometer, so I have to travel several kilometers to pick them up, and I’m doing an exclusive ride alone.

**R439**

Reply: Your understanding is correct. Carpooling is done by people along the way, either by the way or full-time.

**R443**

I once carpooled a real private car owner with a gasoline car. In my personal opinion, carpooling should be banned and let professionals do professional work (operating cars). To put it bluntly, carpooling is the involution of the bottom layer and will kill the ride-hailing market.

## 18. I’m annoyed by people talking loudly on the phone on shared rides

Source: https://www.rednote.com/discovery/item/66f157ce000000002c02cc37
Original record: 20_posts_480_comments / R018
Text scope: Collected post text

I'm annoyed by the people who talk on the phone in shared rides. They talk loudly and talk all the time. If it's just a meeting to talk about something, I understand as a fellow worker, but it's just chatting. I'm sorry for not being used to it. Who wants to know the trivial details of your company? Today I told her to hang up quickly. She also said that the sound was heard when she opened the window. Sister, why don't you stick your head out. You actually have the nerve to say that you are like this every day. That's because you were lucky enough to have a good temper before. I'm sorry for you, I can't bear it. You know how to keep your voice down on the high-speed rail, but not on shared rides. If you have the ability, use the premium ride service. The master probably annoyed her too, so I told her to keep her voice down after I finished speaking.

### Comments

**R036**

Shared ride, there are other passengers in the car, this is considered a public place, the loud beeping all the way is really annoying.

**R053** (post author)

The driver brother is really: #%*^$&

**R068**

Talking about work was incomprehensible. The two women next to me kept chatting about office gossip from the moment they got on the bus to the moment they got off. My head was buzzing like a fly.

**R081** (post author)

Thank you for your hard work. It's even harder for you. As a driver, you can't have an attack.

**R093** (post author)

Driver: My mind is buzzing

**R105**

Didi shared ride and picked up a weird girl. I got on the bus and saw her sitting in the car, reading a manuscript loudly on her mobile phone. At first I thought she was answering the phone and reading to a friend, but later I found out that she was reading it to herself, very loudly. I couldn't stand it anymore, so I asked her if she could stop reading so loudly. After all, it was a public space and it affected me. Then the girl said that there was no way to read the manuscript she was writing. Wasn't it called shared ride? I asked if I could keep my voice down. It’s not like you can disturb others on a shared ride. I’ve never seen you like this on a shared ride. Then she said I’ll see you today. I replied that it’s really weird. There are all kinds of people. I didn’t want to argue, but it was too loud to be exaggerated, so I turned on Douyin and turned it to the loudest until she got off the car. It was a hard-working driver.

**R116**

It’s really annoying. Who wants to hear gossip about family life? A long-tongued woman.

**R126**

I'm going through this, a college entrance examination repeater doesn't know if she talks so loudly on the phone to her friends because she's afraid that others won't know she's a repeater? Are you proud? I don’t understand.

**R136** (post author)

Hug, I understand your pain

**R146** (post author)

There are too many enemies, so let’s strategically tolerate it first, alas.

**R156**

I am also going through the qualification review. I am already tired. I am sitting in the back seat. The two girls next to me know each other and keep chatting. The sound is loud and the driver plays music. It is really annoying. Ride-hailing is also a public space. It’s really rude to keep chatting loudly. I just want to ride in the car quietly.

**R166**

I was really speechless. I took a test today and picked up a few people. Then as soon as I got in the car, I started chatting non-stop. I didn’t stop for a moment. I thought they would calm down for a while after the test, but they kept talking non-stop. They also started to discuss the issue of not liking other people’s posts on WeChat Moments. Whether others posted or not did not matter to her, and they kept commenting there. I was really speechless.

**R176**

I encountered the same situation and I don’t know how to complain. It’s really annoying.

**R186**

The two women next to me never stopped talking, and the man behind me was talking so dryly.

**R196**

I'm going through it. Another woman kept talking on the phone. . I got car sick and tried to squint in the car, but I was so noisy that I died.

**R206** (post author)

Reply to Celine Song: Some people are really unconscious

**R216**

Me too, I'm still on a long car ride, I'm going to vomit on the car

**R226**

The person next to me kept talking, and the woman’s voice was even louder.

**R236** (post author)

Alas, I understand you very much. Some people don’t understand that shared rides are also public transportation.

**R246** (post author)

I know you, this reflects the importance of noise-canceling headphones

**R256**

I am also experiencing this. Everyone except me is an acquaintance, especially a fifty-year-old woman. She chatted in a bunch of dialects that were so unpleasant that we had a quarrel all the way.

**R264** (post author)

You have too many opponents, so it’s not easy to get angry.

**R272**

I worked overtime until ten o'clock and was so tired that I just wanted to go home quietly, using Didi Minibus. A woman got in the car and started to make a video call to the person she was interested in, playing audio aloud. It was so loud, probably Yin Yang. It was so sweet for this man to go on a date with someone else to watch a movie. She also said that I would like to give you a song "Sweet Sweet", and then she actually sang "Sweet Sweet" into her phone. Damn it, did Didi minibus torture me like this? I looked back and signaled with my eyes to lower my voice, but the girl was indifferent. There was nothing I could do. I opened the Douyin Cloud House Flower Live Room on the spot, and the high-pitched BGM and oral broadcasts were turned to the maximum. I'm sorry, but I also find it too noisy. The driver (who looked like a novice and didn’t know the way very well) pitifully said to me: Girl, please keep your voice down, I can’t hear the navigation anymore. I couldn't help but laugh out loud. The driver's head is so big

**R280**

Now I'm experiencing it on the highway. The driver chatted with her all the way. I want to sleep, but it's not quiet, and it's very loud. I'm really having a bipolar episode.

**R288**

Reply to Tao Xingyu: And they are all in the same group

**R296** (post author)

What you said is even scarier, it’s so disgusting

**R304**

Reply to Tao Xingyu: It really makes me speechless

**R312**

I am experiencing two men and two women. I don’t know if they are lovers. I am the co-pilot. Two women are chattering behind me. Two men are chattering behind me. I am really drunk. I am afraid that others cannot hear me. I just want to see if there are the same people online. I really want to shut up.

**R320**

I'm annoyed too, but what's even more annoying is the sound of people picking their noses and throwing things around in the car.

**R328**

Reply to Tao Xingyu: Yes, I feel sorry for the driver, but this fellow driver is really awesome.

## 19. Is sharing a ride with others and talking on the phone all the time in the car considered unqualified?

Source: https://www.rednote.com/discovery/item/66dd85470000000027003ada
Original record: 20_posts_480_comments / R019
Text scope: Collected post text

I took a shared ride after get off work, a shared ride for three people.
.
One of them started making work calls one after another as soon as he got in the car. Throughout the car, with the air conditioner on and the windows closed, her voice was in my ears, talking endlessly. You are quite tired after working all day. If you want to work overtime, do you have to work overtime at work, or go home alone in a car? My head feels so swollen😣
.
Sometimes I see the noisy children on the train and the plane, which makes the passengers disgusted. The parents say, the children are young, can't you be considerate? There are no videos of children talking in your home. To be honest, some regulations in public places do not require much explanation. It is clear at a glance whether you have considered others in public places.
.
If a child just barks accidentally or hits the back of a chair without knowing the severity, who will say anything. If the person on the shared ride car just made a phone call to briefly explain something, I would be considerate. But if you can’t understand public places and feel that the public places you are in are private spaces, it’s almost meaningless.
.
Want to hear what everyone thinks. On the way to get off work, I was a little annoyed 😡
.
# Commute to get off work carpooling #carpoolingexperience sharing #COMmuting to get off work @ Potato Captain

### Comments

**R037**

I'm experiencing it right now. Even a college entrance examination repeater doesn't know how easy it is to show off by speaking so loudly.

**R054**

Even got beaten up

**R069** (post author)

It's her who should take a taxi alone

**R082**

I'm in the car right now, and this woman seems to be a chatterbox. She keeps talking about her family's bad things, and she doesn't stop talking. She's not an ordinary irritant.

**R094**

I'm going through this, it's so noisy, the man next to me keeps talking on the phone

**R106**

Current status➕1

**R117**

I’ve been fighting for an hour and I’m going to collapse😫
13"

**R127**

Normally in this case, I would complain directly to Pinyou

**R137**

I am now

**R147**

Hello, this trick won't work.

**R157**

are experiencing

**R167**

Reply to Xiaochu: Complaints to Pinyou will also receive calls from Didi customer service and they will be speechless... They say they will provide education and warnings, but I don’t know if it is true.

**R177**

I'm going through this, it's so noisy

**R187**

Me too, damn it, so disgusting

**R197**

Of course, it counts. You only need to talk for a few minutes to answer the phone normally. She was on the phone for the whole 40 minutes. As a complete stranger, she was forced to listen to her talk all the way. Her voice was not pleasant, and she sometimes made sharp cracks, making her smile tremble.

**R207**

It is, it is, it is! What is there to talk about for so long? ! ! a car. Four people are forced to listen to them talking about love. It's really annoying for such a love-minded couple.

**R217**

I'm in the car right now, and there's a woman who keeps talking on the phone. It's annoying me to death. She's been talking on the phone since I got in the car.

**R227**

I’m going through this, so noisy🥴

**R237**

Me too, I’m so annoyed, and my voice sounds like a female version of Donald Duck, loud

**R247**

I encountered it and was speechless.

**R257**

I just met a man and woman who kept making noise. Then I said you should take a break.

**R265**

Well, I just yelled at the female passenger who was late on the bus and kept talking on the phone, saying that no one wants to hear about your family's petty behavior all the time. She also said that I shouldn't take the shared ride because of my request.

**R273**

Me too

**R281**

+1, it’s so annoying. As soon as I get on the expressway, the person next to me starts talking on the phone, talking and talking about her kid playing with the tablet all the time, and grandma doesn’t care about anything. It’s so annoying.

**R289**

I'm encountering this. I'm so annoyed. Come to Xiaohongshu to read it.

**R297**

I'm experiencing this right now. I wanted to sleep, but she's been talking on the phone for over twenty minutes and is still going.

**R305**

Is it useful?

**R313**

That's why I searched

**R321**

It's so noisy and annoying

## 20. Do you play loud music when carpooling?

Source: https://www.rednote.com/discovery/item/69f72785000000003502b893
Original record: 20_posts_480_comments / R020
Text scope: Collected post text

I have the habit of listening to music while driving. I didn’t dare to play music loudly while carpooling a few times, so I listened quietly, which was not fun enough.
As a car owner, would you consider whether carpooling passengers like it?
As a passenger, would you mind if the car owner plays music loudly? # Listen to songs in the car #Singing while driving #carpooling

### Comments

**R038**

Reply to Jinyibuyexing: Hello

**R055**

Reply to Gu Meng He Gui: Can Didi make this note?

**R070**

Reply to Gu Meng He Gui: If you don’t accept highway tolls to play songs, I will accept it hahaha

**R083**

Reply to QQQi: How to change Bluetooth?

**R095**

Didi accepts orders in the same way as playing audio aloud on a mobile phone, so I exited the backend directly after getting on the bus. After exiting, Didi often called to confirm whether the passengers had boarded the bus or even chatted with the passengers.

**R107**

I took orders three times. I don't care. I still sang. But one of the passengers even sang with me.

**R118**

Drive directly to KTV to continue

**R128**

Reply to Gu Meng He Gui: Hahahaha.

**R138** (post author)

that's great

**R148**

Take it or leave it. It's my car—can't I listen to music?

**R158**

Reply to Beanbao: Didi monitored the whole process after the passenger got on the bus. I kept chatting with the passenger on the way, talking about her boyfriend’s family, work and private life. Didi kept reminding me not to chat with the passenger.

**R168**

Then you definitely don’t need Didi.

**R178**

Reply to I am Big Fat (PinDou version): Yes

**R188**

I always use Didi on Android because I also found that it affected the sound of my CarPlay.

**R198**

Reply to momo: It is not recommended to drag people along with your dog, as it is not good for the dog. [Smirk R]

**R208**

I agree so much

**R218**

Reply to Gu Meng He Gui: Same, I usually pick up one, I don’t want to take a detour to pick up so many

**R228**

Reply to Gu Meng He Gui: Mine

**R238**

Reply to Gu Meng He Gui: Is this hello? I always lose in PK, I lose in all this kind of games

**R248**

An old car like mine only has Bluetooth, but I don’t have this problem.

**R258**

Yes, it feels good to hear them say nice things.

**R266**

Do you only accept exclusive rides?

**R274**

Reply to Brother Xia who can’t wake up: If you try to attract people, I won’t sing along at most

**R282**

Once I invited three girls to sing with me. I also turned on the KTV mode, which was very fun.

**R290**

Reply to Gu Meng He Gui: Yes, so I will take one

**R298**

Pick me up next time, I want to listen to music

**R306**

Last time, I was asked by passengers why I didn’t continue to let them go. . . Because my phone ran out of battery and I didn’t dare to use it anymore.

**R314**

When Didi is in the background, the sound effect becomes extremely bad. How to fix it?

**R322**

Two mobile phones, one to take orders and one to play songs via Bluetooth

**R329**

After picking up the person and confirming it, just exit the software directly.

**R335**

Passengers be like

**R341**

Reply to powder: Haha, yes, long distance is really boring. I haven’t even paid tolls. I just have someone to chat with me.

**R347**

Reply to Xiao Q1122: When I go to KTV, I only sing and don’t drink because I don’t know how to drink.

**R353**

Reply to I am a big fat guy (pindou version): The exclusive ride is only 6-7 cents now, so I only pick it up along the way.

**R359**

Reply if: Is one person willing to fight alone?

**R365**

Reply to I am a big fat person (Pin Dou version): If there is another person who cannot be picked up alive or dead, there is no insurance. If something happens, I will pay for it myself.

**R371**

Reply to Mingmen Hand-painted🎨: Hahahaha, it makes sense! No wonder I have no friends. This is how emotional friends come. Let’s go, let’s go, who’s going to drink?

**R377**

That was great. I took a few orders before just so I could have someone to chat with while driving, but everyone got in the car and made faces and said nothing. Then I stopped taking orders.

**R383**

Can only use two mobile phones

**R389**

Reply: The world is so nice: I can’t turn it off and I keep calling. It’s very annoying.

**R395**

You can turn Didi Navigation into AutoNavi, you can try it

**R401**

Reply to KianWang Space Design: Changing carplay to bluetooth, I always do the same

**R407**

I also saw one in two days. I opened the window and told me that my dog ​​wanted to open the window to smell the smell (not open on the highway). The first time I opened the window, it was too cold. The second time I said it was too noisy, I was cowardly. I turned it off silently, but I don’t know if it was my problem or his (I only opened the passenger window, he was sitting behind me).

**R413**

Reply to moon: Ah, why

**R419**

Reply to Tuxi: If pk loses, the completion rate is not as good as the opponent’s

**R425**

Reply The sky is blue: Wait until I go to Hunan

**R430**

Don't let me play a song. I'll throw him down and let him get used to it

**R435**

right! So I just exited the app, and finally Didi warned me.

**R440**

Reply to I am a big fat guy (pindou version): I only bring one

**R444**

It's because Didi has been recording. The currently known solution is to use another mobile phone to open Didi.

**R447**

I listened to me, and most of the passengers said they liked it.

**R450**

If you write like this, you will be targeted by professional passengers.

**R453**

Reply: The world is so wonderful: Turn off the background and warn, there are restrictions

**R456**

Reply to Pipi Pig: OK, I’ll try it later, thanks

**R459**

Reply to Love to Eat Mango Rice🐰: I'm okay. My dog ​​is a puppy and likes to sit in the passenger seat. She doesn't want to sit in the back. She usually takes 1-2 people with her, so it doesn't have any impact.

**R461**

Change your phone

**R463**

I especially like to be a regular carpooler because the quality of the cars suits my taste and the car audio is also good hahaha

**R465**

I use bluetooth dsp for audio and car play for navigation.

**R467**

Then I wrote down my driving habits on a signature

**R468**

Reply 123: I don’t use Didi carpooling

**R469**

Yes, if you don’t sit down, I’ll run away. If you don’t let me play music, don’t sit down.

**R470**

No solution, use two mobile phones

**R471**

I think so too. I will play whatever I play as usual. Unless the person answers the phone, I will turn down the volume.

**R472**

Reply to Ganymede: My own dog and I am a carpooling driver

**R473**

Buy an sd card to play music without connecting it to your phone

**R474**

Reply to the work dog poop shoveling official prodigal cream (the pet model at the top of the homepage is connected to the shooting version):

**R475**

Directly switch to another mobile phone and connect Didi

**R476**

Reply if: What if someone comes again?

**R477**

Two mobile phones

**R478** (post author)

Reply to Yiangyang: Sometimes I can’t help it

**R479**

Reply to KianWang Space Design: Turn off the recording permission

**R480**

Reply to momo: Huh? If you have a dog, don’t even think about getting into my car!

**R481**

Let it go, I just feel comfortable. The pick-up and drop-off is 190 kilometers, 60 yuan, and I won’t accept the order next time.

**R482**

Reply to KianWang Space Design: Carplay is disconnected, just change Bluetooth to connect to the car.

**R483**

Reply to Dudu: It will be too troublesome after I stop answering.

**R484**

Reply to The Sky Is Blue: And I didn’t bother to pick up the ones that were not easily accessible. It was too roundabout. I used to pick up more than one, and it took more than three hours to get home.

**R485**

Reply to Ganymede: ...you ignored a question I asked before pulling people in? Agreed, I'm pulling OK? Also, I don’t increase fares. Even if I’m a passenger on a gas truck, I’ll only take 1 or 2 at most, so many passengers like my car very much.

**R486**

Reply to Gu Meng He Gui: I received a total of 4 orders, PK is not friendly to newcomers

**R487**

Let it go, the car is my own, and I am just taking people with me.

**R488** (post author)

Reply to momo: Hahaha, what he said is that it is not good for dogs. My dog ​​can only sit in the passenger seat, and he will look around in the back seat without anyone.

**R489**

Reply to Xiao Hongshu 686347CE: Hahahaha

**R490**

If you don’t take orders frequently, you can take turns taking orders from several platforms, log out after taking one, and reopen carpooling after 30 days, and new users will be rewarded with at least 50 yuan. There are five or six platforms that can accept orders. If you receive five or six orders a month, there will be rewards for newcomers. It’s better than being killed by the platform

**R491**

I have two mobile phones. I always feel that the central control screen is too low and it is inconvenient to see the navigation.

**R492**

Reply to Xiao Q1122: It’s fun to come to Hunan because of its broad scope.

**R493**

Reply to Gu Meng He Gui: @ Dan’s Notepad You have to make one too

**R494**

Carplay is just like this, it connects directly to the car via Bluetooth, no need for carplay projection

**R495** (post author)

That's it haha

**R496**

Exit Didi directly. Love warnings but not warnings.

**R497**

The setting that requires you to open the app during the whole process is so rubbish. If you close the app, it will keep calling you.

**R498**

Use two phones

**R499**

Reply The sky is blue: Which platform is this? You can also write a signature. I also want to write a note on the Didi platform.

**R500**

For two days in a row, I've had carpool drivers blast music at an incredibly loud volume. It's so noisy. I was already exhausted early in the morning and couldn't even get a little sleep. Both drivers did the same thing. I couldn't stand it anymore and blocked them.

## 21. It's hard to describe what I encountered when I met a female carpooling driver. . .

Source: https://www.rednote.com/discovery/item/6a75d337000000002800999a
Original record: 50_posts_1000_comments / N01
Text scope: Visible excerpt in source dataset

1/2
It's hard to describe what I encountered when I met a female carpooling driver. . .
For several months in a row, I used carpooling as a cheap version of taking a taxi. I spent an average of more than 1,000 on carpooling every month, which allowed me to meet all kinds of drivers. Most of them work full-time. Some may not admit it, but it can be seen from the number of orders they receive. Some of them were middle-aged and unemployed, driving around in a top-of-the-line Krypton 001 that they bought for more than 400,000 yuan at the time. There were also some who failed in business and became dishonest people who could not do anything else. They borrowed tens of thousands from someone to buy a second-hand tram and run it. Some of them came to my house early in the morning in order to receive my "long-distance order" of less than 100 kilometers, and stayed in the car overnight waiting for me to get up and set off. Everyone was working hard to survive. . . Today's driver is an older lady. This is the first time I have met a female driver. Her tone is gentle. She was delayed for a few minutes on the way here because she took the wrong route. She even called me to apologize. As soon as I got in the car, I smelled a strong smell of medicine. There were bottles and cans of colorful medicine in the boxes on the armrest box. Then I saw the child sitting in front of the passenger seat. On such a hot day, the air conditioning temperature in the car was not low, but the child was wrapped in a thick quilt. The eldest sister drove very seriously, her hands never left the steering wheel, and her eyes were always staring ahead. Perhaps she was not very skilled. She always looked several times at each intersection before daring to slowly merge onto the main road. The usually one-and-a-half-hour journey took almost two hours to arrive. Maybe it was the only thing she could find that could take care of her children. It's a job that can make money again. Thinking of this, my nose felt sore. God gave me a heart to pity all living beings, but did not give me the ability to save all living beings. But then I thought about it, what qualifications do I have to pity others, my own life is also a piece of cake.
08-07

### Comments

**C0001** (post author)

yes. . . More and more jobs are being replaced

**C0047**

I am a gas truck driver. Can I go to Didi to make some pocket money after get off work?

**C0089**

Awesome kind girl. Everything goes well.

**C0129**

Most of the time, I still don’t want to meet female drivers. Except for some who look like veterans who have been watching ride-hailing for many years, some of them do drive a bit slowly, and the up and down peaks make people anxious.

**C0168**

ModelY loses RMB 40,000 every year, not to mention other brands

**C0207**

If you calculate it this way, the 60 yuan and 45 yuan for this trip is more than half the price. Although most of them are full-time now, the original intention of carpooling is to share some gas expenses along the way. It does not allow you to not only cover all the expenses but also make money.

**C0243**

If you get into a very slow car, sister, you can tell yourself that the only purpose of taking a car is to reach your destination safely. Think about your family, children and precious body. Everything is more important than time. If you get into a very fast car, I will be afraid. The older I get, the more I feel that my time is worthless, and my safety is the most valuable.

**C0278**

My old oil car costs 1 yuan per kilometer

**C0313**

The 400,000 top comes with 001 Laojiao free charging, carpooling is pure profit, hahahaha

**C0348**

When I saw the title, I thought the female driver was in a bad mood. I was speechless.

**C0383**

Real carpooling master. They pick up regular passengers on their way to and from get off work from Monday to Friday. They both sold their cars and went to work on the weekends to pick up passengers if they came along.

**C0418**

Will taking occasional orders affect my insurance?

**C0452**

The oil trucks are really helping each other, they don’t expect to earn a little bit.

**C0486**

Reply to JOHNNY: For urban areas, lower the speed on the highway!

**C0520** (post author)

Around 100 up and down

**C0554**

Battery, I only trust Huawei’s giant whale

**C0587**

Some people who have been running for a long time don't care about this commission. They are worried that their accounts will be banned if the platform finds out. However, the platform does have enough shortcomings.

**C0619**

The cost of premium ride service is high and it will be scrapped after eight years.

**C0651**

It doesn't matter if it's hard work, I'll work hard in the bank. I graduated in finance and couldn't find it in a bank. I finally managed to get a connection to go to a foreign-funded guarantee company and my place was snatched away. Don't listen to the naked words on the Internet. If you don't have the resources, your words will turn into garbage.

**C0683**

Tram?

**C0715**

Those with criminal records cannot register for carpooling

**C0746**

If it were me, I might choose a private transaction and not let her use the platform, so that I can make more money.

**C0777**

In order to receive my "long-distance order" of less than 100 kilometers, someone arrived near my home early in the morning one day in advance and stayed in the car overnight waiting for me to get up and set off. Is this true?

**C0808**

You took a carpooling service. If you are in a hurry, I suggest you take a premium ride service.

**C0839**

Oh, even full-time drivers don't do as many trips as you.

**C0870** (post author)

No, it originally just describes something complicated and full of twists and turns.

**C0901**

Reply to 我的猫猫叫招财: That won't work. Making a living would be far too hard.

**C0932**

I've felt that warmth too. People in all kinds of jobs are working hard to get by; those at the bottom have to be the most deferential. It reminds me of working flat out in a bank lobby while customers complained about waiting. There are only sixty minutes in an hour, and dozens of customers needing answers—someone will always wait longer. Meanwhile, I'd gone two hours without sitting down or drinking any water.

**C0963**

This is the first carpooling post I've seen on Xiaohongshu that shows compassion for others. Carpool drivers are at the bottom of the driving-for-income ladder, and many really are struggling.

**C0994**

Sure. Society needs more selfless volunteers like that.

## 22. If you have never experienced hardship or anger, I suggest you try carpooling😊

Source: https://www.rednote.com/discovery/item/6a18122500000000080016ab
Original record: 50_posts_1000_comments / N02
Text scope: Visible excerpt in source dataset

00:03 / 05:21
If you have never experienced hardship or anger, I suggest you try carpooling😊
Edited on 07-01

### Comments

**C0002**

Reply to Butterfly: And I usually only wait for orders in university towns or apartments like that. If I call in advance, the man will not answer.

**C0048**

If you took an exclusive ride and took three shared rides, it’s the driver’s problem. If it’s the driver’s own home, it’s fine.

**C0090**

Of course it’s low for people who specialize in “carpooling”, it’s just as low as it needs to be

**C0130**

I booked an exclusive ride once, and there were three people on it. Damn, I deleted it after I complained.

**C0169**

Because I am an appointment ticket, I thought I would take the subway if I couldn’t get there. So what would you do if you have a foreign license plate... I can’t go where I want to go.

**C0208**

Finally, someone said... Oh my god, carpooling is not going well at all right now, and everyone is taking orders full-time. The highway tolls from Ningbo back to Hangzhou only cost more than 50 yuan. I said I could pay all of them, but they asked me if I wanted 150 yuan and they thought I was taken advantage of.

**C0244**

Reply I am not the Qiuyu you guessed:

**C0279**

There are many more. If you order an exclusive ride, they will put together a lot for you.

**C0314**

If you order an exclusive ride and order 4 people, if you want to fight, they won’t take the order.

**C0349**

You bless [kiss an R] [kiss an R]

**C0384**

I carpooled once, and I had an out-of-town license plate, and they told me that I couldn’t get on the elevated highway at this point, and I couldn’t reach my destination. It was a very old car, and the back door was full of stuff. , I said you turn left and let me go and I went to take the subway, but he said he couldn't stop the car, and then I finally opened the door and got off the car while waiting for the red light in the middle of the road. I was left with the aftermath. I asked them for help 10 minutes after I got on the bus, but they took an hour to get back to me. I said, is this your emergency rescue? Our company's emergency rescue for customers requires a callback within 10 minutes. I was really scared to death at the time.

**C0419**

Choose 4 people for the next exclusive ride, don’t choose just one! This can be avoided

**C0453**

Reply to LIGHT MARK Xiaobaiguang Wuhan Henglong: I am not a family member, and I don’t know everyone.

**C0487**

Tongfeng Tongfeng will take you along the way and pay part of the gas and tolls. But they won't go out of their way to pick you up or take you to a specific place. You just get on and off the bus during the trip. This is called carpooling. If you need someone to pick you up and take you to a special place, that's not carpooling, it's called premium ride service, and the prices are naturally different.

**C0521**

It is recommended to use the premium ride service directly next time, there are many regulations

**C0555**

Are you carpooling?

**C0588**

Reply to ttlubby: I know it, I also want to fight, how can such a good thing happen?

**C0620**

Oh, let me go, there is such a good thing

**C0652**

Mainly because the unit price is too low

**C0684**

Big cities have a lot of opportunities

**C0716**

Reply to idle cool person: Hahaha, I think so too

**C0747**

@momo awesome

**C0778**

Agreed, it seems useless if I give feedback.

**C0809**

Reply to pure male tall gray wolf: @是hardpersimmon

**C0840**

What's the license plate? I'll go too.

**C0871**

Reply to 网速慢我着急: Then the driver was in the wrong.

**C0902**

There are options, including one to negotiate splitting the tolls.

**C0933**

There really are more opportunities in big cities.

**C0964**

Haha, if you specify that you won't pay tolls, the platform still shows drivers the highway route and travel time but hides the toll amount. Then it depends on the driver's experience. If they don't recognize it as a highway route and accept, they only discover it when starting navigation after pickup. Negotiating tolls then has to happen off-platform, because if they request toll payment in the app, the platform will cancel that request outright.

**C0995**

Then Guangdong drivers are relatively straightforward. They usually only ask for the stated amount.

## 23. I got carpooling and felt nauseous for a long time.

Source: https://www.rednote.com/discovery/item/6a4a71150000000021008098
Original record: 50_posts_1000_comments / N03
Text scope: Visible excerpt in source dataset

I got carpooling and felt nauseous for a long time.
🚗carpooling lightning protection! 98% of the time, is it really a smooth road? Don’t be fooled by the big words! I drove back to my hometown alone and signed up for carpooling with the idea of ​​sharing some costs. I only took these two orders (⚠️emphasis: these two orders were not on the same day! I took them twice), which really made me sick😡 💡Blood and Tears Summary: The "98% smooth way" and "95% smooth way" displayed in large characters on the homepage of the app are simply not accurate! ! When accepting an order, everyone must read the fine print carefully [how long will it take to pick up and drop off passengers/how long will the detour take]! The small print is the truth, the big print is all lies! 🔍 📉First order (return): 📱App shows: 98% of the tickets are on the way 💸highway tolls: Passengers choose not to pay for highway tolls (ok, I think it’s a bit more economical). 🛣️The actual situation: In order to see him off, we took a 40-minute detour in the city! In the end, the total price was just over half of highway tolls (more than 60 yuan). It’s really not worth it to be exhausted after driving all day! 🤦‍♀️ 📉The second order (outbound, not on the same day as the first order): 📱app shows: 95% of the way (only halfway) 💸highway tolls: This time he is willing to pay for all highway tolls, but! What he meant was to take the expressway first, then get to the nearest expressway entrance to his destination and then get on the expressway (actually the highway tolls he was willing to pay were only a few dollars, but it was 40 minutes slower than taking the expressway directly from the city). 🛣️But the actual situation: Because I was not familiar with the app, I searched the place name on the map myself, but I fell into the trap of "the same name but different places"! His real destination was still 40 minutes away from the highway exit, and it was all mountainous! 🏔️ The originally 2 and a half hours of driving by myself was delayed for more than an hour, and it took me almost 4 hours to get home! collapse! For more than 70 yuan 🤯 😤 What makes me speechless the most is the attitude of the passengers: My car costs more than 20 watts, and the interior is clean with no smoke or odor. Does it fully meet the standards of Didi premium ride service? They took it for granted that they spent more than 60 to 70 yuan for a 1-2 and a half hour taxi ride, and they didn't feel any gratitude at all. They felt that everything was as it should be after they paid the money and I took the order! It’s really fast! For this small amount of money, I took a detour and wasted time. Without a heartwarming word, I logged out. Goodbye🙄
07-05

### Comments

**C0003**

Hahahahahahahahaha that’s outrageous

**C0049**

If the car can't add highway tolls, don't look at it. If you get on the car and point out the route, just ask him to get off.

**C0091**

I only take orders but not people, just educate me.

**C0131**

Remember, don’t pick it up in towns and villages

**C0170**

An hour's drive can turn into two and a half hours in a matter of seconds.

**C0209**

Don’t hesitate to report

**C0245**

Real car owner. Look carefully. study.

**C0280** (post author)

Or you have experience! I've only received 2 orders.

**C0315**

Not 70 an hour

**C0350**

Just let your parents place an order for you and take away the first order bonus, and then uninstall the software. This thing is just a scam. I used it a few times in the past two months, but now I don’t use it at all unless the mileage is very long. It’s not troublesome enough.

**C0385**

I turn on automatic order grabbing, and the starting point and destination are 3 kilometers away from me before I can accept the order.

**C0420**

Have I carpooled 55km before? I gave the female driver a cup of milk tea. It was an exclusive ride+highway tollsaa. I'm so touched that she didn't charge me highway tolls.

**C0454** (post author)

So angry

**C0488**

Reply to Jiuxiao and keep the deposit on file:

**C0522**

When carpooling, you first need to check whether the starting point and the end point are far from you. If it is inconvenient, there is no need to pick up if there are multiple traffic lights in different directions. If it is really convenient, it doesn't matter if it is cheaper. Also, you can call after you pick up the call and check the other person's tone. If you feel uncomfortable, don't pick up.

**C0556**

The reply was meager: I was too lazy to watch the first single, I just watched it out of boredom and treated it as a short drama.

**C0589** (post author)

I feel a shadow in my heart.

**C0621**

Reply to Jiuxiao, keep the deposit on file: It’s not like this for a living anyway, it doesn’t matter

**C0653**

If you don’t pay the toll, don’t pick it up. The car owner chooses another route.

**C0685**

It's 70 yuan for an hour of work. I can do this job. I go to work and drive screws for 20 yuan for an hour.

**C0717**

Real car owners, remember to protect yourself.

**C0748**

I would like to ask, if you are willing to pay the expressway toll for a shared ride, it is actually only 35. The driver asked me to pay 300? [laughing and crying R] [laughing and crying R] [laughing and crying R] Isn’t it too outrageous...

**C0779** (post author)

Efforts and rewards are completely out of proportion

**C0810**

If you do this, people will say you are a professional carpooler.

**C0841** (post author)

That's 70 yuan for an hour and a half of your time, and you still have your own things to do.

**C0872**

Once I saw that they wouldn't pay tolls and had unreasonable demands, the outcome was obvious. As a car owner, you need to screen passengers. Leave the difficult ones to full-time drivers.

**C0903** (post author)

Emotional support matters too. Some people think paying makes them the boss. Carpooling is actually about mutual help.

**C0934**

They're all doing charity work.

**C0965**

You're so naughty.

**C0996**

For an hour and a half of driving, fuel alone costs more than 70 yuan.

## 24. 🤦‍♂️Go carpooling if you are bored and experience the real car rollover record

Source: https://www.rednote.com/discovery/item/6aa8153d0000000026015bf0
Original record: 50_posts_1000_comments / N04
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
LIVE
1/5
🤦‍♂️Go carpooling if you are bored and experience the real car rollover record
On a whim, I went for a carpooling experience⛽️ No. 95 oil｜83km｜Income 58.65. I ran down and calculated it, just for love⚡️ I was so broken that I met an unhygienic passenger🤢 The smell hit my face when I got in the car, and I wanted to escape physiologically. My mentality was a bit explosive💥 But I still kept my word and gave it to others. 😭😭Failed life experience +1
Edited on 09-23

### Comments

**C0004**

Every time I have the slightest idea of ​​carpooling, I hit the lightning protection post.

**C0050** (post author)

Highway tolls cost 4 yuan. .

**C0092**

Reply to Xiangtao Yutou: My sister is carpooling and is most afraid of meeting difficult and unhygienic people. Everything else is fine.

**C0132**

I tried to register out of curiosity, but after I answered the first call, I immediately canceled it and never clicked on the carpooling page again.

**C0171**

Reply to qi~in: Hahaha, me too, so when I smelled it later, I asked him to order a new one. Real seats cannot be messed with like this.

**C0210**

My house is next to a university, and I have met college students several times. They all chatted in low voices, and I also chatted with my partner, each chatting without disturbing the other. I didn't overcharge them for joining them temporarily.

**C0246**

Reply to Haji Haji: Really, I will find it for you now

**C0281**

Reply to Haji Haji: It’s really outrageous

**C0316**

Those who arrived at the construction site like me are honest. The key is that they were sweating all over and breathed through their mouths all the way.

**C0351**

I have a very excited look, and I will suffer a lot if I follow you.

**C0386**

Generally, I will look at the starting point and the end point. The quality of the community will be better if it goes to office buildings or schools, except for commercial communities, where there is a mixed bag of people.

**C0421**

Reply to Haji Haji: So what is the charging standard for this carpooling? Don't understand

**C0455**

666

**C0489**

What about the urban village?

**C0523**

It’s not like you’re losing money, highway tolls won’t let you pay, otherwise it’s just for love.

**C0557**

Reply to 香芋芋头: I guess the appearance of the tram has brought down the price. There’s nothing we can do about it.

**C0590**

Reply to Haji Haji: I want to take a random order one day after work and go to another city to have fun.

**C0622**

Reply to Xiangyuyantou: I feel like there are no standards, but the official will definitely make money.

**C0654**

I only recruit students for carpooling. The starting or ending point is in a university town. The students are generally of high quality and will not step into any trap.

**C0686**

Reply to Xiangyaoyantou: Shared ride looks like this, with a 30% discount by default.

**C0718** (post author)

Why not give it a try

**C0749** (post author)

Don't answer, don't answer, it's really a waste

**C0780**

I know they worked hard, but it’s hard to ride a car like this. Really hurt physically and mentally

**C0811**

However, students have a high rate of placing orders in advance and like to compare prices.

**C0842**

Reply to 哈吉哈吉: Look.

**C0873**

Reply to 香芋芋头: Probably not that low. I checked a few days ago: 600 kilometers could get around 250 yuan, and that's for a shared booking.

**C0904**

Carpool rates are extremely low now—not even one yuan per kilometer.

**C0935**

That's nothing. I once picked up someone with such strong body odor that I wanted to jump out of the car as soon as they got in.

**C0966**

I thought about taking someone home over the National Day holiday to share fuel costs, but then decided against it. I've already spent 400,000 yuan on the car—why chase those few pennies?

**C0997**

I drive a petrol car and live on a university campus. Most people I pick up along the way are teachers or students. Most are lovely, good conversationalists and encouraging. I used to be a nervous, inexperienced driver, but all their compliments have actually helped me improve a lot.

## 25. Didi carpooling dangerous car owner complaint‼ ️

Source: https://www.rednote.com/discovery/item/6a807f54000000002c007a8f
Original record: 50_posts_1000_comments / N05
Text scope: Visible excerpt in source dataset

1/8
Didi carpooling dangerous car owner complaint‼ ️
"Didi carpooling complaint!! Sisters, I will feel something is wrong before getting in the car. Never get in the car. I would rather spend more money to take a taxi instead of getting in the car. Share today's carpooling experience. Today at noon, I made an appointment with an exclusive ride carpooling (exclusive ride) departing from 12:00 to 12:15 to have dinner with friends. I think the journey takes about 1 hour and we can arrive before 13:30. The driver called me in advance and said highway The tolls asked me to pay for it, and I asked if it was half and half. The driver said it was only 10 yuan, and I said that was fine. The driver arrived downstairs at my house at 12:15, and I saw two men in the car. You can pay for the tolls yourself. The driver said you can pay 8 yuan. I asked why it was 10 yuan and I paid 8 yuan. The driver said 13 and I just got in the car and said let’s go first. When I drove to the gate of the community, I saw the driver was waiting. I saw that the route was not my normal route, and the end point was not the location I chose. I said that I should go to my place first. The driver said no, and he would send the next one first. I assumed that the two of them were together, and I asked how long it would take to get to my place, and the driver said no. It’s only 10-20 minutes, which is okay, I thought, because I saw that the next destination time was 13:09, so I thought to myself, let’s go. I heard another passenger on the bus saying that the money has been paid to you. If you are a friend, why are you charged separately? It’s obvious that you take the order privately. After walking for only a few kilometers, the driver asked me to pay for the highway tolls first. I said I would pay later. You can pay extra on the platform. The driver asked me to pay first. I insisted again. I said not to do this kind of thing in the future. If you can, pick up the tolls. If you can't, don't pick up. At least tell the passenger in advance. He said to tell me, and I said, just tell me about the highway. Did you say there was someone in the car? The driver said, "Beauty, I'll give you another chance." I didn't dare to speak, so I paid the highway tolls first. Because the experience was so bad, I took photos throughout the journey to prove that there were other people on the bus. Then at around 13:09, when I arrived at the first destination, I found that only one of them got off the bus, but I didn’t ask if the next stop was for me. When I got to the next stop, I asked how long it would take to get there, and the driver said it would only be a few minutes. We arrived at the second destination at 13:21. Did I say we were there? I was about to get off the bus, but the driver said it was not you, and then the second passenger got off. I took videos and photos to prove the time when the first passenger got off and the second passenger got off. The word limit has been exceeded. Please take a look at the screenshots for details. Thank you."
08-15

### Comments

**C0005** (post author)

Now I understand that an exclusive ride can only carry one passenger at a time and deliver the passenger to the destination first. Netizens said that exclusive rides allow you to bring relatives and friends, but the passengers are dropped off first. Personally, I think that even if you can bring relatives and friends, it is best for the driver to communicate with the passengers in advance and explain that there are other people in the car but he will be sent first.

**C0051** (post author)

Sister, you can call and finally transfer to the manual number 4000061876. After dialing, press 0-8--1-0 and finally transfer to the manual successfully. However, Didi's internal department will also shirk the call transfer. You can try it.

**C0093**

Platform intentional

**C0133**

These carpooling platforms have failed to fulfill their audit obligations. Some fake carpooling platforms accept orders from multiple platforms. Passengers spend exclusive ride money to share rides with others, but the real carpooling owners cannot receive orders.

**C0172**

Oh my God, can I be so scared that I tremble?

**C0211** (post author)

Hahahahahahahahahahahahahahaha I have also called a good carpooling car owner before, the commercial car has 7 seats, and the driver is also very nice. So I may think that the probability of this kind of carpooling is very high, but I am wrong.

**C0247**

Reply to Happy Puppy: Good, good, good

**C0282** (post author)

Sisters who can report complaints

**C0317** (post author)

Okay, thank you sister

**C0352**

The most outrageous time was when I took a taxi at Shaoxing North Railway Station. The driver smelled like garlic and was looking down at the video on his mobile phone the whole time. It scared me! It's only about ten minutes away

**C0387**

Maybe different platforms accept exclusive ride orders. The price of carpooling is very low now. If it is not a real carpooling, if you pick up one person professionally, you will definitely lose. Picking 2 people may save your money. Only 3-4 people can make money. Many professional people accept exclusive ride orders on multiple platforms to make money. In fact, the risk is also high because they will be complained (so the driver has been secretly threatening and saying to soften and beg for mercy). So if it is really an exclusive ride order, it is the safest to see someone not getting on the car. To avoid conflicts with drivers, it is not good for you (after all, if the platform complains and punishes the driver’s account, you are afraid of subsequent retaliation). The principle of happiness and concession🤺🤺🤺 Life is not easy now, especially those who drive carpooling, ride-hailing and food delivery. They are themselves a storage pool for all kinds of unemployed people.

**C0422**

I am a car owner and I have pulled a passenger. You are really a very kind passenger. I strongly recommend that you file a complaint. We treat car ownershared rides as exclusive rides, which is too much.

**C0456**

I have also experienced this. I picked up three male passengers in the car, plus the male driver, and the little girl was slightly broken.

**C0490**

One time I was carpooling at night. Even though I paid for the exclusive ride, the driver dropped me off first and then another person. I didn’t dare to say anything.

**C0524**

Carpooling is a black car

**C0558**

Don’t get in the car if you see someone in it, safety first.

**C0591**

Yes! ! This must be dealt with seriously. Girls are inherently afraid of this kind of danger in riding‼ ️

**C0623**

Sister, where are you?

**C0655**

I have also encountered it several times. I chose the exclusive ride and there were people in the seat. I decided not to sit on it. baffling. I also met someone with his pet dog sitting in the passenger seat, hahahahaha

**C0687** (post author)

Wuwuwuwu yes, next time we encounter this situation, we will take a taxi again

**C0719** (post author)

Indeed, I can’t do it next time

**C0750**

exclusive ride Aren’t you the first customer to give exclusive ride?

**C0781** (post author)

Yes, at that time I was wondering if something would happen to me today.

**C0812**

Reply to Happy Puppy: I made a complaint to 12328, but the customer service staff were all indifferent. I was also solicited privately by the driver, and I asked for a waiver. When I complained later, someone contacted me and offered to waive the bill.

**C0843** (post author)

I took a ride from Dongguan to Shenzhen. The driver's car had a Shenzhen plate.

**C0874** (post author)

So that's how it works. My friend was asking today why the driver could still accept bookings when I'd booked an exclusive ride. We guessed it might be a former passenger he'd added on WeChat and arranged privately. Turns out they can accept bookings on multiple platforms at once.

**C0905** (post author)

Reply to 民以食为天: They must be repeat offenders. Nobody penalizes them. Disgusting.

**C0936**

It really is impossible to reach anyone at Didi now. Three times I booked an exclusive carpool ride, and the driver picked up two more people through other platforms. Worst of all, I was dropped off last! I wanted to complain but couldn't find Didi customer service at all.

**C0967**

I never use carpooling, but if this happened to me, I wouldn't take photos. I'd contact customer service directly through Didi because personal safety is at stake.

**C0998** (post author)

Exactly. Make sure everyone is safe first.

## 26. Using AutoNavi carpooling as a blind box, the experience is actually a bit overwhelming

Source: https://www.rednote.com/discovery/item/6ad7335f000000002f032c10
Original record: 50_posts_1000_comments / N06
Text scope: Visible excerpt in source dataset

1/2
Using AutoNavi carpooling as a blind box, the experience is actually a bit overwhelming
In the past, when I used taxi-hailing apps, I just wanted to come and arrive quickly. Recently, I started using AutoNavi carpooling frequently because I was traveling across town to see friends, and suddenly I discovered that the core experience of this thing is actually a bit like opening a blind box. You never know what kind of car or personality the car owner will take. Once when I went to the next city, the person who took the order was a man driving an SUV. The trunk was filled with his fishing equipment. As soon as he got in the car, he chatted with me about the big fish he caught yesterday. Another time, it was a young female car owner who drove a small tram. The car was beautifully decorated, and the podcasts we both liked were played all the way. We drove quietly to the destination. Moreover, this "blind box" refers not only to the car owner, but also to the route. Sometimes the car owner does not follow the navigation, but will take you around some small roads that you would not notice at ordinary times and see different scenery. The most important thing is that the cost of opening this blind box is extremely low, and the price is generally only half of that of taking a taxi. Spend less money and experience different aspects of the world. Every time you send an itinerary and wait for matching, you even have a little expectation. This is probably the difference between carpooling and ordinary taxi rides.
Edited 7 days ago Chongqing

### Comments

**C0006**

Good value for money

## 27. I will never take carpooling again.

Source: https://www.rednote.com/discovery/item/6abe0cbe00000000150023db
Original record: 50_posts_1000_comments / N07
Text scope: Visible excerpt in source dataset

I will never take carpooling again.
1⃣️Two times out of five exclusive rides, the driver will pick up private work, often spending the exclusive ride money to buy shared ride services. 2⃣️There is no use in taking a taxi in advance. Many drivers will cancel the order before departure, breaking your plan. 3⃣️What makes me feel even more unreasonable is the current trend on the Internet: many people only help drivers to settle accounts, but they will not help passengers to settle accounts. The driver makes no money after being charged a commission, so it is reasonable for exclusive rides to accept private jobs. Passengers pay extra to take an exclusive ride, but they deserve to enjoy the shared ride service. If you want to enjoy the benefits of an exclusive ride, you must add the money to the express bus.
10-01 Guangdong

### Comments

**C0007**

My carpooling services are all long-distance or across the city. Premium ride services are expensive, and I use Didi for intra-city transportation. The carpooling I encountered were all full-time.

**C0052**

Why am I on a shared ride, an exclusive ride that I paid first, and I don’t proactively refund the difference when I get off the bus?

**C0094**

I took a carpooling taxi for more than 40 kilometers, and he asked me if I could go for 200 yuan.

**C0134**

The expressway is free, and they charge me highway tolls

**C0173**

I also signed up for carpooling. I don’t accept shared ride orders. I only accept exclusive rides and comfort rides. When I am a passenger, I also like to order exclusive rides. Sometimes the driver will take the order separately, but as long as he picks me up and drops me off first, I won't say anything. I can understand that the driver wants to make more money, but I wouldn’t do such a thing myself.

**C0212**

Reply to momo: Professional carpooling relies on this meal package to increase money, otherwise I would really think it is just a joke. Now carpooling prices are reduced to reduce travel costs, but almost all of them fall on passengers. It is really useless for real carpooling car owners. I hope to increase the unit price and crack down on professional carpooling, so that everyone can really share the travel cost. Carpooling is so cost-effective. As long as you can accept the worst case scenario, the fuel cost of driving yourself is 200, highway tolls are 180, and carpooling is 150. You simply don’t treat the car owner as a human being.

**C0248**

Half an hour before departure on the 7th, I was temporarily released. The platform continued to issue orders and was picked up instantly. The carpooling car owner asked me to use highway tolls for the entire journey. I refused. He said that highway tolls for National Day are a benefit for car owners and are not enjoyed by passengers. I am not used to it.

**C0283**

Reply to the train: That’s a lot to say. In short, in this market, dissatisfaction on both sides is inevitable. Car owners are really less motivated. Many people really only use carpooling. They feel that it is useless and they just stop taking it. Some people who are left behind do whatever they can to increase their income. Passenger experience has further declined, and they don’t know how the situation will develop in the future.

**C0318**

I carpooled my kids several times in a row and canceled when the time was almost up. I don’t know if the driver did it on purpose.

**C0353**

When you find that the carpooling driver has increased the fare, you have the right to choose not to take the ride. No one forces you

**C0388**

Moreover, the driver will not be deducted for temporary cancellation, but the passenger will be charged for cancellation.

**C0423**

Don’t wrong yourself just to save that little money. You must treat yourself well if you are willing to spend money to get a premium ride service. It’s not much more expensive-…

**C0457**

Co-author: When it comes to carpooling, passengers must arrive before the driver. If the driver arrives before the passenger and finds that the passenger is not there, he will cancel the order without saying anything, which is a waste of the passenger's time and the passenger will also suffer.

**C0491**

Xiaohongshu can't talk about bad carpooling, otherwise he will be bombarded

**C0525**

If he really wants to fight, he can continue to fight, and he will take you all the way around.

**C0559**

I can say that carpooling is not called taking a taxi.

**C0592**

In the three carpooling rides I have taken so far, I have always chosen the exclusive ride, and without exception, I have been taken on the shared ride.

**C0624**

That's a professional carpooling car owner, who makes money from this

**C0656**

Because no one will take your shared ride order, so you can only order a shared ride with an exclusive ride price.

**C0688**

Reply to Dudu: I don’t know, there are other people in the car

**C0720**

I haven’t taken one for several years. In the past few years, when I wanted to take one, I found that I couldn’t get the orders I wanted, so I never took the order. Recently, because the oil price has increased a lot, I remembered that I took an order during the National Day holiday, about 100 kilometers away, 2 people, 57 yuan and 83 yuan. For this process, I think the unit price is indeed a bit unexpectedly low. Before, I couldn't get an order at all. This time, this order was also actively invited by passengers, and passengers actively invited me for 2 orders. I chose the one that was more convenient. I placed the order on October 4th. These 3 orders were all on hold for a long time. Finally, when the bus was about to leave, no one took the order, so I took the initiative to invite the driver. In fact, you don’t have to think about it. It’s just because the unit price is so low now that many people feel it’s inappropriate and don’t need to grab the order before I take my turn. I remember a few years ago, the highest one-way trip for the same journey was around 130. Of course, this is not a reason to increase the price.

**C0751** (post author)

Yes, even if the exclusive ride + highway tolls are all-inclusive, you still have to enjoy the shared ride treatment. It’s not just once or twice. I feel like I’m being blamed for spending money.

**C0782** (post author)

as i expected
Pinned comment

**C0813**

Isn't carpooling just a ride on the road? I originally paid extra for an exclusive ride, but ended up being offered a shared ride. I asked the driver's relatives and friends, and the highway tolls had to be paid for by the passengers. Traveling with the driver was a pure money-making experience.

**C0844**

Why do all the shared-ride bookings I accept end up getting an exclusive ride? I always either split the tolls with the passenger or pay them myself.

**C0875**

It's terrifying how you can't say a single bad thing about carpooling on Xiaohongshu.

**C0906**

Last time I chose an exclusive ride, then the driver asked if he could take another person. I said no and told him to cancel. If I see a driver has listed friends or family on board, I cancel those bookings too.

**C0937**

Actually, if it's not on your route, you can simply decline the carpool booking.

**C0968**

Carpooling changed a long time ago. It used to mean taking one passenger on your commute to share fuel costs. Now it's full of unlicensed taxis—the same people who used to solicit passengers around bus and train stations, just doing their old business in a new way.

**C0999**

Wow, I hadn't taken a carpool ride in ages. I just booked one home, and the driver called asking me to pay half the tolls. I thought that was fine. Then he said he was bringing a friend or relative who would pay the other half. Does that mean he's actually combined two bookings going the same way?

## 28. This is the first time I experienced AutoNavi carpooling and I got a refund within seconds. This after-sales service is really good.

Source: https://www.rednote.com/discovery/item/6ae051c90000000018015667
Original record: 50_posts_1000_comments / N08
Text scope: Visible excerpt in source dataset

1/2
This is the first time I experienced AutoNavi carpooling and I got a refund within seconds. This after-sales service is really good.
It’s my first time to experience AutoNavi carpooling and get refunds in seconds. This after-sales service is really good. When I usually use taxi-hailing software, the biggest headache is when my itinerary changes and I want to cancel or get a refund. The process is cumbersome and sometimes I have to argue with customer service for a long time. I originally made an appointment with AutoNavi Carpooling to meet a client this afternoon, but not long after I got in the car, the client suddenly called me and said that the meeting was temporarily cancelled. I hung up the phone and awkwardly explained the situation to the car owner. The older brother was very nice and said it was okay and dropped me off nearby. The order on my mobile phone has already been placed. I thought that the fare for this trip would have to be deducted as usual. After all, it was my unilateral breach of contract. Later, I still couldn't hold it back, so I asked a question about the cost on the order page, and simply wrote, "I only sat for a short period because of something unexpected. Can I get a refund for the price difference?" As a result, before I even reached the subway station, a refund notification popped up on my phone. When I clicked on it, I saw that the platform directly refunded me the cost of the journey I didn’t take, without even having to wait for human customer service. This processing speed really surprised me. If I encounter an emergency again in the future, I will feel confident.
12 hours ago Beijing
Say something...
"3"
"1"
Comment

### Comments

No sampled comments in the supplied dataset.

## 29. Is Didi carpooling really a success?

Source: https://www.rednote.com/discovery/item/6ae00a5200000000180163d3
Original record: 50_posts_1000_comments / N09
Text scope: Visible excerpt in source dataset

Is Didi carpooling really a success?
A few days ago, I called Didi Carpooling and asked the driver how long it would take to arrive. The driver said 4-5 hours, which is indeed within the normal range and acceptable. As a result, it took more than three hours to pick up other passengers in the departure city. Who knows what it feels like to sit in the same place for more than three hours. The originally four- to five-hour drive actually took almost nine hours to arrive. I was dizzy. Is this the meaning of carpooling? I apologized to the platform and gave me a 5 yuan coupon.
17 hours ago Jiangsu

### Comments

**C0008**

Reply to Xiao Hongshu 69770E55: The high-speed rail is not point-to-point, and it requires a lot of time and financial costs to get to and from the high-speed rail station.

**C0053**

It’s cheap. How can sugar cane be as sweet as both ends?

**C0095**

Reply to Xiao Hongshu 69770E55: Or take the high-speed rail and starve to death carpooling

**C0135** (post author)

Why do people say that Didi is not good and someone refutes it? Hello, that’s not the case. It’s not like I’ve never carpooled before. If I don’t agree with you, it’s because others like it.

**C0174** (post author)

Reply to Toyutali: But the reality is that carpooling does not have any advantage in terms of time. Overall, it is better to take the high-speed rail. The problem is that the driver lied, otherwise I will evaluate whether to take the high-speed rail or carpooling.

**C0213**

That's fine for you. I didn't even get on the expressway, so they asked me for highway tolls that cost ten yuan. They just called it "highway tolls" to earn money.

**C0249** (post author)

Highway tolls are another money-making name. Drivers will charge more even if they take the expressway.

**C0284** (post author)

Moreover, the extra highway tolls charged by the driver are almost two or three times the actual cost.

**C0319**

The current price is probably all for professionals. I used to run and play when I had nothing to do, but I am too lazy to move later.

**C0354** (post author)

It’s not cheap, it’s more expensive than the high-speed rail, and there are additional highway tolls to be charged.

**C0389** (post author)

@ Didi Good Departure @ Didi @ Didi Chuxing Customer Service Is carpooling so smooth?

## 30. Carpooling gets more and more annoying

Source: https://www.rednote.com/discovery/item/6a262f990000000022017940
Original record: 50_posts_1000_comments / N10
Text scope: Visible excerpt in source dataset

Carpooling gets more and more annoying
I used to think that carpooling was a really good invention. Drivers could make money taking a long trip, and passengers could also save some taxi fares. But now carpooling seems to be no longer "carpooling". According to my personal experience, the current understanding of “carpooling” by ride-hailing drivers is “the ability to pick up ride-hailing of several people at the same time”, and one trip can earn two people’s money. It has even reached the point where he refuses to drive without two people. The main package requires frequent cross-regional commuting due to work reasons. Because it is a medium- to long-distance ride, there are very few people who take orders for ride-hailing. In comparison, carpooling orders can be received almost in seconds, and the price is one-third cheaper, so I usually choose carpooling more often. But recently, I feel that the carpooling experience has become worse and worse. Here are a few examples: Driver 1: After picking up my car, he parked the car on the side of the road and waited for the order. Driver 2: I couldn't be contacted after taking the order, which caused me to change my high-speed rail ticket. Driver 3: This driver and Driver 2 took a taxi on the same day. Because Driver 2 couldn't be contacted, the taxi was canceled and retaken. He originally planned to ask me to wait for another half an hour because he wanted to pick up another person. I told him that I had to catch the high-speed rail before he reluctantly set off. He kept asking me to add money to him on the way, but I refused. (Driver 3 told me that Driver 2 didn’t answer the phone because he didn’t receive the second order, so he didn’t want to take my order.) Finally, he asked me not to take the shared ride. If I called the exclusive ride, it wouldn’t waste time. Driver 4: After listening to Driver 3’s words, I paid more for the exclusive ride. Driver 4 still asked to pick up one more person. I argued with him, but he blamed me for paying more for the exclusive ride. The above are just a few typical examples. In fact, I encounter one of the 4 types almost every time. I'm really too weak, don't scold me, because time is more important to me, so I don't bother to worry about it. It would be very troublesome to cancel and replay. I have reported them, but my account can only be banned for a day or two at most. These drivers have multiple accounts, and it is useless to ban their accounts. In addition, regarding the price of shared ride, these drivers have several numbers, so they cannot enjoy the shared ride price at all. In other words, passengers can only enjoy shared ride level services but have to pay the exclusive ride fee.
06-08

### Comments

**C0009**

Reply to bert.: Better than nothing

**C0054**

Yes, the detour and time wasted are really not proportional to the little money.

**C0096**

I take one order every ten days commuting in the same city. I only take it if it's really convenient.

**C0136**

It was okay before, but now I won’t answer it, it’s pointless.

**C0175**

Reply to Tanyue: I originally thought of commuting 90KM a day and wanted to take one with me to try. I was shocked when I saw the push notification on the platform. Such a low price requires 5KM transportation. One kilometer in Shanghai may take half an hour to walk and still cost 5KM. I uninstalled it directly.

**C0214** (post author)

Similarly, I met many drivers who picked up rides from Didi and Amap at the same time.

**C0250**

Reply to 㖿㖿's Kangkang🍁: Thank you๑•́₃•̀๑

**C0285**

Coming to the most important point

**C0320**

Some remarks still need to be filled in, such as using the trunk if you have a lot of luggage, if there are elderly people, etc. Otherwise, when the driver arrives at the starting point, he will see that there are too many things to put in, and the elderly will not be willing to pick them up. They will feel that they have been cheated and will yell at you. Just be realistic, or add some money.

**C0355**

Let me put it this way, if you have the budget for ride-hailing, you can increase the carpooling thank you fee to be the same as the ride-hailing price and ask the driver to only pick you up. I believe he will not refuse. My situation is similar to yours. I have to go out for work ten or eight times a month. I used to charge over 100 for carpooling, and I have never encountered a driver who asked for a higher price. Now I am in my early 60s when I carpool, and the price is always higher than mine. So I can accept the driver’s 30 to 40-yuan increase because it’s the same price as my previous carpooling rides. The unit price is really low now. I don't dislike carpooling drivers at all, because people like me are awesome. You may have to leave anytime, anywhere, and at any time, and last-minute business trips are a common occurrence. From point A to point B, if there is no dedicated driver, no one may take my order. Public transportation, high-speed train, taxi and subway plus the time consumed is much more tiring than carpooling.

**C0390**

"There are very few people who take orders for ride-hailing." It's so classic.

**C0424**

Because the platform suppresses prices too hard, my 380 kilometers only cost 114 yuan. Can a taxi be so cheap? I have been driving for more than ten years, and I have taken a few orders. Unless it is a special trip, I will not take it, and I will only take one person at a time to share it equally. If there is no one, then I will not take it. Nowadays, carpooling is all full-time drivers. You can’t make money unless you fill up the car.

**C0458**

Changsha to Ningxiang is 75 kilometers away, 2 people with pets, exclusive price of 45 yuan! It’s really a crime!

**C0492**

Reply to Liu: I used to only issue one seat, and it was still reluctant at that time. Now I haven’t accepted it in 3 years, so I have already uninstalled the software.

**C0526**

I used to do carpooling, which didn't make any money. I could only save some tolls because I was too lazy to pick up and drop off everywhere. I basically only picked up one or two drop-in orders, and I didn't charge highway tolls. Later, I gave the car to my wife and bought a van to go fishing and never left. Nowadays, we also do carpooling, but many of them are professional and the purpose is to make money. They pick up and drop off people no matter how far away they are. They keep picking up people for hours. Highway tolls are getting more and more expensive. You can pay while driving. The platform also encourages this kind of professional drivers. High-quality orders will be given priority to drivers who travel more. Drivers who travel less will only get some low-quality orders. Passengers placed orders and were picked up by professional staff within seconds. No matter what time you booked, if the negotiated time was not met, they would be canceled, causing you to keep placing new orders, and many even privately offered you an exclusive ride price. It was really annoying, and they kept getting cancelled.

**C0560**

1. You can try AutoNavi, which has many access platforms and more sources of orders. 2. The same route runs frequently. You can leave the driver’s phone number and agree on a time in advance to arrange for him to come over. Some drivers also have a fleet.

**C0593**

You are a sensible person and know that there are not so many cheap and high-quality things in this world.

**C0625**

Reply🍑: The key is that I’m not willing to buy highway tolls yet, and I still think you’re expensive.

**C0657**

Just reply and be happy for the rest of your life: There will be no impact, as long as you don’t take more than two orders a day

**C0689**

"Time is important, carpoolingshared ride is also important" Isn't this more classic?

**C0721**

I am a real car owner. I have not received any orders since I registered for 3 years. It’s a 160-kilometer journey, and we only pay 60 yuan for a shared ride and not highway tolls. It’s really a charity. If we have to take a detour, we might as well not pull people in every time. Open the software and look at it, then close it.

**C0752**

Not to mention picking up one, picking up two would make no money at all. You have to pull three or even four to make money.

**C0783**

Reply to Liu: I don’t accept carpooling orders for two reasons: I don’t accept orders for multiple people and I don’t accept orders for pets.

**C0814**

Reply🍑: You are a good person! let's be friends

**C0845**

The platform surely doesn't care whether the people accepting bookings are full-time carpool drivers. As long as more drivers take orders and it gets its commission, that's enough!

**C0876**

If you drive a petrol car, even a small detour means your earnings won't cover the fuel.

**C0907**

I don't want to accept bookings at all. The price is low, and I'm worried about getting someone who smokes or has poor hygiene.

**C0938**

Does activating carpooling for your car affect insurance or anything?

**C0969**

Just over 60 yuan for 150 kilometers—even as someone who often uses carpooling, I think that's absurd.

**C1000**

Reply to 余生欢喜就好: I've heard it can affect insurance. If an accident happens and the insurer doesn't want to pay, it may investigate, classify it as illegal commercial operation and refuse the claim. But normally that doesn't happen.

## 31. Carpooling sister taught me a lesson

Source: https://www.rednote.com/discovery/item/698c3b88000000001a035482
Original record: 50_posts_1000_comments / N11
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
Carpooling sister taught me a lesson
I was the last one to get on the bus after carpooling and I was the last one to get on the bus. The person sitting in the front seat was a girl with red highlights. Her hair looked messy, but in fact it was very stylish. After I sat down, she started to sing, and she sang well. "The distant mountains are calling me~" "If you don't love me!" Then he started chatting with the driver and the people next to him. "Where do you live from?" "Master, are you tired?" She was very enthusiastic and enthusiastic. She talked and sang for a while. My sister took out the strawberries and started handing them out one by one. They all refused, and I was the last one to be handed out. When I saw the red strawberries in front of me, I was a little excited, but I thought no one wanted them, so I waved my hand. When I saw that no one was willing to eat them, I pinched the stems of the strawberries and handed them to me. I took them and ate them, it was very sweet. Everyone else also ate. We arrived at the service area soon, and it was time for dinner. I bought a cake to eat in the car and said why don't you guys buy some food. The elder brother next to me asked if this cake cost ten yuan. She said loudly and cheerfully, "No, it's eight yuan. No matter how expensive it is, you can't go hungry." She was also very concerned about the driver. Is he tired after driving for so long? Why didn't the guy who just got off the bus pay the highway tolls? I'll pay it now. You work so hard, I may not be able to run away. My sister was the second one to get off the bus. As soon as we got to her house, she started to introduce us to the scenic spots we saw. After getting off the bus, she said, "Come down, I'll treat you to mutton soup." When she got off the bus, the driver said he was so angry.
02-11

### Comments

**C0010**

Because you have an eye for discovery, your words are very comfortable to read.

**C0055** (post author)

Hello sisters! Hello uncle!

**C0097**

Refreshing little reply: I laughed so hard

**C0137** (post author)

What? ! ! Even if I, the driver, smoke, you are already very good! ! ! I'll make you the top carpooling driver! ! ! Stop reflecting! Stop internal friction!

**C0176**

I used to go to high school in the county town, and every time I had to go on a shared ride with several people, it cost ten yuan per person. When I arrived at school and was about to get off the bus, the aunt who was driving quietly grabbed a handful of coins and stuffed them back into my hand without saying a word. I was so moved...

**C0215**

I was taking the shuttle bus back to my hometown. Halfway through the bus, a seventy-year-old grandma got on the bus and was cursing (she must have been waiting for the bus for a long time. It was raining outside and quite cold). The grandma in the back was worried about motion sickness. The motion sickness bag happened to be hanging close to me. Grandma said that my little brother could help me pull a bag. I pulled the bag for her. Grandma expressed her gratitude. Then I gave her some tissues. Grandma took it and wished me a hundred years (long life) [Super Like R]

**C0251** (post author)

Reply to a resting cat: Okay ~ I hope it can bring you happiness ~

**C0286**

Please keep using your perspective and writing style, and share more of your life with us!

**C0321** (post author)

Hahahahahahahahahahahahahahahahahahahaha I got rich

**C0356**

I was very nervous when I was doing carpooling. The car was not very soundproof. I kept blaming myself along the way for not buying a more comfortable car. Then I was very careful about gas and brakes. When I drove, I wanted to stand up and step on the accelerator.

**C0391**

Let me use your window to tell you that there are a lot of shared rides these days. The passenger in the passenger seat, no matter what you are like on weekdays, you should be cheerful at this time. Close distance is fine, but long distance, especially in the afternoon, talk to the driver more often to cheer him up.

**C0425** (post author)

Can you add ice to the reply: I guarantee that the task will be completed after receiving it!

**C0459**

Am I the only one who cares where the mutton soup comes from? So greedy! Is it Ju County?

**C0493**

I lent a power bank to an uncle on the high-speed train. We both had standing tickets, and he was worried that I would be tired from standing. He kept asking me to sit on his suitcase along the way, and stuffed me with two oranges. When I got off the train, he kept asking me if I wanted to eat dried shrimps, and gave me a bag. I couldn't resist the kindness, so I accepted two from him🍊

**C0527** (post author)

Thank you for liking Sister Carpooling and my writing. I always like to talk about it. Now I have really found a suitable track. Amway has made a wave of my own, 95 rural girls from different places, and continue to tell small thoughts and stories in my life ~ I hope it can heal you, warm you and accompany you.
Pinned comment

**C0561** (post author)

Sisters are right, this kind of kindness itself is valuable

**C0594**

very nice

**C0626** (post author)

Thank you for the compliment! ! So happy

**C0658**

Let me also say that there were a lot of people on the way back the day before yesterday. When I entered the bus to find a seat, the aisle was already full of people. After finally finding a seat and placing my luggage, the carriage gradually became quiet. I covered my eyes with a hat and got ready to sleep. Suddenly there was the sound of playing games next to me. The sound was not loud, but the girl was standing next to me, with the microphone right above me. I was too sleepy and squinted for a while. The noise was a bit uncomfortable, so I moved around. The girl said to her companions, "There is wind here, come here quickly." About ten minutes passed in a daze. Maybe because no one was talking in the whole car in the early hours of the morning, the sound of the game was particularly obvious. Maybe it was because I was too sleepy and I couldn't control my half-awake state. I clicked my tongue in displeasure. An hour had passed since I woke up, and the sound was gone. The girl stood next to me, not playing games, just standing bored and dazed. At this time, I suddenly felt a little sorry. The only way to pass the time during the long distance was playing games. It was too harsh for me not to sleep.

**C0690** (post author)

pistachio! !

**C0722**

Why did the driver say that I’m paying attention to you? I should be very happy to be your friend in life.

**C0753** (post author)

When we help the elderly here, they will say, I wish you a good university.

**C0784**

No matter it is early in the morning or any time, you should not disturb others by playing audio aloud in public places, not to mention it is already early in the morning. Don't play until others make displeased noises. It was because she was blind or unconscious, or it was possible that her mobile phone had run out of battery. It's not because of your displeasure

**C0815**

I was carpooling once. When I was about to arrive, a girl in the car said: "Master, you drive so steadily." The driver said: "[covers mouth and laughs R] It's okay, okay! I have a good personality!" The girls said: "I should have driven there earlier!" The driver didn't say a word for the second half [Bang R]

**C0846**

I'm like that too: I can chat with anyone. Even when I step off a train for a smoke at a stop, I can strike up a conversation with the guy next to me. I love it, because when you show kindness, you get plenty back. All my friends say I feel very alive and real. Making people happy makes me happy too.

**C0877** (post author)

Hahahaha, have we reached that age?

**C0908**

The driver only dared say that woman was a bit daft after she got out.

**C0939** (post author)

I feel so bad for you. Sending a hug. Thankfully the taxi driver and passengers helped you. Sometimes these sudden situations really are impossible to foresee.

**C0970** (post author)

A Buick GL8, hahahaha. I've memorized that now.

## 32. I was carpooling on a rainy night. I didn’t say a few words, but I remembered them for a long time.

Source: https://www.rednote.com/discovery/item/6aaa32700000000026016e89
Original record: 50_posts_1000_comments / N12
Text scope: Visible excerpt in source dataset

I was carpooling on a rainy night. I didn’t say a few words, but I remembered them for a long time.
Last month, I worked overtime until ten o'clock. The subway stopped, it rained again, and the taxi queue was over fifty. I tried carpooling on Amap, but I didn’t expect anyone to actually pick up the call. The car owner was a female car owner in her early thirties. As soon as she got in the car, she looked at me and asked, "Are you feeling uncomfortable?" I said I had a fever. Without asking any more questions, she adjusted the direction of the air conditioner and turned off the music: "You squint for a while. I'll call you when you get there." She stopped at a convenience store, got out of the car and bought a bottle of water and handed it to me without saying a word. When she got downstairs, she didn't turn off the engine and said, "Come up, don't catch a cold." After returning, she even tipped the car on the platform. Owner, in retrospect, it had nothing to do with whether the car was clean or not, but when I was feeling uncomfortable and exhausted, this kind of kindness that was just right and did not cross the line can really be remembered for a long time.
09-16

### Comments

**C0011**

Do you guys sit in the passenger seat or in the back for this kind of carpooling?

**C0056**

Yes, I saw there was talk of rewards

**C0098**

It would be more practical to give someone a 5 yuan red envelope and pass on this goodwill.

**C0138**

I am a man and I often care about female passengers, and I often get looked down upon.

**C0177**

Hahaha

**C0216**

The good-looking ones and the nice-talking ones sit in the front, and the others cancel their orders directly.

## 33. It turns out that carpooling’s exclusive ride is an exclusive ride seat👍

Source: https://www.rednote.com/discovery/item/6a75f04900000000050280ed
Original record: 50_posts_1000_comments / N13
Text scope: Visible excerpt in source dataset

1/2
It turns out that carpooling’s exclusive ride is an exclusive ride seat👍
Say nothing and walk alone
08-07

### Comments

**C0012**

It is written on Didi that it is an exclusive ride with 4 seats.

**C0057**

Is the parrot okay?

**C0099**

Reply to LLY: If you report it after you have finished your ride, the toll will be refunded and sometimes a coupon will be given.

**C0139**

In fact, the exclusive ride means that this platform only picks you up from one platform to another. He may continue to pick up, and there may be relatives and friends. Anyway, I have taken an exclusive ride with 4 people in a car.

**C0178**

Shared ride means you sit on the driver's body, one on the lap, one on the shoulders, and one on the head.

**C0217**

And the driver said to pick me up first, which means he has to go to three places to pick me up, and all three are on the way to the airport. If he said that he would pick me up after connecting with someone else, then I could accept it, but no one can guarantee that he will be picked up on time. I reserved 3 hours in advance for boarding, including an hour's drive. If I took a detour to pick up someone, I don't know how long it would take to get to the airport because I was in a hurry for work and I didn't dare to gamble on flights.

**C0252**

I just want to complain about the reply: 12328 who complained

**C0287**

No, from the time you receive it to the end of the process, you can only accept this order. You can have relatives traveling with you. You must indicate this when accepting the order.

**C0322**

I took an exclusive ride before. After I was picked up, I went to three places to pick up different people. I wandered around for a long time. The originally one-hour journey took 3.5 hours. Finally, I took an exclusive ride on the highway tolls.

**C0357**

Reply to LLY: You should go to the transportation management to complain about illegal cars. Just ask Doubao for the transportation management’s phone number and then file a direct complaint.

**C0392**

Reply to LLY: Complain directly to customer service. There is it on the order page

**C0426**

What you're talking about is called a shared ride.

**C0460**

Actually, I'm quite curious. Some people say that exclusive ride means exclusive ride seats. So, let me ask you, what does shared ride mean? One seat can seat two or three people? Sitting on top of each other?

**C0494**

Reply to the genius Li Jiawei: Indeed, relatives and friends sit in the passenger seat and the passengers in the back seat

**C0528**

Reply to Bedqian Mingyueguang: Yes, the only time I took two friends to sit in the back together, the co-pilot had an exclusive ride passenger. It was almost 100% a ride and I couldn’t help but pick him up once.

**C0562**

Reply to Qiao Baobao: There is only one order, please send the passengers first

**C0595**

Reply to momo: Yes, so dating carpooling really depends on your luck.

**C0627**

Reply to Raye: Yes, there is an option for traveling with family members in the order

**C0659**

I always express my objections clearly first. If the other party doesn't accept it, then I sit quietly and then report it. The money is refunded when the person receives it.

**C0691**

Different places have different situations. Many people here are just greedy, because there were a lot of black cars and high-priced cars in the past few years. They are used to huge profits and do not accept regular money making. To them, as long as it is not the kind of violation that will lead to immediate arrest, other minor and minor violations of the law do not matter at all.

**C0723**

Reply to TS Sijun: What you are talking about is Didi Express. Carpooling is possible. You can mark relatives and friends in it. Passengers can change their order if they mind.

**C0754**

Reply to ohimlccs: Then if he tells you that he is a relative, there is nothing we can do about it.

**C0785**

I often go out to see if there are any carpooling passengers, but I can only take one relative or friend with me at most. If there are two, I will definitely not take carpooling passengers again. Both sides are worried.

**C0816**

If you take an exclusive ride, he can pick up another person for a shared ride. I think there's no problem in sending you off first.

**C0847**

This should have been regulated long ago. But honestly, there are too few genuine carpool drivers. If all these others were banned, most people's travel needs wouldn't be met. The platforms also take a large commission; not everything you pay reaches the driver. So drivers ask for extra money. It's a vicious cycle: passengers foot the bill, and the market is chaotic.

**C0878**

I'm a car owner, and I also recommend reporting these full-time carpool drivers directly when you encounter them! The platform will refund you!

**C0909**

Reply to 就想吐槽: I complained and also reported the driver for operating an unlicensed taxi.

**C0940**

Last time I booked a ride outside a hotel in Tonglu, the driver accepted instantly and was right at the entrance. I said I'd never had a driver that close. He said he would wait there again after dropping me off, because the previous passenger had canceled after he'd driven from the station to the hotel—less than a kilometer.

**C0971**

That was me this morning.

## 34. Hate shared rides

Source: https://www.rednote.com/discovery/item/6aa67c44000000000d025a8e
Original record: 50_posts_1000_comments / N14
Text scope: Visible excerpt in source dataset

Hate shared rides
At first, four people were picked up in the car, and then they were dropped off one by one. I was far away and the last person dropped off me. I can understand it, but I don’t understand it when I drop off one person and have to pick them up again. Isn’t everyone’s time? , I originally thought that the shared ride would not be particularly time-consuming, but when I walked from Renshou to Dujiangyan at 2:30 in the afternoon, it was already 8:30 in the evening. It only took me 3 hours to take the subway and bus, and it only cost 40 yuan. I took the shared ride for 65. Not only did the ride time become longer, but I also walked a longer distance and kept taking detours.
09-13

### Comments

**C0013**

Reply to Don’t Want to Go to School: Can’t I just take the subway or bus next time?

**C0058**

Reply to Don’t Want to Go to School: You have to confirm the exclusive ride before accepting the exclusive ride. I have encountered your situation once. This is the professional shared ride Didi. I basically take an exclusive ride home by taxi, and it is almost a very clean private car.

**C0100**

Take the premium ride service or the exclusive ride. Sometimes the driver will even pay you for the full ride and you still have to spend the money on the exclusive ride.

**C0140**

The reply is that dizziness is normal: Even if there is no detour, I will not pick up the shared ride order and I will not be responsible for highway tolls.

**C0179**

Time and money are equivalent to a certain extent. If you don’t want to spend time, you have to spend money.

**C0218**

Next time I will teach you how to look at the car model after you take a taxi, and you will be able to tell what a professional is. The decisive decision to cancel professional is always

**C0253**

Yes,

**C0288**

I don’t even watch shared rides that don’t have highway tolls.

**C0323**

Reply: I don’t want to go to school: But at least the probability is high and there is a high probability of priority. The shared ride may also become an exclusive ride, so I’m sure I won’t say anything. Carpooling is to open a blind box, not to operate a car. Cheapness is the first priority, otherwise I believe that most people have no choice. Taking an express car is a matter of minutes.

**C0358**

Reply to Day does not understand the darkness of night:

**C0393**

Reply: I don’t want to go to school: Yes, I went to Chengdu from Jintang before, and the driver insisted on charging me for the exclusive ride. I decisively said that I would get off the car, cancel the order, and take a new exclusive ride.

**C0427**

Carpooling is to allow more people who cannot afford express trains to ride in small cars.

**C0461**

There’s no way around carpooling! Either negotiate the fare for an exclusive ride, or take an express train

**C0495**

Shared ride time is inherently garbage time

**C0529**

I went to a concert on the weekend and took a shared ride for the first time, which cost me an extra 30 yuan. Not responsible for highway tolls (highway tolls65). The driver said it well, let me go in the afternoon. Fortunately, there is still room on the bus.

**C0563**

I take exclusive rides every time, and I haven’t encountered many platforms that accept orders so far.

**C0596**

Now exclusive rides also pick up people. I asked the driver if I ordered an exclusive ride, and he said that you ordered an exclusive ride and not a chartered bus.

**C0628**

Reply to momo: I took an exclusive ride once, and the driver picked up one at another platform. That person was having a wedding banquet with a friend, and he vomited after drinking the wine. I'm going crazy

**C0660**

You can make it clear in advance that you will get off at the same point [kiss an R]

**C0692**

Take Didi Express

**C0724**

For gas cars or electric cars with a price tag of over 200,000, the car owner will bear the highway tolls. This is basically true carpooling. Add exclusive ride insurance. Cheap shared rides will only encounter professional illegal cars.

**C0755**

Reply to momo: Definitely reported it. I was so angry at that time

**C0786**

You can take an exclusive ride. The price of the exclusive ride is not much different.

**C0817**

Talk about the purpose of carpooling

**C0848**

Just book an exclusive ride and there won't be a problem.

**C0879**

We want to rent a three-wheeler for 150 in total and need two more people.

**C0910**

Reply to 不想上学: If you book a shared ride, it will definitely be shared.

**C0941**

You probably got a full-time carpool driver. Genuine car owners wouldn't do that.

**C0972**

The Shenzhen–Zhuhai route has become a commercial operation. Different cars accept online bookings, pick people up, then meet somewhere to transfer everyone into one car for the drop-offs.

## 35. Didi is probably the best I have ever seen in redefining "shared ride success"

Source: https://www.rednote.com/discovery/item/6ac6545d00000000180161a8
Original record: 50_posts_1000_comments / N15
Text scope: Visible excerpt in source dataset

1/5
Didi is probably the best I have ever seen in redefining "shared ride success"
Didi is probably one of the platforms I have seen that is best at redefining “shared ride success”. Today, I took the carpooling shared ride. All four passengers completed the shared ride normally through the platform, and the actual number of passengers has obviously reached the shared ride status. When placing an order, the platform swore that if the shared ride of this order is successful, a cashback of 10 yuan will be given. The result? The car was actually booked, and the seats were indeed filled with passengers. However, the cashback promised by the platform was like suddenly entering the state of "Schrödinger's shared ride success" - as long as it involves cashing in on the offer, the ride can be declared "unfinished." What’s even more interesting is that after I contacted customer service to ask about the cashback issue, the customer service kept explaining repeatedly that “the order was not completed”. But when I further explained that there were indeed other shared ride passengers on the car, the platform’s approach became very “flexible”: since the platform itself couldn’t explain it, it directed the problem to the driver. This way of handling is indeed very "platform wise" - when making discounts, it's about the rules, when it's cashing out, it's about the system, and when there's a dispute, it's about the driver. As for whether consumers actually completed the shared ride, it became the least important thing. I originally just came to inquire about the 10 yuan cashback promised by the platform, but in the end I experienced a complete process of "how to transfer the platform's responsibilities layer by layer" inexplicably. Of course, the platform finally stated that it would deal with the relevant drivers and promised to "suspend services and permanently ban them in serious cases." As for the cash rebate issue that consumers initially reported, it was downplayed. It has to be said that this service concept is indeed breathtaking: consumers are required to believe in the rules of the platform, and the rules can be reinterpreted when the rules really need to be fulfilled. The 10 yuan is actually not important. What is important is that if a platform can so easily shirk its promises to consumers, then what should consumers believe? I hope Didi will continue to maintain this "user first" service attitude in the future. After all, it is a rare ability to handle such a simple cashback issue with such twists and turns.
10-07 Guangxi

### Comments

**C0014**

Reply to iceberg-xt: When I was on a bus, my order showed that it was not completed, but there were other passengers on the bus, and I asked them that they also ordered from Didi; I can only say that it is not ruled out that Didi transfers the order to other platforms, and the driver receives the order through other platforms (but even so, the platform is not strictly regulated, and as a transfer station, you should be able to see the vehicle information for the resale order)

**C0059**

Now the same car will send out several orders at the same time, with the time and address staggered a little. One order is for one person, and up to four orders can be received. In this way, it is still unassembled on the platform.

**C0101**

Didi can accept 4 exclusive rides in the same time period

**C0141**

Reply to Xiao Hongshu 5CBBB726: Every time I look for other orders from the shared ride order, I have to go dozens of kilometers away. Many of the orders on the way have to be picked up separately from the lobby to see them. It turns out that there is a saying that you can get your money back if the spell is not successful. I learned about it for the first time today.

**C0180**

Didi shared rides have three or four passengers each time, and they have never refunded me the price difference.

**C0219**

Reply to Xiao Hongshu 5CBBB726: The car owner cannot receive the unsold price. The unsold price paid by the passenger is only a fixed share price, so there is no need to think that the unsold ride equals an exclusive ride, because the car owner can only see the shared ride, and the difference is eaten by the platform. You have to manually find the platform to refund the difference. Passengers will not be refunded if they do not go to him. The platform is beautiful.

**C0254**

I also encountered this today. The passengers were all booked on Didi, but the platform said they were booked privately.

**C0289**

Reply to iceberg-xt: It’s not from the same order, right?

**C0324**

There is a high probability that other passengers did not get the ride on Didi. Hello and Yiwei may pick it up. Didi cannot detect it on other platforms, and the money deducted for successful rides is also the car owner's money.

**C0359**

It is indeed the driver’s problem. The driver violated the rules for cross-platform shared ride, which resulted in the Didi platform not being able to detect that the order contained a shared ride.

**C0394** (post author)

Reply: The cockscomb did not fall off: Yes

**C0428**

Reply to iceberg-xt: It is also possible that the car owner has two accounts registered with different mobile phone numbers.

**C0462**

Reply to Xiao Hongshu 5CBBB726: Didi is so dark!

**C0496**

How to deal with it later?

**C0530**

Easy to pay but difficult to refund

**C0564**

Reply to Xiaolu: Yes, it is equivalent to receiving 4 orders on the same platform. If they are not put together, it will not be considered a success.

**C0597**

Objectively speaking, this regulation is unreasonable.

**C0629**

This may work like this. The driver issued multiple itineraries and then only picked up one shared ride passenger for each trip. Therefore, although the four people all placed orders with Didi, they were not actually in the same itinerary. This should be regarded as a loophole in Didi's rules.

**C0661**

I once placed an order on the Didi platform and saw the information of another passenger that had been combined, but the information of the other passenger disappeared after I got off the bus.

**C0693**

Replying to the memory of the wind: Only coupons are refunded, sometimes they are not refunded

**C0725**

Didi shared rides can be used for up to two orders, and there is no such thing as four orders. Driver's illegal operation

**C0756**

Reply to Meeee-Save your character for lottery: No, the same number is also ok. A driver who I am familiar with has told me that as long as I post multiple itineraries and stagger them a little, I can pick up the orders separately and then pick them up together without showing that they are not spelled together.

**C0787**

Reply to iceberg-xt: It’s a platform problem. They are all the same car, and they are both on the Didi platform. Why can’t they detect it? The platform took the money.

**C0818** (post author)

The four of us passengers all used Didi Pinpin.

**C0849**

Baidu Maps does the same thing... Companies are so good at shifting conflicts onto everyone else...

**C0880**

Every time, I'm added to someone else's shared booking. I've never had the luck of ending up with the car to myself.

**C0911**

They won't refund it. I've been caught out before: everyone had clearly booked shared rides, but customer service was just a bot endlessly passing the buck. They simply wouldn't refund the fare difference.

**C0942**

Reply to 小鹿同学: [No reply text in source]

**C0973**

As long as the driver doesn't accept bookings under the same trip, it doesn't count as a successfully matched shared ride. The driver probably posted four separate trips and accepted four bookings.

## 36. Please consider business seats (lightning protection) carefully when returning from the Kai Tak concert

Source: https://www.rednote.com/discovery/item/6add525d000000002c03a75b
Original record: 50_posts_1000_comments / N16
Text scope: Visible excerpt in source dataset

LIVE
1/3
Please consider business seats (lightning protection) carefully when returning from the Kai Tak concert
After a concert in Kai Tak, I returned to the mainland and wanted to be more comfortable. I booked a shared ride in a business car, priced at 258 seats. It turned out to be the worst experience of the night. Off topic: The first male in the world this week! 1⃣ We agreed to meet at 22:55 and go to Shenzhen Bay, but the driver actually arrived at 23:10 and changed to Huanggang without saying a word. The group notified us that we must be at the boarding point before 22:55. We basically arrived on time, only one person was a little late, but the bus did not leave until 23:10 at the end. Delay was not the problem of the passengers at all. Before departure, people in the group kept talking about taking the Shenzhen Bay route and kept urging people to do so. However, when we arrived, we went directly to Huanggang without consulting any passengers during the entire journey. Huanggang was crowded with people last night and was stuck in traffic for a long time. My friend started the bus 10 minutes later than me and took the Shenzhen Bay route, which was smooth sailing. Changing the port was a decision that delayed everyone's time, and the driver didn't even say hello. Later, I was told that the port of call is decided by the driver alone. 2⃣ The boarding point was notified of the taxi stand here, but it was actually on the opposite side. There was no reminder in the group. The boarding point notified was at Exit D of the MTR station. You have to turn right and walk a while before going out. It is already far away from Kai Tak. When we arrived at the taxi stand where it was supposed to be, we searched for a long time and couldn't find the taxi. Finally we found out that it was at another taxi stand across the road. The driver didn't say "on the other side" in the group the whole time, and by default every passenger knew. The "business seat" of 3⃣ 258 is actually the connection between two seats, with a raised handle that presses against the waist (actual photo from P2). This is the most annoying thing. I can accept the random seats, but the position I was in was not a normal seat at all. It was at the joint between the two seats, with a hard handle protruding and pressing against my waist. This is not a short trip. If you sit down for a long distance, your waist will be completely useless. First of all, let me make it clear that I ran to get on the bus the whole way without delaying even a second. It’s not because I am slow that I can only sit in this seat. And even if I sit in such a seat, I have the nerve to pay 258? ? This car has a total of 6 seats, only 3 of which are normal VIP seats, and the remaining 3 people are squeezed into the small space in the back row - but the 6 people paid exactly the same price, 258. I checked the review section of his store and found that I was not the only one who was fooled (P3): some passengers encountered the same waiting and seat problems. A reminder for those who want to share ride back to Shenzhen, Guangzhou, Foshan and Dong after watching the performances in Kai Tak and Yabo: ① Before placing the order, ask questions in the chat: which port to go to, whether you can choose a seat, whether there are extra seats in the back row, and keep a written record ② Ask the driver to take photos for confirmation after arrival ③258 is really not cheap. This kind of "junction seat" is not worth it at all. It is better to choose a cross-border bus. Consider this kind of shared ride carefully.
Edited 2 days ago Guangdong

### Comments

**C0015**

The 5k per day I booked before is not like this. The services are very good. This seat is not a normal business car.

**C0060**

Reply: Well, I am Ah Zhen💋: From where to where

**C0102**

Reply%.: Oh, I can’t go back to Guangzhou haha

**C0142**

Can one person help me fight?

**C0181**

Reply to Qianqian📎: Do you have to go through it yourself?

**C0220** (post author)

I even want to call 12315 to complain

**C0255** (post author)

WeChat also has it, and they really have a bunch of excuses. . I don't know what it means

**C0290**

Our teammate is very reliable and the driver is also super fast. We got on the bus at 23:00 and set off at 1:20 to arrive at Zhengjia. Moreover, the driver did not need to change cars and drove all the way very fast.

**C0325** (post author)

I arrived at Zhengjia at 2:30 last night

**C0360**

I saw some Yongdong bus operators said they would arrive at Zhengjia before 1 o'clock, but I don't know if that's true.

**C0395**

Reply to Running around and being confused🐣: There are comments

**C0429**

How much does it cost?

**C0463**

Please introduce the fleet

**C0497**

Reply to Mr. Bao (diary version): 1400 6 people

**C0531**

Mainly because the Shenzhen Bay Port closes at 12 o'clock, and it's still a long way from Kai Tak back to the Shenzhen Bay Port. So at this time, we can only go to Huanggang Port.

**C0565**

Reply to Mr. Bao (diary version): You can pass the customs on the three-way train in the car

**C0598**

Is it really difficult to only be early, not late, not to increase prices at short notice, not to let go and serve attentively? Don’t blame others, blame this industry for being a mixed bag

**C0630**

These cars are illegal in Hong Kong and there is no guarantee if something happens to them.

**C0662**

Reply to Xiaomi Miao: Maybe Xinhuanggang is poor, so if you can go to Shenzhen Bay, he wants to give priority to Shenzhen Bay. If you go to Guangzhou, the journey is relatively far. The car rental company is not so thoughtful. I have tried to organize it once before, with three people in the second and third rows, plus one person in the front row, a total of seven people. But our destination is Huanggang, so it’s fine. Haha

**C0694**

I only confirmed the commercial vehicle for the 200 return trip to Panyu Nancun the day before the opening. The communicators and teammates were very good ~ more than 10 people got on the bus at 10:40 and 50:00, and we arrived at the destination before 1:30.

**C0726**

Sister, is this your first time taking this bus back to the mainland? Six/seven-passenger buses for concerts will always take Huanggang by default. Because there are too many uncontrollable factors, there is no time to go to Shenzhen Bay. In addition, the six/seven of you may not all know each other for the concert, so it will take a certain amount of time to find the bus at the pick-up point and gather. In addition, the seating issue is the problem of this car rental company. If they only accept five people on the bus, then the price per passenger will be higher if the total price remains the same. You passengers can discuss with the car rental company whether you want something more comfortable or cheaper.

**C0757** (post author)

And I don’t know if he left Huanggang after he deviated. Anyway, I kept hearing the navigation saying that you have deviated.

**C0788** (post author)

They say that the buses that go to and from Hong Kong to the Greater Bay Area all look like this, so I don’t know if it’s true or not, but I think everyone who sells business cars definitely doesn’t want to enjoy such treatment. Otherwise, don’t sell this seat. You have to make this money and charge the same price to you. It’s so cool.
Pinned comment

**C0819**

Reply to Hong Kong and Macau travel reception: Kai Tak to Dongguan

**C0850**

Which company? Let me check whether it's the one I booked.

**C0881** (post author)

The name is here. If I remember correctly, their WeChat name was something like Yang Shao.

**C0912**

Same here. The one we found was utterly ridiculous too.

**C0943**

Normally, 600 is enough for the return trip.

**C0974**

Reply to BuzzWoody: @Ascot

## 37. Shared ride follow-up｜shared ride driver praises and posts

Source: https://www.rednote.com/discovery/item/6adf633400000000150134be
Original record: 50_posts_1000_comments / N17
Text scope: Visible excerpt in source dataset

1/9
Shared ride follow-up｜shared ride driver praises and posts
✨Chiang Mai shared ride｜A blessing in disguise! I found a treasure and the Chinese driver praised me ✨ Originally, my friend Momo suddenly missed the appointment, so the shared ride was cancelled. I was a little depressed, but I didn’t expect that I made an appointment with a great driver! Originally, the initial itinerary only included Sticky Waterfall + Elephant Baba Papermaking, but we temporarily added Elephant Camp and Blue Temple the night before, and the chef readily agreed! The key point is to be fluent in Chinese, there is no need to worry about communication barriers, and the whole process is smooth in Chinese 👍 ✅ We were picked up at the hotel on time in the morning, and we officially set off after checking the itinerary 💦First stop | Sticky Waterfall. The chef was super considerate! We prepared mosquito repellent in advance, and even lent us a waterproof mobile phone bag to deliver to the entrance. After the tour, we even helped deliver a change of clothes to the store. It was full of details! 🔵Second stop | Blue Temple. At the door, he also shared the local bananas he brought, which were sweet and delicious~ He took us to the main hall first, patiently taught us the etiquette of worshiping Buddha, and then we were free to visit. After shopping, we were treated to an amazing durian ice cream 🍦 🐘The third stop | Elephant Camp happened to be raining heavily and there were very few tourists! The interaction with elephants is a great experience! Little easter egg 🥰 There is a very cute little elephant. It has been playing on the swing and is still stuck on the swing. Finally, the elephant mother comes to help rescue it. It is so cute! 📜The fourth stop｜Elephant Papa Papermaking Experience Camp: Hand-laying paper + DIY crafts, very interesting! 💆On the way back, I heard that we wanted to cook horse and chicken, and the chef recommended a shop opened by his sister, which is near the ancient city! The technique is very authentic and the acupuncture points are found very accurately. I feel slightly sweaty after the massage and my legs feel relaxed! 💡: This master is more than just a driver! He is also a translator, local tour guide, and will also help with taking photos. He is attentive and reliable! I was originally in a bad mood because of the no-show, but it turned out to be a blessing in disguise~ Friends who come to Chiang Mai and want to rent a car can really go to this master!
Edited yesterday at 15:27 Thailand
Say something...
Comment

### Comments

No sampled comments in the supplied dataset.

## 38. After watching the princesses who will share the ride home that day!

Source: https://www.rednote.com/discovery/item/6ad8bf5c000000002c0226c7
Original record: 50_posts_1000_comments / N18
Text scope: Visible excerpt in source dataset

1/3
After watching the princesses who will share the ride home that day!
To share some experience, first find enough people with similar destinations to share the ride together. I asked for "exclusive ride high-end car" at Hello Carpooling, and then chose "bear all highway tolls". I went back to Wuhan for six hours, and the cost per capita for four people was 275, which is about the same as the price of a commercial vehicle. Those who sit in the front row can use a little more A. If the destination is closer, it will usually be OK to take a short detour to take me home. ps: Business cars are randomly shared for rides, or are only delivered to high-speed rail stations. It is inconvenient to take a taxi home, and the cars that are often sports cars are in average condition and the long-distance experience is not good. The prices of carpooling shared rides or ordinary exclusive rides are low, and no one is willing to take them. The car owners who are willing to take them are a mixed bag, and random shared rides are given here and there, which is not smooth at all and is very time-consuming. High-end car owners are generally more selective about orders. They are willing to take orders if the price is relatively good. They will not pick up others, and there is no need to argue. It is good. You can choose a spacious and comfortable car without paying first, and the driver must have driving experience. You can also call the car owner to confirm the time. You can cancel if you have not agreed. I think the price is reasonable and acceptable. After all, driving is quite hard. I have taken taxis like this several times, and they are always punctual, trustworthy and easy to communicate with. We also rode punctually and quietly! And if you check this box, your order will be received very quickly, and you can go in both directions! pps: In addition, you can choose to gather at the outlet parking lot (at the Ferris wheel opposite the venue). Parking is free, easy to find, and relatively close. If there is a more suitable meeting point please let me know! ! [心心眼R] I hope everyone can find a good car and a good car owner and get home safely and comfortably [reply hello] [reply hello]
Edited 6 days ago Hubei

### Comments

**C0016** (post author)

Temporarily full unless there are pigeons

**C0061**

Reply to Ma Ya Ya He 😼: Great

**C0103**

Princess, is your car back to Wuhan after the show on 11.15 fully booked?

**C0143** (post author)

Reply to official reminder: Temporarily full unless there is someone else

**C0182** (post author)

There is one recent comment. Take a look.

**C0221** (post author)

I made an appointment now, there are more choices

**C0256**

Squat on No. 8!

**C0291**

Princess, are you ready?

**C0326** (post author)

I'll be there next month. It's usually very difficult to get there. Everyone takes the high-speed rail.

**C0361**

I’m going to leave Wuhan on the 11.8th.

**C0396**

Princess, do you want to make a date now?

**C0430**

Reply to Ma Yi Ya He 😼: Okay

**C0464**

Let’s go together from Wuhan on November 6. We can return on the 8th or 9th.
Pinned comment

**C0498** (post author)

If you can fight to get the Martians on your way, it's best if you can't fight. That's it.

**C0532**

When are you going? There are still a few people left to go on the 23rd.

## 39. A shared ride trip to Arctic Village, a day spent with five strangers

Source: https://www.rednote.com/discovery/item/6ae0c37e0000000023030dcb
Original record: 50_posts_1000_comments / N19
Text scope: Visible excerpt in source dataset

/
A shared ride trip to Arctic Village, a day spent with five strangers
When I got off the bus to pick up my luggage, I chatted with a gentle sister. I learned that she was traveling alone. She met a fellow villager in the car, a boy who was also traveling alone. We discussed that the three of us could go on a shared ride together. We all arrived at our respective accommodations first and put our luggage. We stayed in a B&B. The two girls next door to me wanted to go on a shared ride. The owner of the B&B suggested that he could take us along, so I sent a message to ask if the sister and the little boy I met after getting off the bus wanted to go together. They readily agreed. So the five of us set off together. It was a great experience. Although it was the first time we met, everyone had good personalities. We took care of each other and chatted along the way. We had a lot of fun on the trip. We were not lonely or embarrassed at all.
4 hours ago Heilongjiang

### Comments

**C0017** (post author)

Wild ice is really dangerous! We were startled when we heard the sound of ice cracking. Please don’t go out on the ice casually when you come here! Has anyone ever stepped on wild ice?

## 40. Shangri-La｜Perfect Napa Sea shared ride around the lake experience🚗

Source: https://www.rednote.com/discovery/item/6ac10c1e000000001303e228
Original record: 50_posts_1000_comments / N20
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
1/18
Shangri-La｜Perfect Napa Sea shared ride around the lake experience🚗
Itinerary 📅 - Arrive at Shangri-La in the morning and settle your luggage first, then take a stroll in Dukezong Ancient City. Or you might have gone straight to do your makeup in the morning at Shangri-La, and then went to Napa Beach to take some photos! - At 1 o'clock in the afternoon, we gathered in the ancient city and started the shared ride around the Napa Lake. After playing for about three or four hours, we returned to the ancient city. Today's return journey was still a bit congested... we will stop at about four or five scenic spots along the way, where you can take photos and check in. The main ones are the large prayer flags ➡️Gate of the Sky Observation Deck ➡️I can't name it but you can stack Manidui Lake ➡️Jiaorong Village Prairie ➡️ Drive all the way back to the ancient city It is indeed the closest place to heaven. You can take pictures at any time. You can feel the wind of freedom in the prairie. Some random thoughts: I accidentally saw a shared ride post on my trip to Shangri-La. I didn’t expect it to be an unexpected and awesome experience. It was well worth the money.
I met the e-Ren driver who has many experiences and has many jobs. Unexpectedly, he is also the owner of a B&B! Perhaps the meaning of life is to continue to experience life, to meet and feel, and to find what you truly love. Therefore, fate is sometimes a very wonderful thing [reply hello] Amway is especially suitable for friends who are inconvenient to take a solo trip, or for two or three people who do not choose to drive by themselves! It saves you worry and trouble when traveling, and you can also have someone to take photos with 😃 (among other things, the driver can also take photos haha)
10-03 Yunnan

### Comments

**C0018** (post author)

Arrangement Shangri-La True Hiking Paradise [Reply Hello]

**C0062**

Want to go to Antarctica

**C0104**

Sister, where are you sharing the ride? We’ll be there tomorrow too

**C0144**

Oh my god! Thank you so much. I asked why so many people asked me today, haha! ! Thank you! !

**C0183** (post author)

You can contact @小六小六CYQZYZNZDLM📷

## 41. Two days and one night in Jiuzhaigou, only personal experience, for reference only

Source: https://www.rednote.com/discovery/item/6ae02309000000000d01ccbc
Original record: 50_posts_1000_comments / N21
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
LIVE
1/8
Two days and one night in Jiuzhaigou, only personal experience, for reference only
We went to Jiuzhaigou on the 24th and 25th. 1. Regarding high reflexes: It varies from person to person. My personal constitution is more prone to high reflexes. It is said that Jiuzhaigou is not prone to high altitude sickness. But I had high fever when I went to Jiuzhaigou a few years ago. Whenever I go to plateau areas, I have high fever. My symptom of high fever is headache. This time I took my mother there. I ate Rhodiola rosea a week in advance and Gaoyuanan on the day of the trip. Neither my mother nor I had high fever this time in Jiuzhaigou! 2. Regarding dressing: My mother and I both wear three-in-one jackets, jeans + long johns. The temperature difference between morning and evening is really big, so the three-in-one jacket is really convenient. 3. Regarding transportation: high-speed rail + shared ride. Before traveling, I read a lot of guides. Some said shared rides were good, while others said they were bad. I still hesitated for a long time and chose shared ride! I don’t want to take the bus, it takes a long time + I’m afraid of motion sickness. The car I got this time is a nine-seater business car, which is really comfortable to sit in! The driver is also very nice, and he doesn't drive very fast. They have a speed limiter installed on the car, which will start to remind you when you exceed the speed limit. The master will take you to a hotel near the scenic spot or a place to store your luggage according to the needs of the passengers on the bus. I live in Guou Nei, and there is a centralized place for storing luggage. As soon as I mentioned my name, the master knew where it was. After I put it there, I continued to get on the bus and took it directly to the entrance of the scenic spot. On the return trip, it is also a shared ride. However, during the recent peak period, nine-seater commercial vehicles were restricted at the entrance of the scenic spot and could not come to pick up people. They were waiting in the Moon Bay parking lot. Be sure to pay attention to the time! The shared ride was at 5pm. We left the scenic area at 16:30, and then went to the cultural and creative store to buy something.
, thinking that the shuttle bus is very close to the Moon Bay parking lot, and it will be there in a few minutes. But it’s not like this. There are a lot of people queuing up for the shuttle bus during peak hours, and there are not that many shuttle buses. Seeing that it was 5 o’clock in more than ten minutes, I quickly took my mother to the opposite road and took a taxi to the Moon Bay parking lot (10 yuan/person). 4. Regarding accommodation: I really recommend staying in the scenic area! It’s really convenient and saves a lot of elbow strikes! We stayed in a B&B near Sunilang Central Station, and it was really convenient to take the bus! The room in the B&B I stayed in was quite large, and the floor heating was super sufficient, so I didn’t have to be afraid of the cold at all. If you stay at a B&B in Gouni, you must enter the scenic spot before 2 p.m., and you cannot enter the scenic spot after 2 p.m. 5. Regarding play: On the first day, my mother and I entered the park at 1pm. It was not crowded at all at that time. We wanted to go to the left line to play. The bus was bound for the right line, so we transferred to the left line at Sunset Lang Center! After playing the left lane on the first day, we went back to the B&B to rest. At 8:05 the next morning, we went out to Sunset Lang Center to take the bus bound for the right line. It was not crowded at all when we got on the bus, and everyone got on the bus in an orderly manner. It was on the sightseeing bus from Panda Sea to Wucai Pond that I felt the power of the elbow! The seniors are all warriors, very powerful
. During other times, it was fine. It was crowded but people got on the bus in an orderly manner and no one jumped in line. The center line we went to in the afternoon was not too crowded. It is recommended to hike from the Spark Sea to the Reed Sea. This road is really beautiful. The weather is good and the walk is really beautiful!
15 hours ago Sichuan

### Comments

**C0019** (post author)

I found the car from a travel agency on Xiaohongshu.

**C0063**

Polite borrowing of flats and cars

**C0105**

What kind of shared ride is it? Is it a shared ride that can be taken on the platform?

**C0145**

Can you recommend a B&B? Thank you

**C0184** (post author)

@jiuzhaiahranran this

## 42. It was my first time to go to Guilin, and the experience was different from what was said online.

Source: https://www.rednote.com/discovery/item/6ae042670000000015022222
Original record: 50_posts_1000_comments / N22
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
LIVE
LIVE
1/5
It was my first time to go to Guilin, and the experience was different from what was said online.
It is my first time to go to Guilin. I would like to share my opinions, which can be used as a reference for Xiaohongshu’s brothers. Day 1: We set off from Shenzhen, taking the high-speed train at 8 o’clock, and it was already around 12 o’clock when we arrived at the hotel room. The weather is very cool in October, and the walk along Binjiang Road between the Sun and Moon Twin Towers and Jiefang Bridge is extremely comfortable and relaxing. I also booked a hotel near here, with Zhengyang Pedestrian Street behind it (this pedestrian street is more ordinary, an ordinary pedestrian street). I went to Elephant Trunk Hill in the afternoon (to be honest, it felt very ordinary, and it was a good place to go. After going to Elephant Trunk Hill, you can also take a taxi to any scenic spot, the price is not expensive, about 10 yuan). In the evening, I went to Riyue Bay Pier and took a walk in the direction of Ronghu Lake. It was not bad, and the check-in point was also on this road. The next day: Here is the highlight. When traveling on the Li River, it is recommended to go directly from Mopanshan to Yangshuo. And you have to buy the Samsung cruise that leaves at 9 a.m., the price is 213/person, so it won’t be very hot in the middle. My recommendation is not to listen to what Xiaohongshu said and buy the best section. The best section is from Yangshuo to Guilin. This way you have to take a taxi back when you get there, which is a waste of time. Moreover, most of the road from Mopan Mountain to Guilin has very good scenery. It is not bad to enjoy the scenery on the boat, and you can catch up on your sleep later. After arriving in Yangshuo, you can actually check in for the Thousand Miles of Rivers and Mountains Tour within the limited time. Just buy the group ticket for the Thousand Miles of Rivers and Mountains directly on Meituan. The round trip only costs 75 (but the boarding and alighting time is fixed, which is definitely enough time to check in). Don’t listen to the online talk about shared rides. Shared rides cost 50 one way and are difficult to get back. Buying tickets on Meituan includes return trip. Day 3: Yulong River Bamboo Rafting in the morning. Just listen to the information on the Internet. You can buy the best section and take a taxi back to Gongnongqiao Comprehensive Wharf for 6 yuan. All scenic spots such as Yinziyan, Xianggong Mountain, and Thousand Miles of Rivers and Mountains are purchased from Meituan, which includes tickets and transportation. Don't take a shared ride on Xiaohongshu, it's a waste of time. (I see some people say that shared rides are one-way. If you don’t believe me, you can try it yourself.
) Shili Gallery and other attractions where you need to rent electric vehicles. My advice is, don't rent. The sun is very strong and can cause sunburn, and from my point of view, Shili Gallery is just an ordinary farmhouse. I didn’t see any pastoral scenery, or I was going to ride into an unknown rural area. When going to Yinziyan, Shuiedi Pier and other places, you will pass by Shili Gallery. Regarding eating: The Guilin Shaode Xiaoyaolou store has plenty of portions and the taste is OK (note, the portions are very generous!); Yangshuo Wangjiang Restaurant is also OK (sour and spicy); Lao Xu’s feels like it’s passable; Huahong Xike is a failing restaurant for me, so be careful! About accommodation: Guilin lives near the Sun and Moon Twin Towers. If you live in Yangshuo, you can have the best view of the Yulong River, or if you live near the Li River, don't be too far from West Street (but West Street itself is actually relatively ordinary). Note: Xianggong Mountain and Thousand Miles of Rivers and Mountains are two scenic spots, one for sunrise and one for sunset. However, both of them are more productive if you go to check in in the morning; Yinziyan will put up some messy lanterns on the rock wall, so you don’t have to go if you don’t have time; the experience that Shili Gallery focuses on may not be as good as the Li River Cruise
13 hours ago Guangxi

### Comments

**C0020**

May I ask which section of the Yulong River bamboo rafting section you are talking about specifically?

**C0064**

Reply to buu: OK, thank you

**C0106** (post author)

Shui Edi to Comprehensive Pier

**C0146** (post author)

Hanting Riyue Bay, Hanting West Street. If you are in Yangshuo, maybe you can see the Yulong River view from the hotel. Anyway, taxis in Yangshuo are not expensive, they only cost a few yuan.

**C0185**

Teacher, what hotel are you staying in Yangshuo?

## 43. Detailed money-saving guide for girls to brave Altay alone for 3 days and 2 nights

Source: https://www.rednote.com/discovery/item/6ae0651600000000150029b4
Original record: 50_posts_1000_comments / N23
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
LIVE
LIVE
1/14
Detailed money-saving guide for girls to brave Altay alone for 3 days and 2 nights
I received a lot of concerns from girls in private messages about how to play Altay, so I posted a strategy post in the hope that it can help everyone [Bang R][Bang R] 💃Personal situation: I decided to try an aimless trip alone, with no fixed time and no plan, just play as the situation dictates. I am very grateful for the public security management and simple folk customs in the Altay region. I experienced this trip perfectly and flawlessly. Xinjiang is my second hometown! ! ! 🚘The day before departure: 1. Booked a one-night B&B in Baihaba at 10 pm 💰182R 2. Called the owner of the B&B to ask for the shared ride driver’s phone number, and made an appointment for the shared ride from Altay Station to Baihaba 3. Bought the [Baihaba-Kanas-Hemu] winter combined ticket 💰100R. ⚠️⚠️There are no shuttle buses in winter scenic spots‼ ️If you have no snow driving experience, please recommend shared ride. 4. It is very simple to apply for the border defense permit online through the mini program 💃💃 Departure on the first day: 1. Departed at 4 am and took the train from Karamay to Altay (💰58.5R) and arrived at 9 am. The driver picked up on time. The journey took 2 or 4 hours. Be careful to drink less water. The business car has 6 seats and the single shared ride is 200R. The driver is a native of Baihaba, Kazakhstan, which is very nice. 3. Arrive at 1pm and play with two super nice girls from shared ride. There are many hounds raised in the village to resist wild beasts, and cattle and horses roam everywhere; the lambs have gone to the winter pasture, and the summer pasture cannot be visited. Eat: Ashanyu Pot (the spicy beef burger is super delicious, a big one) 💰42R 4. We visited the sky grassland, explored the village, and the observation deck on the right. When we walked deeper into the observation deck, there were many Kazakh locals living inside, and there were also B&Bs. It started to snow that day. For dinner, we recommend the Ranger Restaurant, the local hot pot 💰237R, enough for three girls! It snowed heavily in the evening and went back to the B&B to rest early. 💃💃 Departure on the second day: 1. Prepare to leave for Kanas in the morning. Traffic was restricted due to heavy snow overnight (in winter, the possibility of traffic control must be included in the itinerary). Then we climbed to the observation deck on the left side of Baihaba Village. The whole village was very beautiful in the snow and fog. Lunch Spicy Burger 2. The traffic control was lifted around 12 o'clock. The driver asked his father to drive off-road and take the three of us girls to play. It was equivalent to chartering a car to Kanas and visiting the three bays and one lake for a whole day. It was a great value 💰400R, 133R per person. 3. After the snow, Kanas is simply the king of northern Xinjiang, and the mountains and rivers are astonishing! ! Hiking on the plank road is basically a simple walk for a while - you must take a walk on the plank road by Kanas Lake. It was too cold and I went back to Kanas New Village early in the evening to eat and sleep. Accommodation 💰192R, meals 💰more than 100 (dining in Kanas is expensive) 💃💃Departure on the third day: 1. Get up early and hike from Xincun to Kanas New Bridge (Navigating Queen's Creek), the scenery is not inferior to Sanwan! ! ! 2. Since I was climbing mountains all the time in the first two days and walked tens of thousands of steps every day, my legs were broken on the third day. In addition, it was already several degrees below zero in Kanas and it was a bit torture to go out. In the afternoon, I parted ways with the girls who were traveling with me. I returned to Karamay to rest for a few days and think about the next step. Return to Beitun shared ride💰200R [stick R] end of the battle
Edited 5 hours ago Xinjiang

### Comments

**C0021** (post author)

It’s also snowing on October 17th and 18th.

**C0065** (post author)

Regarding shared ride or self-driving: I drove alone in Karamay for a day. I rented an SUV for 159 per day and paid for gas for 195. I was so tired that I lay in the hotel for two days. It’s really not as good as shared ride.

**C0107**

Reply to Li Lan, Fatty Devil: Yes ~ different feeling ~ different beauty

**C0147** (post author)

It's private to you. You can negotiate the price.

**C0186**

Do you think it’s appropriate to stay in Baihaba for only 2 days? Because I just visited Hemukanas in September. Is Kanas beautiful?

**C0222**

It’s 600+ online, Qunar.com

**C0257**

Reply to Li Lan Fatty Devil: I probably won’t go to Hemu. I’ll probably go to Urumqi, then take the Urumqi train to Beitun at night and sleep. Then Beitun will go directly to Kanas for two nights, to Baihaba for two nights, and then return to Beitun to Karamay or Yining. I don’t know if I want to stop in Jiadengyu, Burqin or Altay city.

**C0292**

Please contact the taxi driver

**C0327**

Reply to Li Lan Fat Devil: Where can I drive to Karamay?

**C0362** (post author)

Already private

**C0397**

Reply to Li Lan, Fatty Demon King: Oh oh oh, this is very economical. It’s just that he needs to drive an hour back to Baihaba’s home. How do you get back to Karamay from Kanas?

**C0431**

Hahahahahaha the battle is over, so cute

**C0465** (post author)

To sum up, if you are just looking for a car to visit Kanas, the price of Kanas B&B to Three Bays and One Lake alone is between 33-50 yuan.

**C0499** (post author)

The scenic spot where I live is Kanas New Village

**C0533** (post author)

Reply to molu: The 3D immersive experience will be more enjoyable after going there

**C0566**

Picture 1 looks great! Can you give me the driver’s contact information?

**C0599** (post author)

He took us to four destinations and waited in the car. After we were done playing, he sent us to Kanas Xincun B&B. Then he went back to Baihaba's home by himself. He is a local.

**C0631** (post author)

I’m so tired. My baby in Xinjiang is so big. I can’t help but sit upright.

**C0663** (post author)

Reply to Jifeicai Qiongqiong: Baihaba is also very good. Find a herdsman to ride a horse and herd cattle to experience it.

**C0695** (post author)

The hotel also distributes it to you. It has a small courtyard~ The heating is so hot that I can't sleep in the middle of the night. I used points and got 50 off. I heard they sell for several thousand during the National Day.
Pinned comment

**C0727** (post author)

Both B&Bs are wooden houses with large floor-to-ceiling windows, so it’s great to see the snow.

**C0758** (post author)

If the price written online is expensive, call the boss and ask about the offline price. Or go and ask offline. Rooms are always available in the off-season. You can stay there for 150-200, which is very good.

**C0789** (post author)

Reply to the kite-flying monster: Very convenient. They are available in the village. If you are worried that it is not convenient enough, you can go to Hemu, which is more commercial.

**C0820**

Reply to Li Lan Fat Devil: Yeah, I understand. I'll see if it's too late. Hehe.

**C0851** (post author)

The first photo is Moon Bay in Kanas, captured just as the sun rose after snowfall. You don't get that crisp, icy feeling at other times; on sunny days it looks more lively and cheerful.

**C0882** (post author)

It depends on what you want from the trip. Kanas is beautiful in the snow too; that's the first photo. The river looks different from sunny days, like icy jade. If you want to relax and zone out in Baihaba, you might as well sit on the grass beside Queen's Creek in Kanas instead—though it is a little cold.

**C0913**

Could someone share a driver's contact details?

**C0944** (post author)

Reply to 放风筝的怪兽: Baiyang Grand Canyon, Urho Grand Canyon, Ghost City and places like that. I went around admiring all the poplar forests.

**C0975**

Reply to 李蓝胖大魔王: Is it convenient to get meals when staying in a guesthouse inside Baihaba? Are convenience stores and noodle shops open? I'm bringing a child. It's still 30 degrees in Guangdong; will it be cold there next month?

## 44. Looking for answers, fear of stepping on thunder

Source: https://www.rednote.com/discovery/item/6ad58287000000002600a7ff
Original record: 50_posts_1000_comments / N24
Text scope: Visible excerpt in source dataset

Looking for answers, fear of stepping on thunder
10-19 Guangdong

### Comments

**C0022** (post author)

I'd like to ask politely. Do you usually check the previous order records when checking your reputation?

**C0066**

What is "correction"?

**C0108**

There is a risk of being cheated but it is relatively small. If it's not possible, find someone you know, or just don't fight. It's impossible not to mention it.

**C0148** (post author)

Reply to Allow: OK, thank you teacher

**C0187**

It goes without saying that most of the shared rides around Times Peak Jun are accurate.

**C0223** (post author)

Wouldn't it be easy for the single owner to lose money and run away like this? Is there such a risk?

**C0258** (post author)

Reply to Allow: Teacher, I would like to ask if you can ask the single owner if you want a shared ride at the beginning. That is, if taking a PT will protect the people who want to get on the ride?

**C0293**

I can’t say that the price is high, it will be better anyway. If the pre-sale period lasts for three or four months, I won’t be happy to give it to someone, especially when you need money urgently.

**C0328**

Reply 0vO: There is such a risk, so if you want to book a deal, you have to keep your eyes peeled and find a more reliable group. After all, Tuanmi is not obligated to advance the full payment and wait for extraordinary construction periods. There are also some companies that do not mention accurate shipments and then run out of orders when the market price drops. If you are afraid of the risk, you can wait to receive it separately after shipment.

**C0363**

Babies, I can join the shared ride group. There is no forced ride, and it is very friendly to new babies. We will find good prices for whatever we want. The atmosphere in the group is very good~

**C0398** (post author)

Reply xw. : No, it means there are many items to be sold in bundles, but if you only want one of them, you can fight with others.

**C0432**

I thought it was Didi shared ride

**C0466**

It seems that shared rides usually transfer money directly.

**C0500**

It’s generally required. The car owner doesn’t have to pay in advance. Nowadays, big cars are missing. I usually go to someone who often does group tours, or go directly to collect them.

**C0534**

Reply 0vO: If some car owners are willing to pay in advance, they will agree.

**C0567**

I want most of them

**C0600**

Can't understand at all

**C0632**

Because if the car owner pays in advance, once the goods arrive, the driver regrets not taking them, and the car owner is at a loss. However, asking for confirmation will indeed put the driver into certain risks, so the baby can find someone he is familiar with.

**C0664**

If you are worried about most of them, you can discuss it with the car owner to see if you can make a decision.

**C0696**

Reply to 0vO: Yes, but if the pre-sale period is long, most car owners will not agree. Especially for large car owners who drive many cars, they may directly form a group or join a group.

**C0728**

Shared rides are usually tq because the car owner basically does not advance the car owner. The car owners and drivers are afraid of running away from each other, so they can only carefully screen when they are trying to fight. Find some car owners with more driving experience. Normally, after joining the car owners, the car owner will gather the group to collect the money, place the order, and send the order record.

**C0759**

Generally it is required.

**C0790**

I usually want it.

**C0821**

Reply to 0vO: Yes, you can ask the car owner for it. Some car owners will post it in the group announcement.

**C0852** (post author)

Reply to 嗯: Okay, thank you for explaining!

**C0883**

As the group organizer, I understand that some group members worry I'll disappear with their money, so I normally provide proof of my reputation. Most have joined many group orders and trust me. If I can't fill all the slots, I'll offer the remaining ones on the platform just before shipping, though the price is higher then, depending on whether people accept it. [This comment appears to concern group purchasing rather than carpooling.]

**C0914** (post author)

Reply to Wind.: Okay, thanks for explaining! [Greeting back]

**C0945**

Isn't it?

**C0976**

Group-order organizers generally don't pay upfront. You can ask her for reputation records and customer feedback. A screen recording is best, because some people steal screenshots. If you're worried, find someone who doesn't require an upfront payment, though the price may be higher. Or ask people you already know whether anyone is organizing a group order. [This appears to concern group purchasing; the source wording also refers to carpool organizers.]

## 45. (The trip to Altay has ended)

Source: https://www.rednote.com/discovery/item/6ac6471f0000000015005dea
Original record: 50_posts_1000_comments / N25
Text scope: Visible excerpt in source dataset

1/3
(The trip to Altay has ended)
"I'm asking experienced friends to tell me about the transportation and accommodation in Altay. Editor 2: Thank you for your attention. Editor 2 has sorted out my travel time and transportation and accommodation to four scenic spots in northern Xinjiang from October 10 to October 15: Let me summarize first: 1. Shared rides are available! There are many shared ride resources in the Altay area. At first, I was worried that the shared ride advertisements on Xiaohongshu were unreliable and would be put on the plane. Later, I placed an order for shared rides directly on Ctrip. ride, the experience is quite good. The shared ride I found on Little Sweet Potato is also very good. 2. The shuttle bus in the scenic area will be closed after the 16th. I don’t know if it will reopen during the snow season. It may be more suitable to drive into the scenic area. 3. There are many options for accommodation outside the scenic area. I went in the off-season and booked a wooden house in the scenic area, which is not expensive."
Finally, if you like small animals, you can bring some cat and dog food. There are many cats and dogs in Altay, and you can capture their hearts with delicious food.
Edited on 10-14 Xinjiang

### Comments

**C0023**

There is no need to sign up for a group tour. If you want convenience, you should stay in a scenic spot. On day 0, Urumqi City to Beitun City, train, on the first day Beitun to Hemu, bus, stay in Hemu Old Village, on the second day Hemu to Jiadengyu, bus, stay in Kanas Old Village/New Village, on the third day Kanas to Baihaba, scenic transportation, stay in Baihaba, on the fourth day leave Baihaba, via Habahe County to Beitun, train back to Urumqi.

**C0067**

It’s a bit more free if you don’t join a group. You can choose transportation in the mini-app to buy tickets. There are chartered cars and shared rides, but you must go in advance! I didn’t make it in advance enough before. Overall, it’s more convenient to stay in the scenic area in Kanas.

**C0109** (post author)

150 to 200 per trip.

**C0149**

Does anyone want to go like this on 11.17?

**C0188** (post author)

Just search for the name of the scenic spot and you can choose where to get on the bus.

**C0224** (post author)

OK, thanks for letting me know

**C0259**

Where can I find shared rides on Ctrip?

**C0294**

How much does a shared ride generally cost? 1,000 per person, in the order of the author’s pictures plus the return trip from Baihaba to Altay. Is it expensive?

**C0329**

The blogger remembers to make an appointment early. Orders are dispatched manually. Even if the customer service is off duty, no one will dispatch. We don’t get to work until 10 or 10:30 in the morning.

**C0364**

Reply to sofaymuiii: I stayed in two hotels in Kanas, one of which was OK (the ramen is delicious). The one where Hemu stayed was located outside the scenic area and facing the mountains (the boss can pick up and drop off the scenic area). The overall quality of the hotel in Baihaba was not as good as that of Kanas and Hemu. I recommend staying in the most famous mountain and sea hotel.

**C0399** (post author)

Landed in Altay on the 10th

**C0433**

Are these buses also available in November? ? Are they all booked through Altay Smart Travel? .

**C0467**

When are you going [End R]

**C0501**

The itinerary is the same as yours, it is also public transportation. The 200shared ride from Altay to Hemu is easy to find. From Hemu to Kanas, you can directly go to the Hemu Visitor Center. There are many people soliciting customers. From Kanas to Baihaba, just take the scenic bus. For two days in Kanas, it is more convenient to stay in the old village or the new village. It is no problem to stay in Jiadengyu.

**C0535**

Yes Altay Intelligent Travel

**C0568** (post author)

We have almost finished our trip to Sailimu Lake.

**C0601**

Reply to Pork Belly: Recommended to stay in Kanas for two nights~the most worthwhile scenic spot

**C0633** (post author)

Just search for the destination and you will find it.

**C0665** (post author)

Can I stay in Kanas for one night and visit Kanas and Baibaha in two days?

**C0697**

I’m on the 31st. Have you found a car?

**C0729**

Is there anyone who landed in Urumqi on December 1st?

**C0760**

Reply to Expecto Patronum: Do you have any recommendations for B&B?

**C0791**

Blogger Blogger I would like to ask how much is the price of the shared ride from Altay Airport to Baihaba?

**C0822**

May I ask how many days you spent in Altay? Is it the Hemu-Kanas-Baibaha route?

**C0853** (post author)

I didn't keep track. I went in the off-season; I think it was around 3,000–4,000.

**C0884**

Yes. There are plenty of chartered cars outside Altay Airport going to Hemu and Baihaba. Online, Altay Smart Travel and Xiaohongshu also have lots of shared rides; arrange one two or three days ahead. Outside Hemu Visitor Center, there are many advertisements for cars to Jiadengyu. From Jiadengyu into Kanas, you take the scenic-area shuttle. There is also a shuttle from Kanas to Baihaba; you can get off at the alpine meadow along the way. But once outside Jiadengyu, finding a shared ride along the Tiejia Highway to Baihaba is very difficult.

**C0915**

Us!

**C0946**

Is anyone going on November 21? There are two of us. We've looked at lots of tours, but the itineraries seem too rushed, so we'd like to travel independently.

**C0977**

How do you book a shared ride on Trip.com?

## 46. carpooling master, farewell to carpooling from now on

Source: https://www.rednote.com/discovery/item/6aab111200000000260171c5
Original record: 50_posts_1000_comments / N26
Text scope: Visible excerpt in source dataset

carpooling master, farewell to carpooling from now on
"Comments from a car owner who has been commuting long distances on weekends for more than a year, carpooling is too useless, don't take orders unless necessary. 1. Today is different from the past, and the price will be too low. During the epidemic, for two people and me as a passenger, for a distance of 200km, my fee was 270 yuan, and the driver got at least 240 yuan. Now, the fee for two people is down to about 160 yuan, and the driver may get 140 yuan. 2. The economy is not good and there are many poor people who are reluctant to give money and their demands are not lowered. This leads to disputes. People who used to take buses, subways and trains thought they could get cheaper premium ride services, and they thought the driver was taking advantage because it saved them money. 3. There are no restrictions on the platform. Both parties can cancel the order at any time without liability or compensation. Your plan will be easily disrupted, and your order will be in an uncertain state. You may have spent a long time driving to his place, and he will say sorry, there is no need for a ride, and just cancel the order. You can just stare at it. It is useless to complain. 4. The cost of communication is too high. Even if the communication is successful, you still have to pick up and deliver the 5-kilometer journey, which may take an extra thirty or forty minutes, plus waiting for someone. The time it takes to get in the car is uncontrollable. You can walk 60 kilometers on the highway in 30 minutes. The time cost is too high, and long-distance commuting is tiring in itself. The more you drive, the more you communicate and the more you worry about, the more tired you will be. If you drive for more than 3 hours, the level of fatigue will increase exponentially. In summary: long-distance carpooling increases the level of fatigue, and short-distance carpooling is not worth the money. 5. If you feel that the platform’s pricing is unreasonable, you may also need to agree to the offline transaction, and there is a risk of cancellation. If you require a deposit, the probability of closing the transaction will be lower, and the communication cost will increase. At the same time, the driver is illegal and is defined as a black driver. If he is reported or found out, he will be fined hugely. If there is an accident, compensation will be very troublesome. If he has a dispute with the passenger, he will complain that you are a black driver, and you will be very passive. 6. After reading the comments, I’ll add another one: Passengers are of different qualities, and it’s disgusting to see people doing vandalism. I just received a call from someone who said she had a grudge and put chewing gum in the groove of my window switch. She also lied about not having children and was actually carrying a 60-year-old mother. To sum up: If you are not very short of money, carpooling car owners should not take the order and drive freely. There will be less constraints and less worries for the passengers. Return to the commuting life of taking the bus, subway, high-speed rail and then taking a taxi. "
Edited on 09-18

### Comments

**C0024**

Reply to Annabelle: I have it for 30 yuan for 100 kilometers.

**C0068**

It’s too low, 140 kilometers, just over 30 cents per kilometer.

**C0110**

The biggest disadvantage of carpooling is that the car owner must pick up and drop off passengers. Why can't they come to the car owner's starting point? Picking up and dropping off people is really time-consuming and labor-intensive, and the money is pitiful.

**C0150**

I just take one with me on my way to and from get off work. I just go with it in the morning and basically have a fixed partner at night. The average for the first four to five years is 2,500 per month and 30,000 per year.

**C0189**

Reply to Xiao Hongshu 69126A0F: All are exclusive rides

**C0225**

Carpooling is pretty good, mainly because it’s cheap. I always share the highway tolls equally. In fact, if the car owner is not in a hurry to make gas money, usually the car owner who is really car pooling is quite willing to take it.

**C0260**

This unit price is already very high

**C0295**

At this price, I have stopped taking orders for a long time. It’s so pleasant to go home alone with music on and singing.

**C0330**

Is the reply true? : I feel that the commuters are of high quality and very polite.

**C0365**

Now I have learned to do it well. When I receive an order, I call first to confirm it before picking up the person.

**C0400**

Your unit price is also too high

**C0434**

Same thing, although the platform says 95% of the time, it’s still not smooth when I click on the details. I have to go all the way to pick him up. I’ve only received one order so far and it’s 99% of the time.

**C0468**

The energy consumption of new energy is less than 1 cent per kilometer, so they earn four times the 5 cents per kilometer. No matter what, someone will take the order.

**C0502**

Reply to Xiao Hongshu 69126A0F: He is not bad even including highway tolls.

**C0536**

Plus one, so every time I go on a business trip of about 200 kilometers, I always come back empty.

**C0569**

Me too, I just take one with me on my way to and from get off work, just do an exclusive ride

**C0602**

The mileage and price of this trip are too mismatched, right?

**C0634**

I really laughed

**C0666**

Is this a tram? I remember not to allow trams to run on Didi or public buses like this. If they run away, the warranty will be affected.

**C0698**

I have been running intermittently for a year, and I have run 681km for 894 yuan, which is 894/681=1.3 per kilometer. It is very interesting to take orders. I meet all kinds of people, and sometimes chat with me for a few words, which is like experiencing a different kind of life. . . I am picky about picking up orders, especially those along the way. The starting point is within 3km and the end point is within 5km. The departure time should be about the same. Don’t go back. I won’t pick up children and the elderly. I won’t pick up orders at stations, airports and hospitals. I won’t pick up orders that have a lot of stuff in the trunk. I won’t pick up orders that don’t go out of highway tolls. When calling in advance to communicate, I won’t pick up orders that are vague or long-winded. . . All in all, it's quite an interesting job.

**C0730**

Reply to someone who doesn't like French fries -: It's expensive for a short distance, so this should be an exclusive ride.

**C0761**

Reply to momo: ?

**C0792**

Placed an order but no one took it

**C0823**

Haha, are they going to carpool to the starting point again?

**C0854**

Reply to Lea: Genuine carpool drivers wouldn't accept this kind of booking at all.

**C0885**

Reply to 你没事吧？: Look at this price. It doesn't even reach 0.4 yuan per kilometer.

**C0916**

I can't even get any bookings.

**C0947**

That fare barely covers the distance spent picking them up and dropping them off. It's not on the way at all—just charity.

**C0978**

To me, carpooling means taking people whose route closely matches yours to save some fuel money. There's no point taking people who aren't on your route. Driving too far for pickups can make you think like a full-time driver and expect professional-driver rates. Platforms shouldn't pressure drivers to accept poorly matched routes either. If it's not on the way, how is it carpooling?

## 47. Recording 100 carpooling passengers｜Wangjing met a beautiful sister

Source: https://www.rednote.com/discovery/item/6ae090c1000000002a033ef9
Original record: 50_posts_1000_comments / N27
Text scope: Visible excerpt in source dataset

1/2
Recording 100 carpooling passengers｜Wangjing met a beautiful sister
📝Female driver born in 2000｜100 carpooling passengers plan It was a warm day today. When I took the order, I met a Beijing lady who works in Wangjing SOHO. We made an appointment to leave at 6:30. The route was smooth and the communication was easy, so I accepted the order. Later, I got off work early and called her to discuss leaving early, and she agreed readily. When we arrived at the pick-up point, we could see her waiting on the roadside from a distance. The young lady is about 170 and super pretty! Seeing that I was a female driver, she asked softly if she could take the passenger seat, saying that she thought it would be more polite. Of course, no problem~ I was very talkative along the way and talked about cars the whole time. She is the most car-savvy girl I have ever seen, and she is also the first passenger to recognize Chiji so far! She said that the cost of gas has been high recently and it is not cost-effective to commute by car, so she commutes by carpooling instead. When we got off the bus at the station, she smiled and said to me: Goodbye, I hope we have another chance to meet again in the future. We meet by chance and stay with us all the way. I wish this beautiful sister everything goes well and see you again soon🌿
8 hours ago Beijing

### Comments

**C0025**

Wow, that makes so much sense! I also want to take up carpooling when I have time.

**C0069** (post author)

pick it up

## 48. 🚗I pick up an order on the way to and from get off work, and I’ll get my 5 days’ gas expenses back! beat

Source: https://www.rednote.com/discovery/item/6a14571d000000000803d26e
Original record: 50_posts_1000_comments / N28
Text scope: Visible excerpt in source dataset

1/2
🚗I pick up an order on the way to and from get off work, and I’ll get my 5 days’ gas expenses back! hit
Who says commuting by car is just a waste of money? As long as you go along the way, you can earn back your gas expenses while commuting to and from get off work! 🌙 I have been carpooling on my way to and from get off work for the past few days. Not only is the journey not boring, I have also collected 378 yuan in 5 days. I feel like I have saved my gas money this month! Let me show you my "making money along the way" running account 👇 📝**【5-day carpooling small ledger】** 5.18: Drop by after get off work, 1 order each from Amap + Hello = 130.1💰 5.19: If you don’t receive the drop-in, then have a good rest (mainly a random one 😂) 5.20: 1 order from Hello after get off work = 54.7💰 5.21: I was busy commuting to and from get off work, Hello + Gaode = 106.43💰 5.22: Didi ran 2 orders in a row after get off work, Hello 1 order = 86.97💰 📊Total income in 5 days: 378 yuan! ✨**【The carpooling owner’s thoughts】** 1️⃣ It’s really easy! You have to drive to and from get off work anyway, so instead of leaving the passenger seat empty, you might as well pick up a passenger. Not only can we share gas costs, but we can also chat sometimes on the road, and the commuting time flies~ 2️⃣ Multi-platform hanging is more stable. Carpooling is not as fast as Express, but I am used to opening Amap, Hello, and Didi, and pick whichever one I want on the way. The highly matched orders are really delicious! 3️⃣ A calm mind is the most important thing. It doesn't matter if you don't receive an order on May 19th. It's just for making extra money along the way. If you have it, make it. If you don't have it, just treat it as an exclusive ride in the KTV in the car🎤.
Although this 378 yuan is not a huge amount of money, for the workers, it can cover most of the gas expenses for half a month, which is really a sense of accomplishment!
Edited on 05-25

### Comments

**C0026**

Will premiums increase?

**C0070** (post author)

One day round trip 130

**C0111**

An order is more than 50 yuan. In our case, at least it goes from Hangzhou to Ningbo.

**C0151** (post author)

The situation in Beijing may be different

**C0190**

It seems that cross-platform ordering is not allowed

**C0226**

After being connected to the platform for a while, I found a fixed match, and then I went offline. The price was cheaper than the platform.

**C0261**

It is difficult to receive more than 80%, but if it is lower than this value, it is basically a roundabout and time-consuming process, and the price/performance ratio is not high. You have to be really smooth! I met 95% once, it was very comfortable, but it is rare!

**C0296** (post author)

I have a lot of orders, usually I can get some with over 90%

**C0331** (post author)

That's so high

**C0366** (post author)

My journey is too far, and I have only found a fixed partner at the moment.

**C0401**

Can two platforms accept orders at the same time?

**C0435**

Our 10 kilometers or so are basically more than 2 yuan per kilometer.

**C0469** (post author)

So cheap? Is it charity? ? ! I usually pay 1 yuan per kilometer, which just subsidizes the gas cost.

**C0503**

My scalp feels numb after looking at it

**C0537** (post author)

There is no increase. I receive one order each time I go to and from get off work. Sometimes I still can’t receive it.

**C0570** (post author)

Didn't cross in the first place

**C0603** (post author)

About fifty or sixty kilometers one way

**C0635**

I can't get an order on Hello

**C0667** (post author)

There is no simultaneous connection, only one platform is connected at a time

**C0699**

You can't commute 70 or 80 kilometers

## 49. Real despair of commuter car owners: new carpooling regulations, what are you doing?

Source: https://www.rednote.com/discovery/item/6a16676800000000070113b3
Original record: 50_posts_1000_comments / N29
Text scope: Visible excerpt in source dataset

1/3
Real despair of commuter car owners: new carpooling regulations, what are you doing?
As a real car owner who only wants to pick up gas money on the way to and from get off work, the new carpooling regulations this time are simply... 😭 My situation: I am a pure real car owner, commuting on a fixed route every day, and just want to share the gas money with someone along the way. I have never considered it as a full-time job. The current endless loop: I took the order, but couldn’t agree on highway tolls: I took the expressway to make my commute faster, but the passengers were unwilling to buy highway tolls, so I had no choice but to cancel. It was cancelled, and the order completion rate plummeted: The system doesn’t care about you, and the cancellation is my fault. Now my order completion rate for more than 15km has dropped directly to 37.5%! Communicate first without taking the order? It's no use at all! Many people don't read the information at all and can only communicate on the phone. If they want to call, they can only take orders. If communication fails, the order completion rate will still be ugly. The consequences are here: the order completion rate is lower than 70%, and the automatic order grabbing rights are gone! Passengers do not give highway tolls → cancel the order → drop the order completion rate → fail to receive the order → income will return to zero! This is not carpooling, it is clearly "carpooling"! Do you have the same driver? Hug together in the comment area to keep warm!
Edited on 05-27

### Comments

**C0027** (post author)

My gas car is not a tram, it can’t be driven on the expressway.

**C0071**

It depends on the situation. I don’t have to give it, but you can’t give it.

**C0112**

Reply to Niuma Commuting Diary: The higher the route, the less money

**C0152**

Reply to Meow Meow’s Worker: Are there really so many car owners on Didi?

**C0191** (post author)

Reply to Makaba Kabi Kabaka: Sometimes you can see on the system that the price is 30 yuan for 80+ kilometers, and highway tolls are not covered... Even taking the bus is more than this price, right?

**C0227**

He changed it like this, and the fun of cheating to grab orders went crazy. Originally, the real car owner could automatically grab orders and get some soup, but in this way, he didn’t even have to drink the soup.

**C0262** (post author)

Will swallow kilometers

**C0297**

I thought I had more than 90, but it turned out to be only 70

**C0332**

I am the true carpooling master

**C0367**

Reply with a name: The total number should be quite a lot, but the proportion is not high. Moreover, car owners are really picky in taking orders. I took a total of 17 orders in three years.

**C0402**

Only if you grab the order automatically will you lose points. If you grab the order, the deduction will be cancelled.

**C0436**

Reply to Niu Ma Commuting Diary: I just came across the option that I chose to negotiate to bear part of the highway tolls. I called the car owner and negotiated that each person would bear half of the highway tolls. They directly asked me to find a new driver with a very bad attitude. I wrote so clearly why you want to take my order. I’m really speechless.

**C0470**

Reply to Niuma Commuting Diary: I wanted to laugh when I saw it. I don’t know how the app can quote this price. Even if you pick up an ordinary friend, you won’t pay this price.

**C0504**

Reply to Miaomiao Beating a Worker: I’ve seen it twice

**C0538**

Reply to Miaomiao Workers: 99 is the only option to pick up, hello 99 is the real route

**C0571**

I am actually 100%, as long as I don’t pick up, I won’t cancel hahhh

**C0604**

I commute 70 kilometers back and forth, and I’m not too particular about highway tolls. I default to taking national highways when picking up people or not. Of course, if he wants to go out of highway tolls, he can take the highway.

**C0636** (post author)

Reply to Makabakabi Kabaka: I won’t accept the 50 cents per kilometer payment, and I won’t accept the highway tolls either.

**C0668**

Reply with a name: I have never seen Hello’s 99, so I didn’t answer it

**C0700**

Reply to Molly: They are all directly hacking the driver. I want you to get out of all highway tolls.

**C0731** (post author)

The unit price is so high?

**C0762**

Reply to Niuma Commuting Diary: I paid 30 yuan for 30 kilometers. This price is too low.

**C0793**

It's negotiable if you accept the order. If it doesn't come out, do you cancel or not?

**C0824**

Didn’t the passengers write down whether they would be responsible for the expressway, or could it be negotiated? Make it clear that those who are not responsible will not be accepted, and then only those that can be negotiated or accepted will be accepted.

**C0855**

Didi's automatic order-grabbing feature also seems broken now. I set pickup and destination limits, but it still grabs bookings miles away that aren't on my route at all. The route-match score is just for show.

**C0886**

At 0.5 yuan per kilometer, it's effectively just the passenger paying the tolls while I take them to their destination for free. There are detours at both ends too; on a long-distance booking, that can easily mean another ten kilometers.

**C0917** (post author)

It doesn't affect you if you don't accept bookings.

**C0948**

Reply to 起个名字: Didi.

**C0979** (post author)

Many don't write anything at all.

## 50. carpooling

Source: https://www.rednote.com/discovery/item/6a43d9d70000000011019f94
Original record: 50_posts_1000_comments / N30
Text scope: Visible excerpt in source dataset

carpooling
I recently browsed xhs and saw several posts about carpooling, each with its own reasons. Let me tell you my feelings: 1️⃣I think everyone who goes carpooling should choose exclusive rides. For real carpooling, no one will chip in. Because I have a long commute to and from work (60km one way), I occasionally do carpooling, but I have never done so. When you are thinking about how others will earn your three melons and two dates along the way, you should think again that you have saved more than half of your money by taking an express train, and others have to take a detour to pick you up. 2️⃣The person who carpools for orders is essentially trying to take advantage. When he really carpools for various orders, he will say he is in a hurry. (Some people say that you don’t have to accept the carpooling orders I sent. The Indian caste system is difficult to change. The essence is that the upper level has a sense of superiority than the lower level) 3️⃣If you are a full-time carpooling driver and are still collecting rides, I think it is good for you to find a stable job. Or go for a quick ride. In fact, I think the full-time carpooling industry should not even exist, because it has strayed away from the original intention of carpooling. 4️⃣ Why have we been talking about restricting full-time carpooling on various platforms, but it has never been implemented? I think from the platform point of view, if others do it but I don’t do it, then I will lose part of my income source, which is a loss to the company (capital) and is absolutely not allowed. But I think there will definitely be restrictions in the future. (The management is very chaotic now, there is no management at all) 5️⃣*** In unlimited volume, roll until there is no lower limit. However, I only accept those with a smoothness of more than 90%, and I even think that most of them are more than 95%. Detours within 10km if you take the expressway, and within 5km if you don’t take the expressway.
06-30

### Comments

**C0028** (post author)

Yes, so carpooling has changed.

**C0072**

The "carpooling" currently operated by several major platforms controlled by capital are ride-hailing service models such as platform pricing, point-to-point pick-up and drop-off, "exclusive ride", "special exclusive ride", "comfortable ride" and "one order only". In fact, they are ride-hailing without double certificates (commonly known as "black cars"). In addition, the current commission ratio of the platform is extremely high (for example, the maximum of Hello is more than 35-40%), which causes the ride-hailing to think that they pay according to the platform price, and of course they are the "passengers" of "taking a taxi", and then feel that they should enjoy the "service" of ride-hailing. However, at the same time, the price offered by the platform to car owners is extremely low (the minimum per capita per kilometer for long distance is less than 0.22 yuan), and it is naturally impossible for a real car owner to provide the ride-hailing service that ride-hailing expects. Therefore, real car owners (including myself) basically rarely accept orders now because they don’t want to work cheaply for the platform and be sucked by the platform! It can only be said that most of the "carpooling" on the platform are black cars operated by professionals!

**C0113**

support! ! ! ! ! I take an exclusive ride and pay highway tolls every time, but I always encounter private shared rides. The most annoying thing is that some drivers say that it is not cost-effective for me to just pick you up. I said that in this case, then you can give me the shared ride price, but he disagreed and said that other passengers were taking exclusive rides.

**C0153**

Thumbs up 1. I just don’t understand. I have to share a ride, I have to be in a hurry, and I have to be a real car owner. What are I thinking about? A true car owner would rather have an empty car than pay for it.

**C0192**

The evil root of the current carpooling situation is the profit-seeking capital platform. The so-called "shady drivers" and "full-time black cars" are also trained by the platform to work for them. The platform operates illegal ride-hailing under the banner of carpooling. Because the state defines carpooling as being only undertaken by private cars, the platform does not need to maintain a large number of operating vehicles and drivers. The cost is greatly reduced, but they take a high commission (hello, the highest is more than 35-40%). They can also "legally" evade taxes, because according to the national definition "carpooling" is not operating vehicles, they only charge "information service fees"! With the encouragement of the platform, former illegal car drivers can also run ride-hailing "legally" under the banner of "carpooling" without having to take dual operating vehicle licenses! Therefore, the platform and black ride-hailing have a community of interests, but the real carpooling owner is in an embarrassing situation - the high-priced orders cannot be grabbed, and the price is too low to cover gas and electricity bills, highway tolls, and the meaning of taking orders is weakened or even lost...

**C0228**

95% of them are professional passengers, so if you need highway tolls, you have to ask for them.

**C0263** (post author)

People who take shared rides want to take advantage of this advantage. Anyway, I would rather drive empty.

**C0298**

Just think like this

**C0333** (post author)

indeed

**C0368**

You spoke my mind. Really, many people offer carpooling. Anyone who wants to go to and from get off work can just take someone along the way. I’m not a taxi. I really only want to pick up exclusive rides. Some people who do carpooling are quite anxious. If you really want to go for it, they won’t want to. It’s a big loophole in carpooling.

**C0403** (post author)

That's not true. If it's true carpooling, it's basically just one order, and you won't fight for it.

**C0437**

Private message the carpooling driver

**C0471**

The actual situation is that an exclusive ride is roughly equivalent to a shared ride, and no one wants to take the shared ride [reply hello]

**C0505**

I think there are big problems with the platform. The platform needs to be profitable. Did you notice during the holidays that the major carpooling platforms have launched more rewards the more orders they receive every day? Doesn’t this breed full-time carpooling drivers?

**C0539**

The platform charges 15% for each order, which is too much profit.

**C0572** (post author)

yes yes

## 51. I guess there will be no more carpooling in the future, just do it and cherish it.

Source: https://www.rednote.com/discovery/item/6a09d34a0000000008001708
Original record: 50_posts_1000_comments / N31
Text scope: Visible excerpt in source dataset

I guess there will be no more carpooling in the future, just do it and cherish it.
05-17

### Comments

**C0029**

And make sure I don't have to wait for him.

**C0073**

You can also take advantage of this

**C0114**

Nothing wrong

**C0154**

A 100% smooth journey won't work, unless the starting and ending points are exactly the same, so I have to consider it reluctantly.

**C0193**

I won't accept it 100%. If I don't earn the 15, I can sleep. If I save you dozens of dollars, I won't be able to sleep.

**C0229**

Reply to Han: He has the right not to ask, and bloggers also have the right not to ask. 34 kilometers costs 200 yuan a month. It’s hard to find another one. Adults still have to talk about relationships. If you don’t talk about relationships, you will end up harming your own interests.

**C0264** (post author)

Brothers, I mean 99%-100% of the way. There is no need to ask if you are not on your way, 100% no answer.
Pinned comment

**C0299**

15 yuan for three or four kilometers, I will consider it

**C0334**

I definitely won’t accept this price.

**C0369**

If you go to pick up someone who comes out of the hospital, there is a chance that you will pick up someone who is not breathing. I’ll also give you a reward

**C0404**

If the indoor price is lower than 80, we will not accept those who do not bear highway tolls. If the outdoor price is lower than 100, we will not accept those who do not bear highway tolls. We will only accept exclusive rides. Those with more than 2 luggages will not be accepted. Those with pets will not be accepted. Those with children and the elderly will not be accepted. Those going to the hospital and discharged from the hospital will not be accepted. Those with tattered and disheveled clothes will not be accepted. Those with high requirements or many requests will not be accepted. Those who require the driver to wait for 10 minutes will not be accepted.

**C0438**

Don't set the price in private. It's okay if nothing happens. If something goes wrong, you won't know. Unless you are a trusted friend, you will always use the platform to take orders.

**C0472**

Reply to momo: He gets on the bus at my place and gets off at the place where I want to get off. Yes, but the app shows that 90% of the routes are detours. My one-hour drive will take at least an hour and a half to reach my original destination. I no longer accept orders. I hang there every time to see if there is anyone on my way. I find that it is a waste of so much time and it is better to drive back by myself.

**C0506**

15? I don't even like this kind of thing

**C0540**

The reply is neither rainy nor sunny~: Well, there are other things later that make me make up my mind. I am a person who never rejects others. After this incident, my car was overhauled twice and everything went smoothly.

**C0573**

Reply to momo: It’s 10 yuan a day, 5 yuan when I go, and 5 yuan when I go back. I completely feel that I won’t refuse people, but I feel disappointed again and again. I really don’t lack these 200 yuan, so I don’t have to worry about it every day.

**C0605**

Reply to momo: 35 for 50 kilometers is about the same

**C0637**

It's not 99% or 100% smooth. You said he would pick up a ride at your door and the driver would get off the bus.

**C0669**

Reply to Xiao Hongshu 676F2F8E: This is the most important thing! At that time, I also thought about lending her money, because we were not 100% on the same road. She asked me to pick her up at her house. That kind of request was not a negotiation.

**C0701**

Reply to Han: So I won’t bring it with me anymore.

**C0732**

No, it’s boring because you can’t cover the gas cost for one way trip. It takes more than an hour to drive and costs about ten yuan. It’s cheaper than the subway.

**C0763**

It's 100% smooth. After getting on the bus, I didn't move. My breathing was steady and weak. I didn't make any sound or smell. You can consider it.

**C0794**

If you don't pick it up, the weight of one more person will be the fuel consumption of one more person. 80 kilometers a day will be less than 20

**C0825**

No answer

**C0856**

Reply to Han: That's why it depends on the person. You can take it lightly, but plenty of people can't. There's nothing wrong with them getting emotionally invested either.

**C0887**

Reply to momo侠: If I were the passenger, I'd definitely help think of solutions. But as the driver, I wouldn't need that, because I'd know what to do: just have the car towed to a repair shop. Still, I'd hope the passenger would check in afterward.

**C0918**

Reading everyone's different attitudes makes me grateful to the woman who gives me a ride every day. The platform fare is around 22 yuan; I pay her 20. We've had this arrangement for over a year, and we're both happy.

**C0949**

I wouldn't accept. It's a waste of time, and it can't be a 100% route match.

**C0980**

Reply to Han: Five yuan a trip is just a token amount. I'm not short of money, so I eventually refused to take them along. Driving alone is much freer.

## 52. Horizontal measurement of 4 major platforms, guide to avoiding carpooling pitfalls

Source: https://www.rednote.com/discovery/item/6a9a9ed0000000002502dd5c
Original record: 50_posts_1000_comments / N32
Text scope: Visible excerpt in source dataset

1/2
Horizontal measurement of 4 major platforms, guide to avoiding carpooling pitfalls
A gathering of those who often take carpooling to commute and travel across cities🙋♀️ I have been carpooling for several years and have tested and experienced it on all four major mainstream platforms! I have a thorough understanding of the advantages, disadvantages and adaptability scenarios of each platform 💙 Hello carpooling｜Cost-performance ceiling (the first choice for daily use) It focuses on an all-around cost-effective solution, so those on a budget can just rush in with their eyes closed! The mode is super flexible and adapts to all travel needs ✨ If you want to save money, choose shared seats, which is a great value for money. If you want to be comfortable and not crowded, choose the exclusive ride, which has both price and experience. The overall fare only starts at 50% off for express trains, so you can save a lot on long-term travel! The exclusive benefits for new users are awesome, and you can get up to 15 yuan in coupons🧧 Whether it’s daily commuting, weekend short distances, or cross-city round trips, it’s the best choice! 🧡 The biggest advantage of Didi carpooling is the speed of receiving orders! The vehicle supply is sufficient, so it can be quickly matched when traveling unexpectedly or in a hurry. The actual riding experience is very stable, and most of the vehicles are clean and tidy with no odor. It is super worry-free to choose it for daily temporary taxi calls and morning and evening peak emergencies! 💚 Dida carpooling｜Buddhist travel options The overall matching pace is moderate, no need to wait for a long time There are no strict departure time requirements, and if you are not in an emergency, it is completely sufficient for daily car bookings, and the stability is online. It can be used as a backup option for long-term travel, and the price/performance ratio is quite satisfactory✅ 💛 Amap carpooling｜Comfort experience player focuses on comfortable and stable travel! The price will be slightly higher, but the itinerary is well planned and the driving is smooth and not bumpy. The matching drivers have good service attitude and most of them are chatty and friendly. It is suitable for Baozi who likes a relaxed riding atmosphere and pursues travel comfort! 🎁 A summary of travel benefits for lazy people. We have put together an exclusive money-saving guide for everyone 👇 📍 Hello carpooling express train prices start at 50% off, which is a great deal for long-term travel 📍 Exclusive coupons of up to 15 yuan for new users, no tricks to get them 📍 Save money by sharing seats, exclusive rides are comfortable, and you can choose according to your needs without being surprised.
09-05

### Comments

**C0030**

Hello, the most rubbish, okay? It’s from an advertisement.

**C0074**

Hello, it’s really useful.

**C0115**

ah? I often use hello

## 53. Carpooling when commuting across cities: 3 things you should never do

Source: https://www.rednote.com/discovery/item/69bc9582000000002800ad5c
Original record: 50_posts_1000_comments / N33
Text scope: Visible excerpt in source dataset

LIVE
LIVE
LIVE
1/3
Carpooling when commuting across cities: 3 things you should never do
After running carpooling for a while, I would like to give three pieces of advice to newbies: 1. Resolutely don’t take orders that are not convenient or detoured. 2. Try not to take orders that are too far, too late, or in remote places. 3. Don’t make yourself very tired just to make a few more bucks. We are just subsidizing the gas and electricity bills along the way. We are not relying on this to support our family. Safety and comfort are the most important thing.
03-20
Say something...
"2"
Comment

### Comments

No sampled comments in the supplied dataset.

## 54. Blog 15. Side hustle exploration 1: carpooling

Source: https://www.rednote.com/discovery/item/69fb6817000000001f002fcd
Original record: 50_posts_1000_comments / N34
Text scope: Visible excerpt in source dataset

Blog 15. Side hustle exploration 1: carpooling
I have only used Dida, and I have been doing it for about 2 months now. I would like to share briefly 1. Remuneration is about 1.4 yuan/km based on the number of kilometers. Basically, only trams can do this at this price. The hourly wage is about 80 yuan. This time is the extra time invested in addition to the part of the journey that you originally had to go. For example: the original commute time is 1 hour, and it takes a total of 2 hours to pick up and drop off people. The extra hour will be paid about 80 yuan. There is a limit on the maximum number of orders accepted in a day. It is said to be 4 orders, but I have not tried it. My current commuting time is 1 hour to 1.5 hours, and the one-way mileage is 45 kilometers. I basically make one order every day after get off work (ranging from 40 to 80 yuan, with an average of about 40 per order). I go out to play and make 1 to 2 orders randomly on weekends. After excluding charging fees, my average monthly extra income is about 800 to 1,000 yuan. This is a situation where office workers already run quite diligently. For reference only. Basically, there are stable free pickup times only after get off work. Due to the morning rush hour in the morning, the risk of being late is too high and it is not recommended. 2. Operation difficulty: The difficulty of getting started is about 0. Just open an account on the Dida app and enter the car and personal information. There are no other additional restrictions and it is not within the scope of operating vehicles. Regarding orders, you set your own starting point and destination on the platform, and the system will recommend orders on its own. New and old customers sometimes send invitations to accept orders. Priority is given to orders with a smoothness of more than 80%. For orders with a smoothness of 80% to 90%, an additional 30 to 45 minutes will be added to your original route. Orders with a smoothness of more than 95% are very rare. The destination of such orders is basically very close to your actual destination. Operation process: publish itinerary, check orders, confirm order receipt, confirm departure, confirm arrival location and receive customers, confirm arrival at destination. Some customers will temporarily release their pigeons. It is best to contact the customer 1 hour before departure to confirm that the itinerary and time are correct. Canceling an order is troublesome and requires customer confirmation, otherwise your credit score will be affected, so try not to cancel. 3. Regarding the car, it is recommended that all passengers sit in the back seat. The back seat should be covered with protective pads to prevent it from getting dirty, and personal belongings and valuables should be placed in the front seat. It is best to buy car insurance that covers passengers. Aromatherapy must be placed inside the car to avoid complaints due to the smell. Passengers are generally willing to play some music or sound, as long as they inform them in advance. It’s best to ban smoking and pets in the car. You can decide this yourself. 4. About the passengers: I have taken at least dozens of passengers so far, and they are basically all friendly and normal. I have never encountered any strange ones, such as drunk people. However, try to keep a sense of distance from passengers. Most people don't like small talk and don't take the initiative to strike up a conversation. A very small number of social cows will take the initiative to chat and just chat with them. Anyone who excessively asks for personal information, tries to get too close, or even sells things will be fooled. Don't be direct, as it may cause complaints and affect the acceptance of orders. 5. Summary The overall cost-effectiveness is low, and it is hard work with little money and tiredness. Now I gradually run less, but for Sheniu drivers, they can indeed meet many interesting strangers, which can be regarded as an interesting life experience.
05-06
Say something...
"8"
"7"
Comment

### Comments

No sampled comments in the supplied dataset.

## 55. The driver was sleepy and asked the passenger to drive the car for him and then charged the full fare. The platform responded.

Source: https://www.rednote.com/discovery/item/6ad9c50e000000002c013e04
Original record: 50_posts_1000_comments / N35
Text scope: Visible excerpt in source dataset

1/4
The driver was sleepy and asked the passenger to drive the car for him and then charged the full fare. The platform responded.
Recently, little girl Zheng from Hangzhou asked the media for help. She said that she and her aunt went to Shanghai to watch Yi-Lian Lam's concert in Shanghai two days ago, and after that, she took a carpooling ride back to Hangzhou. Unexpectedly, the driver said he was sleepy halfway and asked them to drive. In the end, during the two-hour journey, Xiao Zheng's aunt drove for an hour and a half, but the driver fell asleep at the destination and paid the fare in full. Xiao Zheng said that at 10 pm on October 17, after watching Yi Lian Lin's concert in Shanghai, she and her aunt ordered carpooling back to Hangzhou and paid more than 160 yuan for the fare in advance. Less than 5 minutes after picking them up, the driver told them that the car was out of battery and needed to be charged, and he did not set off until after 11 o'clock. Xiao Zheng said that it was too late at the time and they didn't care. Not long after the trip started, the driver said he was sleepy, asked them if they had a driver's license, and asked them to drive. Xiao Zheng said that there was no way to reason on the highway at the time. "Although my aunt had been driving a gas truck, she had just had a gastrointestinal surgery a few days ago, so she had no choice but to take over." The driver originally promised to go to the service area to change people, but ended up sleeping for more than an hour. After getting off the highway, Xiao Zheng's aunt drove to Linping's home. Xiao Zheng's aunt drove about two-thirds of the two-hour journey, and Xiao Zheng still paid the entire fare. When they got off the expressway, they got 68 yuan of highway tolls, and the driver also asked them to pay with their mobile phones. After Xiao Zheng's aunt argued with him, the driver eventually shouldered the cost. After Xiao Zheng returned home, he became more and more angry and complained. At first, the platform only compensated 20 yuan in vouchers. The reporter contacted carpooling customer service, and the other party said that the behavior was a violation of the car owner's rules, and would be punished after confirmation, and a senior service expert would be contacted within 24 hours. Platform rules show that additional charges such as carpooling highway tolls must be negotiated and confirmed before placing an order. It is illegal to temporarily propose charges during the trip, but the driver did not mention it in advance. So far, the platform has refunded the fare in full. (Xiaoqiang Hotline Zhejiang Educational Science)
5 days ago Hunan

### Comments

**C0031**

So, how to calculate it?

## 56. Educated another passenger

Source: https://www.rednote.com/discovery/item/6a7c65e1000000002500f487
Original record: 50_posts_1000_comments / N36
Text scope: Visible excerpt in source dataset

1/6
Educated another passenger
Didi’s new rules mean car owners can’t take orders
08-12

### Comments

**C0032**

The platform educates the car owner, the car owner tries to educate the passengers, the passengers complain to the platform, the platform educates the car owner, and the loop is closed.

**C0075**

The other person's attitude is very good, and you also need education.

**C0116**

Yes

**C0155**

You are the real wind

**C0194**

I remember that in the past, carpooling was just to save drivers money on gas or highway tolls, and it was not for the purpose of making money. In the past, carpooling was always done by fellow villagers, and I never asked for highway tolls or anything that was cheaper. Since the platform came out, traveling has become more expensive.

**C0230**

Yes, before I started driving, the car owner really asked me to go somewhere nearby, such as a highway entrance. Now that I'm driving, I'm going to take a detour to the door of someone's house, and maybe load goods.

**C0265**

They say they don’t make money from this, but they always add money.

**C0300** (post author)

I remember that in the past, carpooling required passengers to get on the car at the car owner and get off at the car owner's stop. There was no need for pick-up and drop-off, but now carpooling requires pick-up and drop-off.

**C0335**

Anyway, I only take one of the exclusive rides or shared rides just to pay for electricity and parking fees.

**C0370**

Passengers' attitude is surprisingly good

**C0405**

Every time I call for an exclusive ride, there are passengers on the car every time.

**C0439**

I am a passenger. When I carpool, I always ask for an equal share. I have always taken the initiative to share the ride equally. If anyone is willing to drop by, I will accept it. But using the excuse of picking me up and dropping me off to require me to travel all the way, I definitely can’t accept it, so I might as well choose another way to travel.

**C0473**

If the hourly wage is high, I won’t take orders.

**C0507**

What a joy to reply: I am afraid that I will meet someone like this, so every time the driver takes an order, I discuss highway tolls with him immediately, because I am afraid that when the end happens, he will tell me that I have to pay for it all.

**C0541**

I understand carpooling: the car owner has to go to this place regardless of whether he takes me as a passenger, he just takes this passenger along with him.

**C0574**

Ordered, the split is reasonable

**C0606**

I have never confiscated highway tolls. Who is really carpooling to make money? Isn’t it just to cover the cost?

**C0638**

That's how I understand it too

**C0670**

What I understand is true carpooling. If I take an exclusive ride, it would be more reasonable to pay half the highway tolls.

**C0702**

Is it really like what he said? The route shown on the platform actually takes more than half an hour to detour. This is too exaggerated.

**C0733**

Anyone who lets passengers out of highway tolls is classified as professional carpooling

**C0764**

Nowadays, they are all black cars pretending to be carpooling.

**C0795**

That's a really smooth road. It doesn't matter if it's within five kilometers of getting on and off. Generally speaking, it doesn't matter at all. In many cases, it's normal that it takes 10 kilometers to get on and off. It's not worth the detour.

**C0826**

In the earliest cross-city carpooling, the departure and arrival locations were unified and decided by the driver. This was the real carpooling. Nowadays, passengers need to be picked up from one point to another, which naturally leads to the phenomenon of professional carpooling.我如果是car owner我也懒得伺候。

**C0857**

Hahahaha, don't embarrass him to death.

**C0888**

I think carpooling isn't about making money. It's about reducing the cost of a long-distance trip a little.

**C0919**

It always feels as if passengers pay but are still treated like freeloaders. It's scary, so I hardly ever use carpooling. I'd rather take the high-speed train and then a taxi.

**C0950**

Yes. I've done a few trips between Shenzhen and Guangzhou these past few weeks. Driving alone takes under two hours; taking carpool passengers takes almost three.

**C0981**

I booked an exclusive ride and offered to pay all tolls, but was still asked for another 40 yuan. My total fare was under 70.

## 57. Why can't I pick up other people if I picked up the exclusive ride?

Source: https://www.rednote.com/discovery/item/6a20ef30000000003601ba1a
Original record: 50_posts_1000_comments / N37
Text scope: Visible excerpt in source dataset

1/3
Why can't I pick up other people if I picked up the exclusive ride?
225 kilometers, shared ride 80, exclusive ride 238. I do not bear highway tolls = I accept taking the national highway; if the driver takes the highway, I am willing to bear half of the highway tolls. Considering that there are two cats, we specially took the exclusive ride; both cats were placed in boxes. I asked the driver in advance if he would pick up other people, but the driver pretended to be dead and didn't reply. The appointment was after 2 o'clock, and the driver asked to get on the bus at 1 o'clock, and I agreed. When I got on the bus, I found that there was already one person in the back seat. I endured it and treated it as a relative. I continued to drive around the city and picked up another person, but I endured it again. Then I ran to Jintang to pick up the third person. I couldn't bear it anymore. I asked the driver if I didn't take an exclusive ride. The driver said no matter what, he had to pick up other people. I asked him to take me back, but he refused. Then I asked him to drop me off. I was in Jintang and called the police. I complained to the platform and the platform refunded the money to me; however, it was of no use. Instead, it tormented my cat for more than two hours. I took the exclusive ride because I didn’t want it to be too crowded. If you want to fight for people, just one or two people. What does it mean to fight for three people? So what’s the difference between me and the single ride? Is it a bit too much? Am I being taken advantage of? Do I pay for the exclusive ride and take the shared ride? The old woman in the car also kept saying things like "nothing is easy" and "meeting is fate". Am I easy? I spent money on an exclusive ride but it turned out to be a shared ride. It doesn’t hurt my back when I stand and talk.
The price of a combination car here is only 120-150 per person. Don’t say that the price is low, the high-speed rail is only 90. What I paid is much higher than the market price. The follow-up is: the platform is completely biased towards the driver. I was asked to make up for the difference with a taxi coupon, but I refused. I personally will not use Didi carpooling again, and I will also protect others around me; there is no penalty at all for the driver. Everyone who wants to carpool with Didi should be prepared for the possibility of being tricked or pretending to be dead by the platform. I can't even imagine how scary girls would be at night...
There’s no need for the platform’s customer service to call me. I won’t use your platform anymore and I won’t be able to use the coupons. Either refund my cash or block the driver’s account directly.
06-04

### Comments

**C0033**

A team of full-time carpoolingcar owners has been established in the comment area [cover your mouth and laugh R]

**C0076**

Reply to the teacher, please love me again: Because you reported to the wrong place, you need to report it to the Transportation Management Bureau. Just report the license plate number to the other party directly, and then clearly explain the order quantity to him, and the penalty will be guaranteed.

**C0117**

black car owner

**C0156**

Reply to Yibao’s post: This can be seen by looking at the order volume. It’s a gray area. It’s just that no one reports it and they don’t care. If someone reports it, they will be punished.

**C0195**

You should not call the police in this case, you should report it to the Traffic Management and Transportation Bureau. If they are operating without an operating license, they will be fined several thousand if they are caught. First call 12345 and ask them to transfer you to the Transportation Bureau, and then you can file a complaint.

**C0231**

Reply to Yibao Post: No account ban. Last time I was threatened by a driver and complained to the headquarters. The punishment for the driver was just to stop taking orders for a week. Speechless.

**C0266**

I took the Didi carpoolingexclusive ride to catch the high-speed train last week, but the driver gave me a ride on the Didi platform, which made me so angry that I didn’t catch the high-speed train.

**C0301**

I carpooled my dad back to my hometown from the high-speed rail station. Because it was night and my dad was alone, I called the driver to communicate. The driver was very talkative at the time. I was thinking of giving the driver some extra rewards when it was over. But when my dad got home, he said that the driver didn’t drive a car, but an electric donkey [uh R]. In the end, I could only say that’s it. Fortunately, it was only about 20 minutes away from the city to my hometown.

**C0336**

Reply to mato: If he accepts so many, it is an illegal operation. A tailwind is a smooth road.

**C0371**

Reply to mato: There is no penalty for personal success. If you run professionally every day, you will definitely be punished if you are caught.

**C0406**

I have also encountered this kind of thing. My mother took an exclusive ride. Then there were a lot of people in the car. I said I took an exclusive ride. The driver said, do you want to sit or not? I was so angry.

**C0440**

I've been to exclusive rides many times and it's a shared ride. I'm really speechless. They charge a lot of money. It's better to cancel.

**C0474**

Reply to Yubei Shanchuanxing: I also just encountered that my Didi exclusive ride, another man's Didi shared ride, and another man's Hello carpooling on the same platform has an exclusive ride, and it is also a shared ride. It is amazing.

**C0508**

Reply: The user has logged out: Okay, okay. Just do it next time if this happens again.

**C0542**

Reply to Yibao's post: There is a single quantity limit. If you run personally within 3 times a day, it will definitely be fine. If you run full-time, it will definitely exceed this number. Report one and get it right.

**C0575**

Reply to Lilacsintheair: I met such a driver once when I was returning from carpooling at Jiaodong Airport. However, the driver only remembered halfway through the car and forgot to tell us to go offline. I was afraid that he would throw us on the road.

**C0607**

? ? ? There are also masters

**C0639**

Carpooling is not regulated, what is regulated is ordinary ride-hailing, so there are many original web pages where drivers now run full-time carpooling. The reason is that it is not regulated, and there is no need to pay a large amount of money every year to buy an operating license.

**C0671**

I saw a method before. You don’t pay before carpooling. It can filter out the full-time ones. The full-time ones only grab those who have paid. I am really carpooling. One way to and from get off work is 80km. I only accept one ride, whether it is a shared ride or an exclusive ride. But I can’t pick up the passengers who are on the same route at all. The passengers who pay directly are all snatched away by professional drivers. The ones I can pick up either have very little money or the passengers haven’t paid.

**C0703**

Reply to Yubei Mountain and Sichuan Tour: Isn’t this driver very profitable? ! I made money from several exclusive rides!

**C0734**

And if it is carpooling, it is usually covered by ordinary insurance. After you apply, it will at least be checked. If the car is involved in an accident, especially if there are people with it, the insurance will adjust the information and look at the number of orders received, and there is a high probability that the insurance will deny compensation. I heard a consultation in the live broadcast room before. There was an accident, and the insurance company refused to pay compensation on the grounds of operating the vehicle. You can strive for real carpooling services a few times a year, like this kind of registration for multiple platforms and taking multiple people with you at one time, haha

**C0765**

The reply was Mao: He must be using a different account.

**C0796**

Mainly my shared ride, Mao Mao’s exclusive ride, and my aunt’s exclusive ride are all on Didi. It’s actually the same platform. I don’t want to say anything.

**C0827**

Reply to mato: There is really no control over carpooling. Those who specialize in it are black cars, and black cars must be managed.

**C0858**

File a complaint. While you're in the car, get the driver to admit that he's combined bookings. The platform records the trip and will listen to the recording when it investigates.

**C0889**

I thought so too, until the driver arrived in a luxury minivan.

**C0920**

Reply to mato: But carpool drivers can only do two trips a day.

**C0951**

Reply to mato: [No reply text in source]

**C0982**

Reply to 用户已注销: Whether 12328 handles carpooling complaints depends on the region.

## 58. It is not recommended for any car owner who is not short of money to take up carpooling.

Source: https://www.rednote.com/discovery/item/6ac87d380000000014038153
Original record: 50_posts_1000_comments / N38
Text scope: Visible excerpt in source dataset

It is not recommended for any car owner who is not short of money to take up carpooling.
Because some people today just look like people. [Uh R] I believe every car owner has had the thought of “should I take a carpooling order?”, and so did I, and I even tried it. When I received the third order, I was so scared that I immediately logged out of the car owner and uninstalled the software. The first two orders I took were from two female students. One order when they went home during the Mid-Autumn Festival, and one order when they came back to work. Both of them were very easy to communicate with and both rides were exclusive, but I still felt unhappy taking the order. Because of the holiday, the traffic jam on the way to pick up and drop off and at the school entrance was particularly serious, but this did not completely eliminate the idea of ​​taking orders. The last one made me give up carpooling completely. I went home during the National Day holiday and took an order. This is a joint order. The destination is more than ten kilometers away from my home, but I am more familiar with the road there, so after thinking about it, I took it. I didn't plan to join the order. After arriving at the lady's designated location, the phone could not be reached. After waiting for about 5 minutes, she came with a suitcase (the passenger did not note that she had luggage). After getting on the bus, I sat in the back seat and opened a pack of biscuits. I discussed with her whether I could not eat in the car (I don’t really like people eating in my car). The lady rolled her eyes at me (my subjective assumption) and then said nothing. At this point I thought we were on the same page. When I was driving about 1-2 kilometers, I heard the sound of packages being pulled and chewed from behind, so I pulled over and said, "Sorry, I don't like people eating in my car." I didn't know where I offended this lady. She had a very bad attitude towards me, saying that she was very careful not to drop the food on my car, and that I was surprised that there were food available in the car. She kept saying this. I explained to her that I don’t know what other people are like, but I don’t like people eating in my car. After an argument, the lady still had a bad attitude and said she didn't want to eat and asked me to leave quickly. I thought I was civilized and polite throughout the entire exchange, but I was also very angry inside and said, "Sorry, I'm very angry now, please get out of the car." On the way home, this lady called me more than twenty times. I only answered the first one because she said on the phone, "If you don't take me home, you won't make it easy for me, and I won't make it easy for you." Halfway through, I was so scared that I uninstalled the app and blocked my phone number, for fear that she would locate my home and take revenge on me. When I came back the next day, I logged out of the car owner and uninstalled it again. It was very scary.
I will never do carpooling on any software again. (I am even writing this post in fear that she will see it and retaliate against me.)
Edited on 10-17 Hebei

### Comments

**C0034**

I picked up someone before and ate all the snacks given to me by my friend in the back row, and the food was all over the floor. I gave her a pack to express my gratitude, and she finished it all for me. When I got home, I made an appointment for a fine cleaning. I originally lost money when I went out to drive my gas truck that day, and then I lost even more.

**C0077**

, I also took a taxi, but the distance was relatively far, and I brought a cat with a cage. I offered to pay an extra 50, but no one else asked for it. Then I bought coffee cake. Others are also quite polite.

**C0118**

Reply to Xiao Hongshu 65E51D13: Open the door and windows in the office, and everyone is far apart. There is only so much room in the car, and the smell of sitting in the passenger seat cannot be penetrated at all. Windows cannot be opened on the outer ring expressway, and the speed is hundreds of yards.

**C0157**

It's so far behind that I can't even be bothered to care about it.

**C0196**

It won’t break if you use it manually [cover your mouth and laugh R] [cover your mouth and laugh R]! My car is often manually operated

**C0232**

Let’s just say, who can resist the 30 yuan reward for the first order? I invited a student and wore headphones the whole time, which was super harmonious.

**C0267**

I agree with you. Although I understand the main package, there are too many rules and it is really not suitable for Party B.

**C0302**

It’s mutually beneficial along the way. It’s better to work hard than make money from this.

**C0337**

I can't accept any stranger riding in my car

**C0372**

I still hope that everyone will open up carpooling if they have time and money. I always get professional carpooling drivers, which is a rip-off. Even exclusive rides are shared, and there is no way to complain.

**C0407**

I was bored at work this morning and picked up a junior high school student. His family should have called a taxi for him. Sure enough, we were having breakfast in the car after driving for a while. But seeing how carefully he was wrapped in a plastic bag the whole time, I felt that students nowadays are under a lot of pressure, so I didn’t feel comfortable going there.

**C0441**

I don't really like it either. During our relationship, he was carpooling, and I really couldn't talk properly. It was so embarrassing. When we stopped at traffic lights, I was embarrassed to kiss him, and I was embarrassed to feed him milk tea and snacks. Forcing himself to sleep for an hour, in fact, he would be sleepy and bored on the road, and there was no way he wanted to earn the thirty or fifty

**C0475**

In the beginning, that is, seven or eight years ago, it might have been okay. Nowadays, good-looking women have long understood their own value and are basically not too short of money. There is no need for carpooling.

**C0509**

Is it too fast or too slow? This speed is considered normal in urban areas.

**C0543**

The last time I picked up someone, he rubbed his nose into the back seat of me. I couldn't hold myself any longer.

**C0576** (post author)

I forgot to mention that after taking the second order, I wanted to wipe the seat, but I found a lighter on the seat and took it off with lingering fear. My car would be parked on the side of the road in the sun.

**C0608**

Then if you are like me, you drag a man in his 50s or 60s, step on my seat with his bare feet, and chew betel nut, Hainan’s strong-smelling raw betel nut, for an hour, and sniffle all the way. You must not be crazy, I am also half crazy anyway.

**C0640**

I was so angry that I blocked people as soon as I got off the car.

**C0672**

When picking up carpooling services, I always call the driver unless you say you are driving a luxury car for the ride.

**C0704**

I'm a girl. The passengers I picked up were all pretty normal and nice. Except for the fact that the electric tailgate was manually closed for me, I felt distressed.

**C0735**

After registering for carpooling, the insurance premium was raised the next year and I stopped taking it.

**C0766**

My husband and I only took over carpooling once, and it was because I said it would save some money on gas. That time the woman in the back crossed her legs and scratched the seat leather, and we never took it again. Another reason is that there are many outsiders in the car, so it is not convenient for me to say something that is not convenient for outsiders to hear.

**C0797**

Indeed, you have to check the app to contact the passengers and pick them up at the designated location, which is troublesome.

**C0828**

I don’t do carpooling because I don’t want to smell other people’s breath. My colleagues at work occasionally have to smell other people’s breath when they ride in my car. It looks like it’s an expressway and I can’t open the windows.

**C0859**

My point wasn't to criticize drivers or passengers. Contacting each other beforehand helps car owners screen passengers and avoid trouble, and helps passengers find a suitable car. Smoking is prohibited in public places too, yet it still happens everywhere. You can't assume everyone has the same standards of considerate behavior.

**C0890**

I did a few trips and felt I was losing badly. No money in it, and passengers were hard to please. I uninstalled the app.

**C0921**

My one-way commute is about 35 kilometers. I took passengers for a while after changing cars and made over a thousand yuan altogether. I didn't meet anyone especially inconsiderate, but it took so much time and was mentally exhausting. I stopped and felt completely relieved.

**C0952**

Can only Ling Ling ride? [Wording unclear in source.]

**C0983**

Reply to ooo: Ask by phone. With all my unusual requirements, of course I discuss everything before accepting. Otherwise we'd end up arguing if I only brought them up after accepting.

## 59. Disgusted by professional carpooling passengers 🤢

Source: https://www.rednote.com/discovery/item/6a6204ed000000002201b6f4
Original record: 50_posts_1000_comments / N39
Text scope: Visible excerpt in source dataset

1/7
Disgusted by professional carpooling passengers 🤢
The reason is that I have to send my younger brother back to school today (Shanghai to Suzhou), so I went to Hello last night to see if I could pick up a carpooling order and share the highway tolls and gas expenses. When I posted the itinerary, I had already chosen the number of seats available to be 3, which means that there is a relative or friend traveling with me in the car. Before leaving today, I planned to call this person to confirm the departure time and the fact that my brother was traveling with me in the car. That’s when things started to go wrong. I called her 4 times in a row before setting off and all hung up within seconds. I thought maybe she would have special circumstances and it was inconvenient to answer the phone, so I set off first. Halfway through, I glanced at my phone and saw her sending me a question mark❓ and I felt very uncomfortable. My brother also said that this person was so unqualified, but I thought I was almost at her starting point. After picking up someone, the first thing she said when she got in the car was, "Didn't I take an exclusive ride? Why is there someone else?" I explained to her that this was my younger brother and I was sending him to school. Later I asked her why she didn't answer the phone, and she replied that she didn't like to answer other people's calls. . . (Why are you taking a taxi if you don’t answer the phone? May I ask😅) I was still chatting with my brother on the way, talking and laughing the whole time. A normal person can tell that we are very close to each other. It is impossible for us to be strangers we don’t know, so there is no situation where I am taking orders on other platforms. After getting off the highway, I told her highway tolls29 and asked her to pay on the platform. After she got off the bus, I found that highway tolls had not been paid yet, so I sent her a message and found out that she had been blocked! ! ! At that time, I realized that I might have met a professional passenger, but 20 minutes later she paid for the highway tolls again. I thought that maybe she simply forgot. After returning home in the afternoon, I suddenly received a text message saying that I had been complained about paying extra people. At this time, I finally realized why she didn't answer other people's calls. Most likely, she did such immoral things too many times and was scolded by others on the phone, so she didn't dare to answer calls from strangers. Fortunately, this was the first time I was complained, so the platform only deducted a moderate 50 growth points, otherwise I would have to give her the highway tolls to refund the car.
I used to think that I would never encounter a professional passenger. After all, I don’t do much carpooling. I didn’t expect that I would encounter a professional passenger just after I took the 6th order. It’s not about luck.
The good mood of the day was ruined like this
Edited on 07-31

### Comments

**C0035** (post author)

It probably won’t work. It’s okay if you meet a passenger who is easy to negotiate with. But if you meet a passenger who promises you on the surface but then complains when you get off the bus that you didn’t deliver him to his destination, the platform will directly let you refund the fare.

**C0078**

I also experienced exactly the same thing in AutoNavi. AutoNavi directly deducted my fare! ! Never use Gaode carpooling!

**C0119**

Not to mention exclusive rides, just shared rides. If I ask how many people there are, I will cancel them. Who is spoiling them?

**C0158**

I don’t like paying the fare in advance and always being grabbed by stinky cars who want to squeeze more than a dozen people into the car.

**C0197**

I remember that when I took carpooling seven or eight years ago, there was never a saying that passengers were responsible for highway tolls. The platform charged as much as they wanted, and the driver didn’t say anything. Now in this trend, I feel that people on both sides are very resentful. Maybe it’s because the general environment is not good, and everyone gets tense if they have any minor problems.

**C0233**

You must occupy one for exclusive rides and all highway tolls

**C0268**

I'll be direct, as long as you provide highway tolls! Whether it’s a shared ride or an exclusive ride.

**C0303**

When I received orders before, I would always make a note about highway tolls. Since last month, I have been unable to make notes about highway tolls. It’s a very strange phenomenon. Who has spoiled this? With such a low unit price, I would rather run by myself without Ahighway tolls. I can still listen to novels and drive at the same time.

**C0338**

Hello, I'm sorry to bring you a bad feeling. In order to get in touch with you and verify your feedback as soon as possible, please give us your order information, and relevant customer service will be arranged to serve you as soon as possible. Thank you!

**C0373**

Amap directly banned me for a day for private transactions. I didn’t even recruit anyone to Amap that day, it was Didi. Gothe asked Highway Tolls 30 if he could go there, and then he was blocked.

**C0408**

Complain to the platform and there will be compensation.

**C0442**

I also saw this order

**C0476**

Whenever you encounter communication compensation, you must cancel the stop loss in time

**C0510**

Send a text message on the platform first, and then contact the other party through the platform. If there is a dispute, the customer service specialists will listen to the voice, and even if it is in dialect, they will translate it to understand the situation. Therefore, try to make it clear before departure and leave a record, because in most cases the platform is biased towards passengers, and it becomes the driver who needs to provide evidence.

**C0544**

I was disgusted last time. I took an order for 400 kilometers and traveled 40 kilometers to pick someone up. Then I called downstairs and told them to come downstairs immediately. They canceled the order directly and made me travel 60 to 70 kilometers back and forth in vain and wasted more than an hour.

**C0577**

We only occasionally post about carpooling when we are driving long distances on the highway. When we met two families with dogs, they were unwilling to install a cage in the trunk. Our car has a trunk and a rear seat connected, so there is no lack of air. I also have pets. When we didn’t buy a car, we would pack a box or even add dozens of dollars to avoid causing trouble to others. Some people really think that carpooling is like transferring the ownership of the car to her. Also, don’t pull this kind of people when the car is empty. I don’t want to get used to it.

**C0609**

Please pay attention to the wording. I am a hitchhiker, not a guest.

**C0641**

I always make it clear to my guests in advance. If you feel bad about your attitude when calling, you must think carefully about it.

**C0673**

What do I say when I often meet professional drivers in Guangdong? Or pick someone up across counties?

**C0705**

I won’t answer if the contact is difficult, I won’t answer if the time is uncertain, I won’t answer if I haven’t paid, and I won’t answer if it’s less than 95 and I just want to go smoothly. I don’t have to make money if I just want to go smoothly, but it can’t affect my mood.

**C0736**

How to tell if a carpooling car owner is a real carpoolingcar owner? It’s my first time taking a carpoolingexclusive ride.

**C0767** (post author)

I will know it later. I will learn from it and gain wisdom.

**C0798**

If I can't get through two or three phone calls in the future, I'll just cancel the order.

**C0829** (post author)

You know what? Transporting dogs pays better than transporting people.

**C0860**

I occasionally make long-distance trips and only want to take someone along my own route. Is that possible? I don't want to go out of my way for pickups or drop-offs. Asking as a private car owner who has never activated carpooling.

**C0891**

It doesn't work. I agreed on tolls with a passenger both in the platform chat and by phone, but they refused to pay. Nothing could be done, and the platform offered no compensation. After that, I always had passengers pay the tolls as soon as we left the highway.

**C0922**

It feels like no matter what you put in the booking notes, full-time carpool drivers turn exclusive bookings into shared ones and still charge tolls. Then genuine car owners get endlessly hassled.

**C0953**

Compare the prices then and now. I bought my car in 2020 and often went out for fun, taking people along the way. Using half a tank could earn me enough for a full tank. Now it's 0.3–0.4 yuan per kilometer: using a full tank only earns half a tank's worth, and you pay the tolls yourself if passengers won't share them.

**C0984**

That's a fake booking to stop other people grabbing it.

## 60. Carpooling passengers maliciously cancel orders

Source: https://www.rednote.com/discovery/item/6ae00e78000000001503abde
Original record: 50_posts_1000_comments / N40
Text scope: Visible excerpt in source dataset

1/3
Carpooling passengers maliciously cancel orders
Didi carpooling took orders and took a detour of more than 30 kilometers to pick up passengers. At 10 o'clock in the evening, the mountain road was full of potholes. After arriving, the passengers maliciously canceled the reservation and had a bad attitude. After drinking, the platform complained and it was not processed. The processing was completed directly. There was no penalty for the passengers and no guarantee for the driver! ! !
17 hours ago Guangxi

### Comments

**C0036** (post author)

How do I ask for compensation? I have only been doing carpooling for a few days and have no experience.

**C0079**

It seems that Xiaohongshu still has too few brushes.

**C0120**

Do not accept shared rides

**C0159**

Reply to Qianruo Qingfeng: Your second picture shows the conversation with customer service. Ask customer service directly for compensation for empty driving.

**C0198** (post author)

Damn, 90% of the time, I thought it was in our town. Who knew it was in the mountains?

**C0234** (post author)

It can only be said that the rest of the life is left behind.

**C0269** (post author)

Because it’s our town, I didn’t know it was so remote, but I still suffered from the lack of knowledge.

**C0304** (post author)

90% of the time

**C0339**

So don’t pick it up if you’re not on your way.

**C0374**

It's a detour of more than 30 kilometers, and it's still a mountain road. It's so remote, how dare you accept the order?

**C0409**

There are so many detours,

**C0443**

Fortunately, I didn't do it. After drinking, I couldn't control myself and got into a lot of trouble.

**C0477** (post author)

Very scary

**C0511**

Reply to Qianruo Qingfeng: Didi usually only compensates you 5 yuan.

**C0545**

Hello, we very much hope to handle your feedback, so we need you to provide your registration number in a private message so that we can verify and process it as soon as possible. You can reply to us at any time if it is convenient for you. Thank you for your understanding and support.

**C0578** (post author)

Remembered

**C0610**

Reply to Qianruo Qingfeng: If the time is not long, you can still try it now to see if you can get it.

**C0642** (post author)

Didi only limits the permissions of drivers and only protects passengers. Should this be changed? Should drivers also have the permission to evaluate passengers? After the driver orders to pick up the passenger, should the passenger not be able to cancel the order?

**C0674** (post author)

Yes, I won’t answer anymore

**C0706** (post author)

@ Didi

**C0737** (post author)

Hello, it seems a bit more expensive.

**C0768**

You will also take the 30-kilometer detour

**C0799**

That's what carpooling is, there's nothing you can do about it

**C0830**

Why did you only arrive at ten for a six o'clock booking?

**C0861**

You can ask customer service for compensation for the empty trip. Also, it's better not to detour for pickups, so you won't lose anything even if the booking is canceled.

**C0892**

HelloBike is a bit better. The other day a passenger canceled after I'd driven a kilometer. HelloBike compensated me 20 yuan, even though the booking was only thirty-something yuan.

**C0923**

Call first and confirm before accepting next time. Also, never take anyone who's had too much to drink. If they vomit in your car, the cleaning bill is one thing, but even deep cleaning won't get rid of the smell. Isn't that disgusting? It's not worth that little bit of money.

**C0954**

Even when I don't accept their bookings, habitual freeloaders curse at me. Step one: only consider exclusive rides where the passenger pays all tolls; don't register with HelloBike. Step two: ignore route matches below 95%. Step three: the pickup must be within three kilometers of my original route. Step four: no pets or large luggage. Step five: no elderly, frail, sick, disabled or pregnant passengers. Step six: no hospitals, airports, train stations, nursing homes, funeral homes, difficult roads, or pickups inside residential compounds or villages. Step seven: call first; decline if the conversation makes me uncomfortable. Step eight: call about fifteen minutes before arrival; decline if the passenger isn't there and I'd have to wait. Step nine: decline if the actual passenger count differs from the booking. Another step nine: decline if the person booking isn't the passenger. Step ten: decline anyone dirty, untidy or with an odor I find unpleasant. Step eleven: negotiation is fine, but decline anyone who treats carpooling like ride-hailing and makes all sorts of demands.

**C0985**

Don't go begging among beggars.

## 61. The passenger said that no family members were allowed on the bus, only her.

Source: https://www.rednote.com/discovery/item/695de125000000002202036c
Original record: 50_posts_1000_comments / N41
Text scope: Visible excerpt in source dataset

The passenger said that no family members were allowed on the bus, only her.
carpooling Why does a single passenger on an exclusive ride think that she is the only one in the car besides the driver?
01-07

### Comments

**C0037**

If you are driving carpooling, please mark clearly if there is someone in the car.

**C0080** (post author)

Then you can just cancel the order. This is a full-time carpooling job.

**C0121** (post author)

pretty

**C0160** (post author)

Reply to Yuanyang milk tea with sugar and milk: Haha, it’s not impossible

**C0199**

Reply to Buddhist Xiaoqi Psychology: I sat like this twice and I didn’t dare to say anything

**C0235** (post author)

Makes sense

**C0270** (post author)

Reply: The user has logged out: I have been there before, and I will think about it later.

**C0305** (post author)

Right?

**C0340**

Reply to Buddhist Xiaoqi Psychology: How do you know? You can’t be too arbitrary if you don’t show your household registration book.

**C0375**

Because it’s so rare to have real family members

**C0410**

Reply to Buddhist Xiaoqi Psychology: Okay, thank you

**C0444** (post author)

Reply to Miya: Maybe, after all, not everyone knows what carpooling is

**C0478** (post author)

Reply to Miya: In this case, you'd better call in advance and ask the other party whether he or she accepts the offer. If the other party doesn't accept it, they will tell you on the phone. Otherwise, it will be in vain and it is not worth it.

**C0512**

Read these words

**C0546**

Reply to Buddhist Xiaoqi Psychology: Then get in the car and kiss first

**C0579**

Reply to Buddhist Xiao Qixue Psychology: The problem is that family members may have different destinations. What if the driver first takes my wife to work and then takes me? What’s more, there is also the driver’s operation of picking up people across platforms, so as a passenger, I definitely don’t want to have people in the car. Why should I make a car that I need to distinguish by myself? Isn’t it a good idea to take another one?

**C0611** (post author)

My partner can also be fake

**C0643**

Reply to Buddhist Xiaoqixue Psychology: So if the driver brings a relative or friend and is in the car before the passengers get on the bus and then gives priority to the passengers, will he be reported? I don’t understand and I want to ask sincerely.

**C0675** (post author)

Reply to Sunvia: Do you show me the household registration book? Through chatting, I can’t tell whether the two people are really familiar with each other, or are they just passengers meeting for the first time? Have you seen any carpooling driver mingling with a synthetic person he doesn’t know?

**C0707**

Reply to Buddhist Xiaoqixue Psychology: Then I have to consider whether to pick up the call. My partner and I often travel 100 kilometers to nearby places to earn electricity bills. If we can't accept the two of us together, then I won't pick up the call.

**C0738** (post author)

Agree

**C0769** (post author)

You should know if they are real family members as soon as you get in the car. If you are not a real family member, just complain directly. Don’t be spoiled.

**C0800**

Reply to Buddhist Xiaoqi Psychology: You are still telling me what to do if you don’t make money.

**C0831**

This is not called an exclusive ride. An exclusive ride means that you only pick up one person and then go to the destination.

**C0862** (post author)

Reply to 用户已注销: Some car owners may be exploiting this loophole to combine bookings across platforms. You pay more, and they earn more.

**C0893** (post author)

Reply to 喵叽周日不加班: Exactly. People booking an exclusive ride paid for one. Family members coming along is understandable; combining passenger bookings is absolutely unacceptable.

**C0924** (post author)

Reply to 喵叽周日不加班: Genuine carpool drivers certainly don't make money. From Hangzhou to Jinhua, I pay 80 yuan in tolls and around 35 in fuel for my hybrid. One booking only brings in 50–60 yuan, or 80 if it's a better one. I just want to share a little of the cost, not make a profit. I don't want to drive all over picking people up and dropping them off either. Just thinking about it is tiring, unless you're doing it full-time.

**C0955** (post author)

People generally choose not to pay tolls or to negotiate. Some offer to pay all of them, but very few.

**C0986**

Because they haven't changed their belief that paying automatically makes them a consumer.

## 62. How outrageous are carpooling passengers nowadays?

Source: https://www.rednote.com/discovery/item/6a71b7f00000000022016061
Original record: 50_posts_1000_comments / N42
Text scope: Visible excerpt in source dataset

1/4
How outrageous are carpooling passengers nowadays?
Are you treating yourself like an emperor by sharing a seat?
08-04

### Comments

**C0038**

If I just reply, just ask: Bajie, I won’t go as a teacher.

**C0081**

If this continues, this platform will be ruined. The edge is the end

**C0122**

There is no obligation to go, which is ridiculous. It is recommended that the bus country has a comprehensive arrangement, including buses and taxis.

**C0161**

This is a fake bill

**C0200**

All capital platforms have already deteriorated human nature

**C0236**

Reply to Lang Ziqian: It would be foolish to take that one

**C0271**

Now it’s 130 kilometers 52 blocks

**C0306**

He even marked it out for you. Many people didn’t tell you about it. You didn’t find out until you arrived.

**C0341**

Immediately I will say that they are all black cars and I will also sign up for a tour group.

**C0376**

You can pay one yuan per kilometer, which is not bad.

**C0411**

[Type]: Car looking for people [Model] Xiaopeng p7 or BMW i3 [Date]: August 22-23 [Start]: Nanshan, Shenzhen [End]: Ganzhou, Jiangxi [Number of people]: Personal Requirements: If you have a lot of luggage, you need to tell me in advance which car I can choose to drive back.

**C0445**

52 kilometers, 130 yuan was cancelled. Then came another driver who paid 136 yuan.

**C0479**

If you bring durian and don't take the order, the smell won't go away for a week.

**C0513**

Reply to Li Nianyuan:

**C0547**

Reply to Liu: Look at what I posted downstairs

**C0580**

I'm crying later, needing to change a diaper bag, etc., and I don't have a safety seat yet.

**C0612**

This type is for small accounts to receive orders and receive rewards from the platform. They are afraid of being picked up by others.

**C0644**

Usually exclusive ride passengers complain about professional drivers, but real car owners complain about professional shared ride passengers.

**C0676**

I received 21 yuan, and it is estimated that the other party paid 23 yuan. It should be 14km in the opposite direction to buy a durian, so the journey from the durian shop to the destination became 40km. If I were a blogger, I would take it. I would buy a durian myself and eat it, and use the remaining durian shells to knock the other person on the head, which might heal the other person.

**C0708**

Treatment is free

**C0739**

Carpooling platforms now charge a commission of generally 25%-40%

**C0770**

It’s really hard to comment on carpooling passengers nowadays. They don’t want to spend money but want to take advantage. I haven’t accepted them for a long time.

**C0801**

I never read those who have access points, let alone accept them.

**C0832**

If the discussion is not good, don't accept it, it will save both parties trouble later.

**C0863**

Anyone who accepts this is truly extraordinary.

**C0894**

Twenty-nine kilometers becomes fifty-nine—double the distance. Forty-six minutes becomes eighty-six, or ninety with the shopping stop—double the time too. I wouldn't do it for another 40 yuan. At least 50 extra.

**C0925**

Reply to 喵趣一生: People really do accept those bookings, then curse at the passenger afterward.

**C0956**

Hahaha, crying, motion sickness and spitting up milk—370 wouldn't even cover cleaning the car.

**C0987**

Hahahahahahaha

## 63. There are still people who think there is real carpooling!

Source: https://www.rednote.com/discovery/item/6ac0ce50000000001403965c
Original record: 50_posts_1000_comments / N43
Text scope: Visible excerpt in source dataset

There are still people who think there is real carpooling!
After reading a lot of notes in Xiaohongshu, many passengers were complaining about why highway tolls should be included, and why this package should be included. Now it can basically be said that 99% of the time it is professional carpooling. You can just think of it as the old black cars. They are driven by professional black car drivers, and they are meant to make money. The current carpooling chaos is either asking you for more money, charging you highway tolls, or charging you more on holidays; there is another kind of carpooling that is really disgusting, that is, you have obviously booked an exclusive ride, and they turn around and go to other platforms to recruit a few people. This is really not authentic. But I think the bottom line for these black cars is that as long as the price is negotiated with you at the beginning and they don’t turn their backs on you and force you to pay extra, it’s actually fine. Nowadays, there is very little carpooling in the true sense, that is, the driver himself does not rely on this to make a living, but just picks up one or two people along the way to return some gas money and share some highway tolls. Just treat it as a black car. If you are looking for a carpooling car that is new, comfortable, cheap and does not require highway tolls, there is basically none. There are two main reasons: First, people who drive such good cars don’t lack the money. Now the platform fees are too low, right? What's the second one? The car owner has no way to screen high-quality passengers. Some passengers feel unbalanced when they see you driving a nice car worth hundreds of thousands of dollars, so they deliberately scratch your car with their nails. You couldn't tell it at the time, but it was a good intention. Maybe you are simple, and you will only know it after you have suffered a loss. Therefore, many people are reluctant to use their cars for carpooling, especially new cars that cost RMB 300,000 to RMB 400,000 to RMB 400,000 to RMB 400,000. If you look at the shabby cars on the road, they are basically driven by professionals, and there is no real carpooling at all. So please stop posting and complaining about carpooling charging highway tolls and charging extra money. Those are basically black cars and they are all professional.
10-03 Jiangsu

### Comments

**C0039**

I'm really carpooling, but I don't take orders either.

**C0082**

Pigeon people, those who leave people in the middle, do not accept orders, and cancel their accounts are the real car owners. Professional carpooling is based on money. If money cannot be negotiated, no one will really want to take such orders.

**C0123**

Me too, I go to and from get off work every day and automatically pick up orders within 5 kilometers from the starting point and 8 kilometers from the station. If the price is less than 1 yuan per kilometer, we will not accept the call if it does not go out of highway tolls, hospitals, etc. If you don't get one, you'll be casual. If you don't get a highway toll, the quality of a shared ride won't be high. I took a shared ride order that was very smooth, and I didn't pick up anyone else. He was a family member who helped him take a taxi. When he got on the bus, he designated which highway he was on, and he went straight to breakfast, fried dough sticks, soy milk and eggs. After finishing the order, I tidied up the back seat and discovered that the door handles were all oily and the breakfast bags were thrown into the car door. Since that time, I have never taken an order with conditions lower than the above.

**C0162**

I am also carpooling, but I don’t understand what you mean by not knowing how to pick up. As long as I see that the route is relatively high and there are no detours, I will usually pick up. And I will not charge for those marked by highway tolls or those that are not marked, because it would be too unfair to accept one if not the other, so I will not accept them. There are also pets. If it is a dog, it is fine in a cage. If it is a cat, it does not matter whether it is in a cage or not.

**C0201**

I'm willing to have a beautiful woman like you even if you don't pay her.

**C0237**

I'm not even willing to pull a car with more than 200,000 yuan.

**C0272** (post author)

The elderly and children are not accepted. There are too many uncontrollable factors.

**C0307**

I booked a round-trip trip to Sanqing Mountain on the 5th early. 95% of the people who stopped by would have to walk an hour longer.

**C0342**

I don’t use highway tolls at all, I think there are too many things to do.

**C0377**

Ah, I haven't done carpooling in 4 or 5 years. I really don't know that the rules have changed so much now. What is the operation of "asking for more money"? Do you scan the QR code privately and give it to the driver?

**C0412**

Real carpooling means not accepting orders less than 50 cents per kilometer, not accepting orders that directly indicate that highway tolls are not responsible, not accepting orders of more than two people, and not accepting orders from schools, only picking up one person per trip, emptying the car if the order does not match, not joking about your own car, and it will be over if you do not screen the passengers and pick up the best ones.

**C0446**

You will be besieged by so-called real carpooling drivers.

**C0480**

I am really carpooling. I don’t accept shared ride orders, hospital orders, or pet orders. I don’t accept highway tolls if they are marked as unavailable (although I don’t necessarily let the other party purchase highway tolls).

**C0514**

It's better to go by yourself

**C0548**

I'm a real carpooling car owner, but I can't get orders, so I often go back and forth on my own. Good rides are basically taken away by professional carpooling, so everyone spends money on exclusive rides and ends up not being able to take a real carpooling ride...

**C0581**

Reply to Xiao Fei: For real car owners, unless it costs 1 yuan per kilometer, you come to my place and get off the car where I arrive. Otherwise, the price is really forgotten and it is not troublesome enough. Plus there are traffic jams on holidays. Pick up and drop off takes at least 1 hour

**C0613**

It's okay. I chose to take the bus last week. It was only 13.5 yuan after the discount. I could get a comfortable seat without having to detour. There were more than 100 carpooling cars sitting on it, which were like pieces of pork. It took me four hours to sit on the two-hour journey.

**C0645**

Me too, really carpooling. Detour and no pick-up

**C0677**

Hongshu professional passenger: "The cars that ask me to drive on highway tolls are all illegal cars"

**C0709**

There is a platform that provides rewards or negotiates highway tolls, and you can make up for it.

**C0740**

I figured it out after taking the train three times. I didn’t take the tram more than 500 times. The rest were really smooth rides. Real SF trains are very clean and taste good.

**C0771**

Yes, but I don’t want to sit down. I want to enjoy the benefits of taking a taxi in the name of carpooling and at a reasonable price.

**C0802** (post author)

At least 99% plus high speed included

**C0833**

Also, if you get a petrol car, it must be a genuine carpool.

**C0864**

Me. I post a trip when I drive home from work, but only accept a 100% route match. Last time someone who would require a two-kilometer detour messaged asking why I wouldn't accept them. I just said I wasn't making that detour.

**C0895**

Reply to 默默: I've never taken carpool bookings, but if someone took off their shoes, picked at their feet or smoked in my car, I'd definitely leave them at a service area.

**C0926**

That's what I think too.

**C0957**

I've taken thirteen bookings in my new Xiaomi SU7 Max, mostly on my commute. Today I drove five kilometers in the opposite direction to pick up someone going near my workplace. To avoid being late, I took a detour around traffic, turning a seventeen-kilometer journey into almost thirty, for only 29 yuan. Carpooling really isn't worthwhile.

**C0988**

Genuine carpool drivers are very selective. My trip home this time was 220 kilometers; most platforms offered 60–90 yuan. I wouldn't accept that even for a perfect route match. Eventually I took one person for 122.

## 64. Driver waits for abstract passenger, ending is surprising

Source: https://www.rednote.com/discovery/item/6ae0755d0000000023010182
Original record: 50_posts_1000_comments / N44
Text scope: Visible excerpt in source dataset

/
Driver waits for abstract passenger, ending is surprising
10 hours ago Henan

### Comments

**C0040**

No money will be deducted if the customer cancels.

## 65. Carpooling is ruined by “professional carpooling”

Source: https://www.rednote.com/discovery/item/6a7c0d9f0000000035014e42
Original record: 50_posts_1000_comments / N45
Text scope: Visible excerpt in source dataset

1/3
Carpooling is ruined by “professional carpooling”
08-12

### Comments

**C0041**

Reply: But I always pick up people coming from and to get off work. If I really want to take the expressway, I will ask for highway tolls. If you don’t want to give them, I have already got in the car and have nothing to say. I will go out on my own and I won’t pick up this person anymore.

**C0083**

It’s much cheaper for passengers, okay. I used to go back to the city from get off work for 25 bucks. Then it was 20, then 15, and finally 12. I just watched the price get more and more outrageous. In the end, after I laughed a few times over the 12-yuan order, I deleted the app and never looked at it again. Who is so poor for 12 yuan? Not up to my starting price of driving the door for others.

**C0124**

Very much agree. The large number of fake carpooling drivers coming online is actually the result of three loses: real carpooling drivers can't take orders (taking orders more casually); passengers have to pay more (they need to pay highway tolls); and fake carpooling drivers have intensified competition and their fees are getting lower and lower. Five years ago, 80 kilometers was less than 70 yuan, but now 100 kilometers is only 65 yuan. As a passenger, I am embarrassed to pay such a low price, and I have to add 5 to 10 yuan as a thank you fee. But as a passenger, the cost itself is increased because you don’t have to pay highway fees before, and you can share industry gossip with the driver throughout the journey. But now you have to pay an additional thirty or forty yuan for highway tolls, and there is basically no communication with the driver. I feel that the only beneficiary is the platform, because with more orders, their commissions will also increase.

**C0163**

Reply to the porter: Highway tolls are not given to real passengers, and they are not picked up if they like.

**C0202**

It’s less than 60 yuan for 100 kilometers here.

**C0238**

Reply to fragmentary remarks: Because the time cost is indeed there, it is spread a little, but not much.

**C0273** (post author)

Yes, I won’t answer it now

**C0308**

Reply to the porter: What does a car owner really want highway tolls for? We all depend on how smooth the road is. The kind that is more or less smooth. Anyway, if you bring one, you will make a pure profit. If you don’t bring it, I have to go.

**C0343**

The fuel cost of a car is 60 cents per kilometer, but it can be even lower on the expressway, 40 to 50 cents. 65 yuan for 100 kilometers is indeed the purpose of the platform to share fuel costs. What's more, there are a large number of trams now, and one kilometer only costs a few cents. You may think you are losing money, but in fact, the tram car owner still makes money.

**C0378**

The person who replied: I saw that many of them are 95%. If there is no one on the way, just drive by yourself. Anyway, the carpooling owner should have gone to that place, just to save some costs, not to make money, and there is no need to spend time to pick up and drop off. If there is more than 95%, then pick up, otherwise just go by yourself. Just like when I go carpooling, if someone picks me up, I leave. If no one picks me up, I just take an express bus.

**C0413**

The impact on real car owners is almost zero

**C0447**

In fact, the unit price has not been reduced, because in the past, there was basically no such thing as expressway collection, and in the past, car owners basically put in one order, or at most two orders, but now they both charge expressway and fill it up.

**C0481**

Don’t you think about why so many professional drivers come to this profession?

**C0515**

And the so-called 95% is not very smooth. Anyway, if I share the highway tolls, I will pick it up. If I don’t share it, I won’t pick it up.

**C0549**

It only costs 30 to 40 yuan for 100 kilometers, and the one I took for 700 to 800 kilometers was less than 300 yuan.

**C0582**

In the past, when carpooling had a social aspect, I mainly picked beautiful women. This was the value of carpooling. Later, the social aspect was banned, and people were picked up indiscriminately. This was originally what professional drivers were willing to do.

**C0614**

Reply to Tommy Shelby, a commoner: Last time I went back 70 kilometers and it cost more than thirty kilometers, so I gave up decisively.

**C0646**

Reply to Xiao Hongshu 66037A6E: A real car owner also wants your highway tolls. Will you leave if you like?

**C0678**

Reply to a fragmentary comment: I think it would be better to ban the profession, otherwise the real car owner would really not want to fight for the order.

**C0710**

Reply to momo: The platform provides information. There is nothing we can do about it. Information is the greatest resource.

**C0741**

Reply to Miki Narimori: The ride-hailing platform has already started harvesting carpooling leeks!

**C0772**

The first order I ever took was three female students. It was fun to listen to them chattering in the car while driving 300 kilometers on the highway.

**C0803**

Forget about communicating with passengers. Generally speaking, I don’t talk to passengers easily if they don’t take the initiative to talk. Occasionally, I will say a few words at the end to prevent myself from looking too much like a professional driver. After all, he is a grown man with a family and a family, and it is a bit strange that the carpooling girls are talking to him.

**C0834**

Every time I hear carpooling car owners say "it doesn't make money", I find it unbelievable. Carpooling is not used to make money at all.

**C0865**

I genuinely need these trips and travel between Guangzhou, Dongguan and Shenzhen all year round. I always use carpooling, but only two or three trips a year are with genuine carpool drivers. The rest are full-time drivers using automatic order grabbing. Full-time drivers work well for me too: pickups and drop-offs are quick. Driving myself takes energy and money, and parking in Guangzhou and Shenzhen is expensive and hard to find.

**C0896**

Agreed. Lots of comments blame habitual bargain-hunting passengers, but the reality is that the influx of full-time carpool drivers intensified competition, letting platforms cut prices at will. That then attracted more of those passengers. Before there were many full-time drivers, long-distance rates could reach 1.2 yuan per kilometer, and passengers were generally more considerate too.

**C0927**

Without full-time drivers, long-distance bookings are really hard to get accepted. A shared ride of over 600 kilometers only pays a little over 100 yuan. It's hard to find someone whose route matches that well.

**C0958**

That's not entirely true. Without full-time carpool drivers, there might be no rides available. Personally, I only take bookings that are extremely well matched to my route and exclusive. Really, the platform is to blame: it should use vehicle registration details to limit drivers to two or three bookings a day, preventing full-time drivers from accepting bookings indiscriminately.

**C0989**

Hahaha, same here. I accept bookings on my commute: no big detours, no remote pickups. Even if the destination is in the same area, if it's a little too far, I decline.

## 66. The cat I had raised for eight years was stuffed into the trunk by the driver and suffocated to death

Source: https://www.rednote.com/discovery/item/6a110f2d0000000007011775
Original record: 50_posts_1000_comments / N46
Text scope: Visible excerpt in source dataset

1/11
The cat I had raised for eight years was stuffed into the trunk by the driver and suffocated to death
“The cat I had for eight years was stuffed into the trunk by the driver and suffocated to death”: Who cares whether carpooling is an “exclusive ride” or not? This is a true story and an absurd drama that is being played out repeatedly among countless carpooling passengers. On one side, there is an aunt who has lost her "little kid" who has been with her for eight years. She cries until she collapses, but the driver blocks the ride and runs away without any punishment. On the other side, there are thousands of passengers who place orders for "exclusive rides", but the driver inserts strangers into them on various platforms, causing detours, late arrivals, and crowded spaces. These two incidents seem to occur in the same place, but in fact they are rooted in the same problem: when carpooling drivers turn "fake rides" into business, who will pay for the consequences? What happened to my aunt sounds extreme. But if you often carpool, you must have encountered the following scenarios: · You place an order for an "exclusive ride", and when you get in the car, you find that the passenger seat and the back seat are full of people · The driver is driving with three or four mobile phones on the center console, and various platforms are taking orders at the same time · In order to pick up the "next customer", the driver takes a detour for half an hour or an hour, and you are anxious to catch a plane or a train · You question why the driver wants to share the "exclusive ride" ride, the other party said confidently: "What will I earn if I don't share the ride?" This is not an exception, this is a common phenomenon. According to the relevant provisions of the Civil Code, the aunt can claim compensation from the driver for: (1) The market value of the cat (purchase cost) (2) Solatium for mental damage (high cost of proof, Article 1183 of the Civil Code) (3) Full refund of shipping costs. Just because the driver blackmails the cat and runs away does not mean that the legal liability disappears. If the license plate number is there, people can find it. The police can check the identity of the car owner through the license plate, and the traffic law enforcement department can trace the order record. Platforms are also obliged to disclose true information about drivers. Finally, what kind of travel environment do we want? Auntie’s cat can’t come back. It is difficult to fully compensate for the delayed schedule, occupied space, and consumed trust. But the issues exposed by this incident are far more worthy of attention than the death of a cat: when carpooling drivers can turn "exclusive rides" into shared rides at no cost, when platforms only use a few yuan to pay off injured passengers, when blacklisting and running away can evade all responsibility - the travel safety of each of us is being eroded little by little. We hope that: · Platforms will establish a true stepped compensation mechanism (refund the price difference + 3-5 times compensation) · Each platform will establish a driver blacklist linkage mechanism. If a violation occurs on one platform, all platforms will be banned. · The traffic law enforcement department will increase its crackdown on "fake carpooling" to make illegal operations truly "heartbreaking". · The law will give more respect to the emotional value of pets that accompany them for a long time. Auntie is still sad. The driver is still at large. But we don’t want you, or someone you love, to be the next victim.
Edited on 05-23

### Comments

**C0042**

It seems to be a shared ride

**C0084**

Should be detained

**C0125**

My cat is adopted. If the cat dies in a situation like this, there won’t be much compensation. I can’t punish the other party at all.

**C0164**

If the owner pays, the cat also belongs to the passenger. This is equivalent to throwing the passenger into the trunk and severely punishing the driver. Without severe punishment, it is difficult to prevent such things from happening again. This is not the first time that a driver has put a pet in the trunk and an accident has occurred.

**C0203**

Reply to Vanner who is looking for a weight: Clicked

**C0239**

It seems that the reverse is that 2 is not a premium ride service, and the owner has also defaulted to the behavior of putting the trunk in the car. As for this matter itself, we have to wait and see how it develops. But this is not the first time that premium ride services are used as shared rides.

**C0274**

I'll just put the cat bag on my lap.

**C0309**

The old man caught the afternoon train to Haikou to take the cat out of the island.

**C0344**

Me too, I would never gamble with a cat’s life just to save money and get off the car directly, and the driver would not force the person and the cat to stay in the car.

**C0379**

No matter what, I can't save the kitten's life

**C0414**

As long as it's not a premium pet ride service, it's reasonable for someone else to carry it in the trunk, and it's normal if you don't accept it. This aunt finally compromised with the car and put it in the trunk. Both parties are responsible.

**C0448**

Reply to FIN.E: Shared ride is not ride-hailing, it is a black private car. This situation is difficult to break.

**C0482**

It's a shared ride. The victim said it himself.

**C0516**

Reply to Xiao Hongshu 6A872A10: Oh my god, it’s hard to defend your rights.

**C0550**

Reply to Xiao Hongshu 6A872A10: For shared rides, you also have to pay for the seat, not to mention it is equivalent to a life of your family.

**C0583**

Reply: I really want to eat potato chips: But I don’t understand the driver’s behavior of blacklisting and escaping. If the driver is reasonable, he can tell it on the table.

**C0615**

Yes, you paid for the seat and the cat is a guest. There are many, many people who paid the money but threw the cat in the trunk just to make a penny more. If you said it was too much and put it on the seat mat, it would not make you angry, at least it would not suffocate you to death. I really can’t forgive such a person for throwing the trunk.

**C0647**

Reply to I miss you every day: Did you reply to the wrong person? I am a neutral person.

**C0679**

Reply to Vanner who was looking for a weight: Are you the driver? People also paid for shared rides.

**C0711**

The user who replied has logged out: People in Hainan now melt to the point of melting away every minute they go out, let alone an animal as hairy as a cat.

**C0742**

You have to repay your life debt sooner or later

**C0773**

Reply to Miyu Nail Art Studio: Yes, especially this day, the temperature in the trunk is very high, and it is still in Hainan, it is simply torture...

**C0804**

Reply to Miyu Nail Art Studio: There is no legislation. Cats are not protected by law and they are not passengers.

**C0835**

They were all riding in the same car and when the cat was stuffed into the trunk, the reason why the aunt didn't stop it was because she didn't expect the consequences to be so serious or for some other reason?

**C0866**

Reply to 小红薯6A872A10: Since it's a shared ride, the transaction should be completed through the relevant platform.

**C0897**

Reply to FIN.E: Getting a driver's number from a friend and contacting them directly is just about saving money because platform prices are high. I checked that woman's route: Didi would charge around 400 yuan for one trip.

**C0928**

Reply to 奇迹乘着雪橇来: Neither side is in the right. The woman arranged an unlicensed shared ride outside the platform and was present when the luggage was put in the trunk and agreed to it. Seeking redress is practically impossible.

**C0959**

So frustrating.

**C0990**

Sometimes when people take taxis with a cat in a carrier, drivers insist on putting the cat in the trunk. I refuse. It's a living creature, not cargo.

## 67. If you are a male traveling alone, you can cancel without obligation.

Source: https://www.rednote.com/discovery/item/69e1ccca000000001a033cdc
Original record: 50_posts_1000_comments / N47
Text scope: Visible excerpt in source dataset

If you are a male traveling alone, you can cancel without obligation.
I set my Didi carpooling preference to give priority to female drivers. When I got to the car this morning, I looked through the open passenger window and saw a row of cute pink decorations. When I opened the back door, it was just as I imagined, with clean floor mats, flat seat cushions, a refreshing fragrance, and a gentle smile. Before I even closed the car door, the eldest sister said before she could lower her lips: "Have you set the priority for female drivers?" I couldn't wait to respond to her: "Yes, can you see it over there?" "Haha, the platform notified me as soon as I received the order. This is a female-friendly order. If a man is traveling alone, I can cancel without any responsibility." Through the rearview mirror, we saw clearly the slightly raised corners of each other's mouths. I said "It's great", and the eldest sister also said "It's great". We didn't go into details about what was great about it, we were all in the smiles we exchanged in the air with the fragrance as the medium. She is clean and neat Ms. Wang, Ms. Wang with short hair, Ms. Wang who has a daughter born in 2006, Ms. Wang with a gentle smile, Ms. Wang who takes 10,000+ orders and is defined as an "urban hero" by the platform, and Ms. Wang with superb driving skills who helped me not be late. I am Ms. Guan, who is used to wearing a mask on ride-hailing but does not need it for this order. Together with her eldest sister and daughter, she collectively calls her the post-00s Ms. Guan. My eldest sister commented that she looks like a new teacher. Ms. Guan, who went to the meeting with only half makeup on because she slept in. Ms. Guan, who was not late for the meeting with the help of her eldest sister. In today's unexpected encounter, we all felt the small blessing of being "female friendly".
Edited on 04-18

### Comments

**C0043**

Loyal Amap users download Didi because of this feature

**C0085**

Capitalist sucks blood

**C0126** (post author)

Honeycomb Latte

**C0165**

I think DD can also build a non-smoking carriage type so that people can have more choices.

**C0204**

I’m going to start using Didi. If Amap doesn’t keep up, I will give up using Amap @高德taxi

**C0240**

Off topic, what's on the cover? It looks delicious.

**C0275**

I don’t think we should directly increase the cost of riding for customers. The platform has the responsibility to improve the relevant mechanisms. After all, their commissions are very high.

**C0310**

How good! !

**C0345**

However, a driver sister told me that setting priority for female drivers will not allow them to receive more profitable orders. On the contrary, because there are currently few female drivers, the platform often makes them take detours to pick up orders 3 kilometers away, which in disguise reduces their income. I hope that the platform can protect the rights and interests of female drivers instead of letting them silently bear the cost of multiple detours. I personally can accept a small increase in unit price [Bang R]

**C0380**

The only drawback is that the priority for female drivers is only 30 seconds. I am willing to wait a little longer for a safe and clean car.

**C0415**

Yes, baby, I have them in Foshan

**C0449**

I didn’t know this function existed yet. Then I’ll use Didi instead.

**C0483**

Is it only possible to select using software?

**C0517**

What are you drinking in the picture? It looks delicious.

**C0551**

And the female driver is gentle and gentle in speech! One time, a female driver accidentally took a detour and asked me to refund two yuan. I said it was okay, it didn't matter, and she was still very embarrassed.

**C0584**

I just took a taxi and it was just a few minutes away, and the driver was letting me inhale second-hand smoke.

**C0616**

This function can only be turned on if your registered number is female and the ID card is verified. If you are a boy, just don't open this mode. It is equivalent to a normal taxi ride. She is talking about male users using a female number to open this service. This is considered a fake real-name authentication.

**C0648**

I took a taxi at a high-speed rail station before, and the driver asked me if it was female-friendly. She would tell me that if it weren't for this function, she wouldn't be able to grab a good taxi ride from such a distance. I thought it was very good! !

**C0680**

But, I'm a man, and I don't want to smell the smell of cigarette smoke. I often work all day long, until 11 or 12 o'clock at night, and I can't breathe in the car when I get home, and I feel like I want to die.

**C0712**

Screenshots are proof. Screenshots are proof, and this was only in the second half of 25 years. I learned about Didi’s female-friendly plan and started using Didi frequently.

**C0743**

I will reward you with a little money every time. I don’t know if I can make up for it.

**C0774**

Can I only choose Didi? Then I will uninstall the others.

**C0805**

Why don't I?

**C0836**

Does this really not violate any mandatory legal provisions?

**C0867**

Why isn't this feature available in Guangzhou? @Didi @Didi customer service @Didi travel

**C0898**

I once met a woman driver who said she was heading home to celebrate her birthday after our trip. We all wished her a happy birthday, and she was delighted.

**C0929**

Yes! I also selected a preference for women drivers. Almost every driver is happy to see me. Several told me they were glad to get a women-friendly booking and felt happy when a woman got in.

**C0960**

Could you tell me where that setting is? I don't think I've ever found it.

**C0991**

@Didi @Didi customer service @Didi travel—did you hear that?

## 68. Didi carpooling private shared ride deduction｜Customer service refused to review

Source: https://www.rednote.com/discovery/item/6ae00a61000000000e026829
Original record: 50_posts_1000_comments / N48
Text scope: Visible excerpt in source dataset

1/7
Didi carpooling private shared ride deduction｜Customer service refused to review
"This trick of Didi is too malicious. It has become lawless and it can be done as it pleases. Didi carpooling car owner has stepped on a big trap. The order was a clear exclusive ride order, and only one passenger was picked up during the whole journey. No one was picked up privately, no detours, no extra passengers. The system AI directly judged that I shared the ride privately, and directly deducted a penalty. I appealed to the official customer service, and after many communications, the reply I got was one sentence: There is no way to solve it, and I cannot escalate the feedback to superiors. Regardless of whether I offered to verify the GPS track, the chat history in the app, or even contact the passenger for verification, the customer service refused directly and only offered excuses. What’s even more terrible is that the passenger who agreed to the highway tolls in advance did not pay in the end, and the platform still deducted my money. The job number is 203047, and the entire chat record is retained. The original purpose of the exclusive ride order is to only pull one person, and the algorithm is rough and the appeal channel is useless. Does the owner have no room for appeal? Are there any car owners who were also misjudged by Didi carpooling for illegal deductions? How did everyone successfully defend their rights in the end?
17 hours ago Tianjin

### Comments

**C0044**

Complaining in this case will not work. The best result is to withdraw the yellow card, but the record of the yellow card will always exist.

**C0086**

Go to the Black Cat platform to complain and it will be given to you as soon as you complain.

## 69. What is carpooling?

Source: https://www.rednote.com/discovery/item/6a663f90000000001c00f04e
Original record: 50_posts_1000_comments / N49
Text scope: Visible excerpt in source dataset

What is carpooling?
Is it carpooling that requires me to pay the driver to travel to and from highway tolls? Is it carpooling where the driver has to go around an extra 200 kilometers and I have to pay the extra fare outside the route? The driver himself said that no one called me back when I called him. Is this carpooling?
07-26

### Comments

**C0045**

As the saying goes, don’t take orders if you don’t get along.

**C0087**

Outrageous

**C0127**

Reply to the little monkey roaming in Taolin: In the past, carpooling was really a matter of private cars. Later, with the rise of ride-hailing and the crackdown on gangsters, those who ran illegal cars turned to carpooling, so their behavior is no different from the previous illegal cars. We also went to Chengdu to play, and we all asked for a higher fare when taking a taxi at night. My husband and I called at the same time on our mobile phones. If the fare was not increased, we bought highway tolls, and those who asked for an increase would not leave.

**C0166**

No, the prices were okay in the past few years, but there were always new car owners who took advantage of them. Now the price is as low as dirt, there is no chance of being taken advantage of.

**C0205**

I feel like full-time carpooling is pretty good, it's just like ride-hailing. If you accept a shared ride, it can pick you up at the starting point and take you to your destination, and it's not expensive. He will not yin and yang you either

**C0241**

I often don’t pick up the empty trains, and even if the invitation is unreasonable, I won’t pick up most of them. I can’t make it easier for professional passengers.

**C0276**

There may even be a price increase. I took a taxi from Jingdezhen a few days ago, and the fare was only over 60. Two drivers in a row asked for an increase, and the extra charge was 60. They also asked me to pay extra highway tolls. I chose to split the fare equally with the driver. Can't he see that? He didn't pay a dime, and he was really convinced. And you won’t leave without increasing the price, just double the price.

**C0311**

I have encountered an exclusive ride that required ➕30 yuan and highway tolls.

**C0346**

When I pick up carpooling passengers, I never ask passengers to leave highway tolls, but I will never accept orders from a distance of more than 3 kilometers (for long distances, 10 kilometers).

**C0381**

Similarly, a few days ago I stung a hornet's nest. The drivers of illegal cars were very speechless. After scolding you, they blocked you immediately, leaving you unable to reply. I complained about someone who said bad words, and the Xiaohongshu platform actually took care of it.

**C0416**

Bloggers can try calling on Dida. I often meet Xiangxiang female drivers on Dida! They are all real carpooling masters who have not taken a few orders. Don’t look for those who take a lot of orders. They are all professional and make money.

**C0450**

Reply to Honghong: Me too. Later, the third driver who took the order didn’t say a fare increase, but asked to take the expressway and I paid for the entire expressway, so I paid and left quickly [crying with laughter R]

**C0484**

How many real car owners are there? They are all shady car drivers.

**C0518**

No one really thinks that carpooling is 100% convenient, right?

**C0552**

Stop talking about the carpooling culture. We really need to rectify the professional carpooling that is all about low prices.

**C0585**

Most of them are fake carpooling, so I don’t take them anymore. For distant high-speed trains, the drivers of illegal cars are more reliable than the full-time drivers of carpooling.

**C0617**

There is no 100% smooth ride, it always takes about half an hour to pick up and drop off.

**C0649**

Highway tolls asked me for 5 yuan and asked me for 15 yuan to tell me about the gas bill. My platform also paid more than 30 yuan.

**C0681**

Indeed, it’s really annoying

**C0713**

I do all the exclusive rides, and I also ride all the highway tolls. . .

**C0744**

If there are no illegal drivers, just take the bus.

**C0775**

Reply to Yu You Niannian: I agree with the driver before I get on the bus that if I pay for half of the highway tolls, then he can take at most one person to take out the other half. If he wants to bring more people, then don’t take my order. If he can’t stand the crowding, he will pay more and waste time. The two-way option is agreed in advance.

**C0806**

If it doesn’t go well, you don’t have to accept it.

**C0837**

Finally, someone with an experience as outrageous as mine. Mine was 260 including tolls, but they wanted me to pay 600.

**C0868**

Why?

**C0899**

What I don't understand is whether carpool bookings are assigned to drivers compulsorily by the platform. I tried booking once, thinking it was fine if nobody accepted. But a driver accepted and then called to yell at me.

**C0930**

I split the tolls too, but with four people and a 23-yuan toll, they charged the two of us 20. Unbelievable.

**C0961**

I suddenly feel incredibly lucky. My first carpool trip was 800 kilometers with just me and my cat. I booked a shared ride, but the driver said he couldn't be bothered picking up anyone else, so I had the car to myself. He didn't charge tolls either, just 327 yuan. Bless that kind man!

**C0992**

Is 300 yuan enough for a 200-kilometer ride?

## 70. The carpooling driver was too sleepy and asked the passenger to drive, but the 160 yuan fare was still collected

Source: https://www.rednote.com/discovery/item/6adeb5720000000017037052
Original record: 50_posts_1000_comments / N50
Text scope: Visible excerpt in source dataset

00:02 / 00:35
The carpooling driver was too sleepy and asked the passenger to drive, but the 160 yuan fare was still collected
Yesterday 03:05 Guangdong

### Comments

**C0046**

At least eliminate highway tolls, otherwise people won’t complain.

**C0088**

You give him the carpooling fee, or you ask him to pay you the driving fee, and you can still charge a little bit.

**C0128**

It's really scary. I saw a passenger slapped the driver and woke him up. But that was a regular operating vehicle, not a carpooling one.

**C0167**

He is too sleepy, and the fare may not be refunded. It would be more dangerous for him to drive.

**C0206**

There are two-way options on the platform. You can pay by yourself, or negotiate with the driver. Nowadays, it is usually an equal share when taking the expressway, but there are also some unscrupulous people who ask passengers to pay entirely. Exclusive ride changes the order and says it will save you some highway tolls.

**C0242**

In fact, it is also a loophole. Carpooling’s audit fee is lower than that of ride-hailing. The unit price of carpooling is lower than that of ride-hailing. From a safety perspective, carpooling is not very good.

**C0277**

In the future, you can follow this idea when looking for a driver. Not only do you not have to pay, but you will also earn 160.

**C0312**

Not only that, but also his 50r expressway discount coupon

**C0347**

I drive the car, pay the fare, and pay for the highway. I wouldn’t want to change it for me. It would be better to waive the highway tolls or charge half the fare.

**C0382**

Everyone should calculate it separately. The fare is the fare, and the driving fee should also be charged.

**C0417**

It's like he found a driver who paid for him.

**C0451**

Your husband is in a good mood. He is in a good mood and everything goes well.

**C0485**

At least we don’t insist on safety being the first priority.

**C0519**

It’s just that you shouldn’t take orders when you’re sleepy.

**C0553**

My brother was carpooling, and the driver said he was sleepy. When my brother drove back, they reduced the toll from 55 yuan to 25 yuan. My brother came back so beautiful that he kept talking about it.

**C0586**

Then the driver in the back seat probably has to pay for the ride.

**C0618**

To be fair, the driver should have paid the driving fee. And what if the passenger doesn’t have a driver’s license?

**C0650**

It’s okay if you don’t say you can’t drive.

**C0682**

My husband returned to Shanghai from Zhoushan before. Yes. It is said that a film producer was filming a movie in Zhoushan and was too sleepy. I also let my husband drive it by himself. My husband drove all the way back to Shanghai. My husband was still very happy and told me that he had driven an Audi.

**C0714**

This is reasonable

**C0745**

You're renting a car

**C0776**

Are you going to put out highway tolls now that the wind is blowing? Never used it before

**C0807**

Reply to Wild Voldemort: But in this video the victim paid 50 highway tolls

**C0838**

I like this. I can drive, and I get a free ride home too.

**C0869**

Hiring a designated driver costs much more than the fare.

**C0900**

Carpooling means the driver is going to that destination anyway and finds someone whose route matches. The driver benefits, and the passenger normally pays less than for a dedicated driver.

**C0931**

Reply to 野生伏地魔: No, you have to state beforehand that you won't pay tolls; otherwise you need to pay. You can also negotiate paying half, or take ordinary roads.

**C0962**

I've experienced that too. It was especially scary at night, but I couldn't drive, so he pushed through and finished the trip.

**C0993**

Yes, I think waiving the tolls would roughly make it fair, and most people wouldn't complain then. If you're driving, paying tolls and paying the fare too, of course you'd feel it was unfair.
