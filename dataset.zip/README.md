# Combined Xiaohongshu carpooling dataset — English translation

70 posts and 1,480 comments, combining the two supplied datasets. No overlapping post IDs or comment IDs were found. Identical short texts attached to distinct comment IDs remain separate records.

The English Markdown reading edition groups comments under each post. The bilingual CSV files preserve original Chinese text, source IDs, URLs and English translations. The 50-post source provides visible excerpts; translations do not reconstruct unavailable full post bodies. Four of those posts have no sampled comments.

Translations are machine-generated using Google Translate, with terminology preprocessing for carpooling, ride-hailing, shared rides, exclusive rides, audio played aloud, and highway tolls. Remaining service-limited fields were translated separately, and selected quotations were edited. The complete dataset has not been individually reviewed. Slang, sarcasm, usernames, profanity and incomplete replies may be imperfectly translated. Usernames and source metadata may retain Chinese. Display dates are preserved verbatim.

The earlier sentiment percentages apply only to the initial 480-comment sample; no combined sentiment analysis is claimed here.
